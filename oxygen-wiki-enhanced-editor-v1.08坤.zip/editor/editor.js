/*
 * editor.js — 编辑标签页逻辑（独立标签页编辑的落点）
 *
 * 加载：直接 fetch action=raw（扩展上下文带 host_permissions，可绕过 CORS 读公开页）；
 *       失败再退回 API action=query&prop=revisions 取 wikitext。
 * 保存：编辑标签页「直接带 cookie 保存」——对本扩展已声明 host_permissions 的 wiki.gg 域名，
 *       fetch 带 credentials:'include' 会自动附上用户会话 cookie，直接 POST action=edit 回写；
 *       若返回未登录/令牌错误且存在原页面，则自动经 background 走原页面 MAIN world 兜底保存。
 *
 * 文本可视化编辑：逐行渲染——仅「光标所在行」以源码（带语法着色）编辑，其余行按原站
 *       action=parse 渲染结果显示。字节计数显示初始 / 当前 / 更改。
 * 表格可视化：移除每格独立的跨行列与表头选择控件，整表 width:100% 自适应拉伸；开关在顶栏，
 *       默认仅在检测到表格时打开；打开后列出识别到的表格供选择。片段插入改为用户自定义存储。
 */
(function () {
  'use strict';

  const HAS_WT = (typeof WT !== 'undefined');
  // wtblock.js：wikitext 块分析 + Parsoid 风格本地渲染 + 节点↔源码区间映射。
  // 若未加载（极旧缓存）则退回旧的逐段 action=parse 行为，功能降级但不白屏。
  const HAS_BLK = (typeof WTBlock !== 'undefined');
  const $ = (id) => document.getElementById(id);
  const le = () => document.getElementById('lineEditor');

  // 运行时报错可见化：任何未捕获错误/未处理的 Promise 拒绝都在页面顶部显示红色横幅，
  // 避免出现"白屏/没反应却不知原因"的情况（便于把问题直接反馈给我们定位）。
  function reportFatal(msg) {
    try {
      let el = document.getElementById('wtFatal');
      if (!el) {
        el = document.createElement('div');
        el.id = 'wtFatal';
        el.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:2147483647;background:#ffe5ea;color:#a3123a;'
          + 'border-bottom:1px solid #ff9bb3;padding:6px 12px;font:12px/1.6 ui-monospace,Consolas,monospace;white-space:pre-wrap;';
        (document.body || document.documentElement).appendChild(el);
      }
      el.textContent = '加强编辑发生错误：' + msg;
    } catch (e) { /* 兜底失败则忽略 */ }
  }
  window.addEventListener('error', (ev) => { reportFatal((ev && ev.message) || '未知错误'); });
  window.addEventListener('unhandledrejection', (ev) => {
    let r = ev && ev.reason; r = (r && (r.message || r)) || '未处理的 Promise 拒绝';
    reportFatal(String(r));
  });

  const state = {
    title: '', server: '', scriptPath: '', srcTabId: '', revId: '',
    loadedRevId: 0, loadedTimestamp: '',
    source: '', lines: [], initialBytes: 0, originalText: '',  // originalText = 加载时的原始版本，用于保存前差异对比
    _pendingSaveOpts: null,   // 保存前 diff 弹窗暂存的保存参数
    // 渲染缓存按**段自己的 wikitext** 索引（段是渲染单位，段间无共享状态）
    activeSeg: -1, segments: [], renderCache: {}, pending: new Set(), _pendingCaret: null, _pendingPoint: null,
    // 编辑会话代次：每次新建「活动段源码框」自增；旧 textarea 的回写/Enter 若代次不符则一律作废，
    // 杜绝「换行后旧输入框事件又触发一次回写 → 改动递归重复」（见 makeActiveSeg / handleEnterKey）。
    editEpoch: 0, _srcRr: null,
    // 节点级切换：activeNode = { si, s, e, seg }（当前正在看源码的渲染节点）
    activeNode: null, _nodeSave: null,
    badLinks: new Set(), badLinkList: [], badTargets: new Set(), _badTimer: null,
    siteCss: null, siteCssText: '',
    // 分栏：左右槽位各放一个视图（'source' 源码 / 'ref' 参考页面 / 'ai' DeepSeek / '' 空）。
    // 宽度用等权模型 paneWeight：所有**可见**栏按权重占满整行；权重相等 → 等宽。
    // 任何结构变化（开/关栏、显隐渲染区）都会把权重重置为等权 → 满足「平分空间、宽度一致、关掉即填充」。
    panes: { left: '', right: '' }, paneWeight: { left: 1, main: 1, right: 1 },
    // 三栏的**显示次序**（可被「拖动标题栏换位」交换；拖动后写入 storage 记住）。
    // 不再用常量 PANE_ORDER —— 主编辑区也能参与换位。
    paneOrder: { left: 10, main: 20, right: 30 }, syncScroll: true,
    // 渲染区（主编辑区 #paneMain）是否隐藏：顶栏「渲染区」按钮 / 渲染区内 ✕ 可临时关闭；
    // 规则：当源码栏与参考栏都未打开时，渲染区不允许被关（否则整页空白），会被强制重开。
    renderHidden: false,
    refPage: '', refHtml: '', progressGroups: [], progressCatCache: {}, _progressAt: 0,
    // 正文内正在就地编辑的表格：{ si, idx, cur:{r,c} }
    inlineTable: null,
    // 目录（TOC）：collapsed=折叠状态（记住）；pendingFrag=URL #片段，首次加载后跳一次
    tocCollapsed: false, pendingFrag: '', _segVer: 0,
    tables: [], selected: -1, selR: -1, selC: -1, _pendingCursor: null,
    selRect: null, _dragRows: null,
    wraps: [],              // 自定义「包裹符号 + 快捷键」（见 DEFAULT_WRAPS / buildWrapPanel）
    // 内容转换（zh 维基的 LanguageConverter）：variant = 当前所选变体（默认 zh =「不转换」），
    // variants = 站点可用变体列表 [{code,name}]（见 detectVariant / buildVariantPicker）
    variant: 'zh', variantReady: false, variants: [], sourceVia: ''
  };

  // 编辑概要的默认预制值（用户可在保存栏里自己增删改）
  const DEFAULT_SUMMARIES = ['通过可视化编辑器编辑', '更新表格数据', '修正翻译', '补充内容', '格式调整'];

// 「包裹符号 + 快捷键」默认表：选中文字 → 套上「左符号 + 选中 + 右符号」。
// 未选中时插入「左符号 + 右符号」并把光标放在中间（如 {{物品|}} 的 | 之后，便于直接打参数）。
// caret: 'in' = 光标落在内侧（默认）；'after' = 落在整体之后（如 [[分类:x]] 这种整段追加更顺手）。
// 快捷键一律带 Ctrl/Alt/Shift 修饰，避免抢占输入框内的普通按键；用 e.code 记录（不受键盘布局影响）。
const DEFAULT_WRAPS = [
  { label: '内部链接', open: '[[', close: ']]', key: 'Alt+Digit1', caret: 'in' },
  { label: '物品', open: '{{物品|', close: '}}', key: 'Alt+Digit2', caret: 'in' },
  { label: '元素', open: '{{元素|', close: '}}', key: 'Alt+Digit3', caret: 'in' },
  { label: '图标', open: '{{图标|', close: '}}', key: 'Alt+Digit4', caret: 'in' },
  { label: '粗体', open: "'''", close: "'''", key: 'Alt+Digit5', caret: 'in' },
  { label: '斜体', open: "''", close: "''", key: 'Alt+Digit6', caret: 'in' }
];
// 被占用的组合（一律不注册，并给出提示）——这些是浏览器 / 编辑器自身的固定快捷键
const RESERVED_KEYS = new Set([
  'Ctrl+Enter', 'Ctrl+Shift+Enter', 'Ctrl+KeyS', 'Ctrl+KeyW', 'Ctrl+KeyT', 'Ctrl+KeyN', 'Ctrl+KeyR',
  'Ctrl+KeyF', 'Ctrl+KeyP', 'Ctrl+KeyD', 'Ctrl+KeyL', 'Ctrl+KeyZ', 'Ctrl+KeyY', 'Ctrl+KeyA',
  'Ctrl+KeyC', 'Ctrl+KeyV', 'Ctrl+KeyX', 'Ctrl+Backspace', 'Ctrl+ArrowUp', 'Ctrl+ArrowDown',
  'Ctrl+ArrowLeft', 'Ctrl+ArrowRight', 'Ctrl+Shift+ArrowUp', 'Ctrl+Shift+ArrowDown',
  'Ctrl+Shift+Backspace', 'Ctrl+KeyK', 'Ctrl+Shift+KeyK', 'Alt+ArrowUp', 'Alt+ArrowDown',
  'Meta+Enter', 'Meta+Shift+Enter', 'Meta+KeyS'
]);

// 把 KeyboardEvent 归一化成「修饰键 + code」的稳定字符串，用于注册与显示
function keyStr(e) {
  const parts = [];
  if (e.ctrlKey || e.metaKey) parts.push('Ctrl');
  if (e.altKey) parts.push('Alt');
  if (e.shiftKey) parts.push('Shift');
  if (!parts.length) return '';           // 无修饰键的按键不注册（会抢占正常输入）
  parts.push(e.code || '');
  return parts.join('+');
}
// 快捷键的「人话」显示：Alt+Digit2 → Alt+2，Ctrl+KeyS → Ctrl+S
function prettyKey(s) {
  if (!s) return '未设置';
  return String(s).split('+').map((p) => {
    if (/^Key[A-Z]$/.test(p)) return p.slice(3);
    if (/^Digit\d$/.test(p)) return p.slice(5);
    if (p === 'ArrowUp') return '↑';
    if (p === 'ArrowDown') return '↓';
    if (p === 'ArrowLeft') return '←';
    if (p === 'ArrowRight') return '→';
    if (p === 'Backspace') return '⌫';
    if (p === 'Enter') return '⏎';
    if (p === 'Space') return '空格';
    return p;
  }).join('+');
}
// 快速录入用的「组合 → code」表（录入框里按下 Ctrl+Shift+K，e.code 即 KeyK）
function keyFromEvent(e) { return keyStr(e); }

  // 表格属性标签（class）一键开关：写入 {| 行的 class="…"，供 MediaWiki / 扩展启用「可折叠 / 可排序」等行为
  const CLASS_PRESETS = [
    { cls: 'wikitable', label: '标准表格' },
    { cls: 'sortable', label: '可排序' },
    { cls: 'mw-collapsible', label: '可折叠' },
    { cls: 'mw-collapsed', label: '默认折叠' },
    { cls: 'mw-datatable', label: '数据表' },
    { cls: 'alternating', label: '隔行变色' },
    { cls: 'nowraplinks', label: '禁止换行' },
    { cls: 'plainrowheaders', label: '行首无样式' }
  ];

  // ---------- 工具 ----------
  function normalizeServer(s) {
    if (!s) return location.origin;
    if (s.indexOf('//') === 0) s = 'https:' + s;
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    return s.replace(/\/+$/, '');
  }
  function baseUrl() { return normalizeServer(state.server) + (state.scriptPath || ''); }
  // action=raw 默认会被 CDN/浏览器缓存，可能拿到几秒~几分钟前的旧版本。
  // maxage=0&smaxage=0 让 MediaWiki 不对该响应做缓存；再追加时间戳参数 _= 作为
  // 缓存键，强制 CDN 与浏览器都缓存未命中，确保取到「当前最新修订」。
  function rawUrl() {
    return baseUrl() + '/index.php?title=' + encodeURIComponent(state.title)
      + '&action=raw&maxage=0&smaxage=0' + variantParam() + '&_=' + Date.now();
  }
  function apiUrl() { return baseUrl() + '/api.php'; }
  // 页面在原站的地址（漂亮 URL：/wiki/标题，空格转下划线）
  function pageUrl(title) {
    return baseUrl() + '/wiki/' + encodeURIComponent(String(title || '').replace(/ /g, '_'));
  }

  // ---------- 内容转换（zh 维基的 LanguageConverter 变体）----------
  //
  // 【症状】zh 维基开着语言转换器：请求里**不带** variant 时，服务器会按
  //   「登录用户的语言变体偏好 / variant cookie / Accept-Language」自动挑一个变体
  //   （zh-hans、zh-hant、zh-cn、zh-tw…）再返回文本。扩展取正文时拿不到用户自己设的
  //   「不转换」偏好（取文本的请求不带会话数据，或会话里没有该偏好），于是被转换成
  //   简体/繁体甚至**词汇级**替换（例：「大口呼吸者」→「用嘴呼吸」、「污染氧」→「汙氧」）。
  //   写回时就会把这些转换后的字写进 wiki —— 原文被污染。
  //
  // 【解决】① 取「原文」走 API 的 revisions content 为主路径 —— 当前修订的内容在
  //          服务器端**永远**是未经转换的存储原文，action=raw 仅作兜底；
  //        ② 凡取正文/渲染的地方都显式带 `variant=<所选变体>`；**默认选「不转换」(zh)**，
  //          服务器便不再按 cookie / 语言协商做转换；
  //        ③ 顶栏下拉让用户自己挑变体（选项来自站点 siteinfo，服务器自带中文名）。
  //          换变体会重新加载原文并重渲染 —— 预览与源码始终同一变体，不会一边繁体一边原文。
  function variantParam() {
    return state.variant ? ('&variant=' + encodeURIComponent(state.variant)) : '';
  }
  // 当前所选变体的用名（如「不转换」「简体」），供状态栏/提示引用
  function variantName() {
    if (!state.variant) return '默认';
    const hit = (state.variants || []).find((v) => v.code === state.variant);
    return (hit && hit.name) ? hit.name : state.variant;
  }
  // 是否处于「不转换」——只有不转换时，渲染结果才等于 wiki 的存储原文
  function variantIsRaw() { return state.variant === 'zh'; }
  // 状态栏标记：不转换时显示「（不转换）」；选了会转换的变体时说明**预览**按该变体渲染
  function variantTag() {
    if (!state.variant) return '';
    return variantIsRaw() ? '（不转换）' : ('（预览：' + variantName() + '）');
  }
  // 选了非「不转换」的变体时，**必须让每一段都经服务器渲染**。
  //
  // 【为什么】纯段落 / 标题 / 列表是本地渲染的（WTBlock.renderBlock，不走网络），
  // 而语言转换只发生在**服务器渲染结果**里 —— 本地渲染拿到的永远是原文，不会变繁体。
  // 于是「选了繁體却看不出变化」：只有含 {{模板}} 的段落走了 action=parse 被转换，
  // 其余大半文字仍是原文。这里在有转换器且选了非不转换时禁用本地渲染，
  // 让 action=parse&variant=<所选变体> 接管全部段落（已实测：text=＋variant=zh-hant → 氧氣/遊戲）。
  function variantForcesServer() {
    return !!(state.variants && state.variants.length) && !variantIsRaw();
  }

  // 变体选择持久化：按「站点+scriptPath」分开记，不同 wiki 各有各的选择
  const VARIANT_KEY = 'variantChoice';
  function variantStoreKey() { return (state.server || location.origin) + (state.scriptPath || ''); }
  function loadVariantChoice() {
    return new Promise((res) => {
      try {
        chrome.storage.local.get(VARIANT_KEY, (r) => {
          const m = (r && r[VARIANT_KEY] && typeof r[VARIANT_KEY] === 'object') ? r[VARIANT_KEY] : {};
          res(String(m[variantStoreKey()] == null ? '' : m[variantStoreKey()]));
        });
      } catch (e) { res(''); }
    });
  }
  function saveVariantChoice(code) {
    try {
      chrome.storage.local.get(VARIANT_KEY, (r) => {
        const m = (r && r[VARIANT_KEY] && typeof r[VARIANT_KEY] === 'object') ? r[VARIANT_KEY] : {};
        m[variantStoreKey()] = String(code || '');
        saveJSON(VARIANT_KEY, m);
      });
    } catch (e) { }
  }

  // 兜底用中文名（只在站点没给 general.variants、只能从 languagevariants 拿编码时用）
  const VARIANT_CN = {
    zh: '不转换', 'zh-hans': '简体', 'zh-hant': '繁體', 'zh-cn': '大陆简体',
    'zh-tw': '臺灣正體', 'zh-hk': '香港繁體', 'zh-mo': '澳門繁體',
    'zh-sg': '新加坡简体', 'zh-my': '大马简体'
  };

  // 探测本站可用的转换变体，并定下本次要用的变体。
  // 取值顺序：用户上次选的（且本站仍支持）→ 「不转换」(zh) → 站点默认（不带 variant）。
  //
  // ⚠️ languagevariants 的结构是**嵌套对象**而不是数组：
  //   {"query":{"general":{…},"languagevariants":{"zh":{"zh":{…},"zh-hans":{…},…},"sr":{…},…}}}
  //   外层键是语言代码（服务器的 API 会列出**所有**语言的变体表），内层键才是该语言的变体。
  //   因此必须用本站内容语言 general.lang 去索引，**不能**直接看有没有 zh 这个键
  //   （英文站也会带 zh 的变体表，那样就会给英文站错塞 variant=zh）。
  async function detectVariant() {
    if (state.variantReady) return state.variant;
    state.variantReady = true;                 // 先置位：并发调用只探测一次
    try {
      const url = apiUrl() + '?action=query&meta=siteinfo&siprop=general|languagevariants&format=json&_=' + Date.now();
      const r = await fetch(url, { credentials: 'include', cache: 'no-store', headers: { 'Accept': 'application/json' } });
      if (!r.ok) return state.variant;
      const j = await r.json();
      const q = j && j.query;
      const lang = (q && q.general && q.general.lang) || '';
      let list = null;                                    // [{code,name}]
      // 首选 general.variants —— 服务器自己就把它列成
      //   [{code:'zh',name:'不转换'},{code:'zh-hans',name:'简体'},…]（连中文名一起给）
      const gv = q && q.general && q.general.variants;
      if (Array.isArray(gv)) {
        list = gv.map((v) => {
          const code = String((v && v.code) != null ? v.code : (v == null ? '' : v));
          const name = String((v && v.name) || VARIANT_CN[code] || code || '默认');
          return { code: code, name: name };
        }).filter((v) => v.code || v.name);
      }
      if (!list) {
        // 兜底：只有编码，没有名字 → 用 VARIANT_CN 或编码本身当名字
        let codes = null;
        const lv = q && q.languagevariants;
        if (Array.isArray(lv)) codes = lv.map(String);                        // 兼容数组形态
        else if (lv && typeof lv === 'object') {
          const group = (lang && lv[lang]) ? lv[lang] : null;
          if (group && typeof group === 'object') codes = Object.keys(group);
        }
        if (codes) list = codes.map((c) => ({ code: c, name: VARIANT_CN[c] || c }));
      }
      state.variants = list || [];
      if (state.variants.length) {
        const codes = state.variants.map((v) => v.code);
        const saved = await loadVariantChoice();
        // 默认「不转换」：本站有 zh 就用 zh，否则用站点默认（不带 variant，跟随服务器）
        const fallback = (codes.indexOf('zh') >= 0) ? 'zh' : '';
        state.variant = (saved && codes.indexOf(saved) >= 0) ? saved : fallback;
      } else if (!lang) {
        // 拿不到内容语言（老版本/异常返回）：保留启发式默认，别把 zh 站钉住的变体弄丢
        state.variant = /^\/zh\b/i.test(state.scriptPath || '') ? 'zh' : '';
      } else {
        state.variant = '';                              // 该语言没有语言转换器 → 不需要 variant
      }
    } catch (e) { /* 探测失败：保持默认（zh 站继续用不转换；非 zh 站带上也无副作用） */ }
    return state.variant;
  }

  // ---------- 顶栏「转换」下拉 ----------
  // 选项来自站点 siteinfo；**默认「不转换」**。没有语言转换器的站点直接隐藏该控件。
  function buildVariantPicker() {
    const box = $('variantPick'), sel = $('variantSel');
    if (!box || !sel) return;
    const list = state.variants || [];
    if (!list.length) { box.hidden = true; return; }     // 非转换站：不显示（避免误导）
    box.hidden = false;
    sel.innerHTML = '';
    const codes = list.map((v) => v.code);
    // 选中的是「不带 variant」（站点默认）时，补一个可选项，否则下拉无法表达该状态
    const opts = (state.variant && codes.indexOf(state.variant) < 0) || (!state.variant && codes.indexOf('') < 0)
      ? [{ code: '', name: '默认（跟随站点）' }].concat(list) : list;
    opts.forEach((v) => {
      const o = document.createElement('option');
      o.value = v.code;
      o.textContent = (v.code === 'zh')
        ? (v.name + '（推荐：与原文一致）')                // zh 就是「不转换」
        : v.name;
      sel.appendChild(o);
    });
    sel.value = state.variant || '';
    paintVariantWarn();
    sel.onchange = () => switchVariant(sel.value);   // 用 onchange 而非 addEventListener：可重复调用不叠加
  }
  // 变体下拉的状态提示。
  // ⚠️ 选了非「不转换」的变体**不危险**：MediaWiki 从不转换 wikitext —— 已实测 action=raw /
  //    action=query&prop=revisions / action=parse&prop=wikitext **三种路径都不转换**，
  //    连站点自己的「檢視原始碼」页面在 variant=zh-hant 下显示的也是未转换的原文。
  //    转换只发生在**渲染结果**里，所以这里给的是「预览中」的中性提示，而不是污染警告。
  function paintVariantWarn() {
    const box = $('variantPick'), sel = $('variantSel');
    if (!box) return;
    const previewing = !!state.variant && !variantIsRaw();
    box.classList.toggle('preview', previewing);
    box.classList.remove('warn');
    if (sel) {
      sel.title = previewing
        ? ('预览按「' + variantName() + '」渲染；源码与保存始终是 wiki 原文（MediaWiki 不转换 wikitext）')
        : '内容转换：控制**渲染预览**的变体。默认「不转换」，与 wiki 原文完全一致；源码/保存永远是原文';
    }
    const h = $('srcViewHint');
    if (h) h.textContent = previewing ? ('源码=原文（不转换）· 预览=' + variantName()) : '与渲染栏滚动同步';
  }

  // 换变体：清渲染缓存 → 按新变体重新渲染预览（源码始终是原文，只重载渲染）
  async function switchVariant(code) {
    code = String(code == null ? '' : code);
    if (code === state.variant) return;
    const prev = state.variant;
    const nextName = ((state.variants || []).find((v) => v.code === code) || {}).name || code || '默认';
    // 有未保存改动时先问一句：换变体会重新加载（=丢弃当前编辑）
    const dirty = (state.lines.join('\n') !== (state.originalText || ''));
    if (dirty && !window.confirm('切换内容转换会重新加载页面，当前未保存的修改会丢失。\n\n确定切换到「' + nextName + '」吗？')) {
      const sel = $('variantSel'); if (sel) sel.value = prev;   // 撤销下拉的选择
      return;
    }
    state.variant = code;
    saveVariantChoice(code);
    paintVariantWarn();
    // 渲染缓存是按「段自己的 wikitext」索引的 —— 换变体后同一个 wikitext 的渲染结果会变，
    // 必须整片清掉，否则预览会残留上一个变体的文字。
    state.renderCache = {}; state.pending.clear();
    // 顺带清掉本地渲染缓存：选了非不转换时要改走服务器渲染（variantForcesServer）
    try { (state.segments || []).forEach((s) => { if (s) s._localHtml = undefined; }); } catch (e) { }
    toast(code === 'zh'
      ? '内容转换：不转换（与 wiki 原文一致），正在重新渲染…'
      : ('预览将按「' + nextName + '」渲染（源码/保存仍是原文），正在重新渲染…'));
    await loadSource();
  }

  function byteLen(s) {
    try { return new TextEncoder().encode(s).length; }
    catch (e) {
      let n = 0;
      for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); n += c < 128 ? 1 : (c < 2048 ? 2 : 3); }
      return n;
    }
  }
  // 注意：**不**在这里清渲染缓存。缓存按「段自己的 wikitext」索引 —— 段内容一变，
  // key 就变了，下次 renderForSeg 自然不命中并重新请求**这一段**；没变的段继续命中缓存。
  // 若在这里全清，每敲一个字都会让所有含 transclusion 的段重取一遍。
  function syncSource() {
    state.source = state.lines.join('\n');
    // 分栏里的源码栏要跟着正文侧的改动走（源码栏自己打字时由 refreshSourceView 的焦点保护挡掉）
    try { refreshSourceView(); } catch (e) { }
  }
  // 源码栏里改动后（可能动了表格）→ 防抖重扫表格模型；正在就地编辑表格时跳过
  let _rescanTimer = null;
  function scheduleRescan() {
    if (_rescanTimer) return;
    _rescanTimer = setTimeout(() => {
      _rescanTimer = null;
      if (!state.inlineTable) { try { rescan(); } catch (e) { } }
    }, 320);
  }
  // 顶栏中间的「灵动岛」状态胶囊：文本变化时弹一下（宽度/透明度由 CSS 过渡）
  function setStatus(msg) {
    const el = $('status'); if (!el) return;
    const s = String(msg == null ? '' : msg);
    if (el.textContent === s) return;
    el.textContent = s;
    if (!s) return;
    el.classList.remove('pop');
    void el.offsetWidth;              // 重排一次，保证动画能重播
    el.classList.add('pop');
  }
  let toastTimer = null;
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 1800); }

  function loadJSON(key, def) {
    return new Promise((res) => {
      try { chrome.storage.local.get(key, (r) => { res((r && r[key] && r[key].length) ? r[key] : def); }); }
      catch (e) { res(def); }
    });
  }
  function saveJSON(key, val) { try { chrome.storage.local.set({ [key]: val }); } catch (e) {} }

  // 与 loadJSON 的区别：「已存在但为空数组」是**有效值**（用户把预制概要全删了），
  // 不能像 loadJSON 那样退回默认值 —— 否则删光后一刷新默认概要又全回来。
  function loadJSONStrict(key, def) {
    return new Promise((res) => {
      try {
        chrome.storage.local.get(key, (r) => {
          const has = r && Object.prototype.hasOwnProperty.call(r, key) && Array.isArray(r[key]);
          res(has ? r[key] : def);
        });
      } catch (e) { res(def); }
    });
  }

  // ---------- 主题（白天 / 黑夜）----------
  // 首屏主题已由 <head> 的 theme-boot.js 用 localStorage 镜像先行套用（避免闪白/闪黑）；
  // 这里以 chrome.storage.local 为准再同步一次，并把镜像回写、接好顶栏按钮。
  const THEME_KEY = 'theme';
  function currentTheme() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }
  function applyTheme(t, persist) {
    const dark = (t === 'dark');
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    try { localStorage.setItem('enhEditorTheme', dark ? 'dark' : 'light'); } catch (e) { }
    const tt = $('themeToggle');
    if (tt) {
      const knob = tt.querySelector('.knob');
      if (knob) knob.textContent = dark ? '🌙' : '☀️';
      tt.title = dark ? '当前：黑夜，点击切换到白天（拉绳开关）' : '当前：白天，点击切换到黑夜（拉绳开关）';
    }
    if (persist) saveJSON(THEME_KEY, dark ? 'dark' : 'light');
    // 渲染块是原站 HTML（走 Shadow DOM），必须按新主题重建：重挂深色覆盖表 + 重刷坏链标红。
    // 否则「深字深底」或标红颜色仍停留在旧主题。非 Shadow 路径由 CSS 的 html[data-theme] 规则兜底。
    try { repaintAllRendered(); markRenderedBadLinks(); annotateRenderedLinks(); } catch (e) { }
    // 参考栏也是 Shadow 渲染（深色覆盖表按主题注入）→ 切主题要重建，否则仍是旧配色
    try { if (state.refHtml && viewOpen('ref')) paintRef(state.refHtml); } catch (e) { }
  }
  function initTheme() {
    applyTheme(currentTheme(), false);                                   // 先按首屏镜像同步按钮文案
    loadJSON(THEME_KEY, currentTheme()).then((t) => applyTheme(t, false)); // 再以存储为准
    // 暗色 UI 拉绳开关：点按触发「上下起伏」动画并缓慢切换主题；切换动画进行中锁定，不再触发。
    const tt = $('themeToggle');
    if (tt) {
      const DUR = 600; // 与 CSS 动画 / 过渡时长一致
      tt.addEventListener('click', () => {
        if (state._themeLock) return;                 // 上一次切换未结束 → 忽略本次点按
        state._themeLock = true;
        applyTheme(currentTheme() === 'dark' ? 'light' : 'dark', true);
        // 重新触发拉绳起伏动画
        tt.classList.remove('pull'); void tt.offsetWidth; tt.classList.add('pull');
        setTimeout(() => { state._themeLock = false; }, DUR);
      });
      tt.addEventListener('animationend', () => tt.classList.remove('pull'));
    }
  }

  // ---------- 初始化 ----------
  function init() {
    const q = new URLSearchParams(location.search);
    state.title = q.get('title') || '';
    state.server = q.get('server') || location.origin;
    state.scriptPath = q.get('scriptPath') || '';
    state.srcTabId = parseInt(q.get('src') || '0', 10) || 0;
    state.revId = q.get('rev') || '';
    // URL #片段：跨页 [[z#xx]] 打开本编辑器时，加载完直接跳该章节
    try { state.pendingFrag = location.hash && location.hash.length > 1 ? decodeURIComponent(location.hash.slice(1)) : ''; } catch (e) { state.pendingFrag = ''; }
    try { state.tocCollapsed = localStorage.getItem('tocCollapsed') === '1'; } catch (e) { state.tocCollapsed = false; }
    $('pageTitle').textContent = state.title || '（未知标题）';
    // 标签页标题：词条名-增强编辑
    document.title = state.title ? (state.title + '-增强编辑') : '增强编辑';
    if (!state.title) { setStatus('缺少页面标题，无法加载'); return; }
    if (!HAS_WT) {
      const nb = $('btnNewTable'); if (nb) nb.disabled = true;
    }
    initTheme();               // 白天 / 黑夜主题（尽早，减少闪烁）
    bindEvents();
    wireLineEditor();
    wireToc();                 // 目录「折叠」按钮的委托处理
    initLinkGuard();           // 全局兜底：任何会导航走的链接都改走扩展内打开，编辑页永不被导航走
    initPanes();               // 分栏体系：恢复上次布局 + 拖动条 + 滚动同步
    buildWrapPanel();          // 顶栏「⌘ 包裹符号」弹窗
    buildHelpModal();          // 顶栏「? 快捷键指南」弹窗
    buildDiffModal();          // 保存前「差异对比」弹窗
    buildFloatLayout();   // 信息框右侧浮动：无拖动条，按实测几何让位
    buildSearchModal();        // 顶栏「🔍 搜索」+ Ctrl+K 站内搜索 / 跳转弹窗
    buildExtModal();           // 外链点击确认弹窗
    buildProgressModal();      // 顶栏「🚧 施工进度」弹窗
    bindGlobalTextKeys();      // 包裹 / 插入行 / 删除行 / 复制行 / 移动行 的全局快捷键
    loadSource();
    loadSiteStyles();
  }

  // ---------- 加载源码（API 修订内容「不转换」原文为主，action=raw 兜底）----------
  //
  // 【为什么改成 API 优先】raw 端点会跟随会话/Accept-Language 选变体 → 可能拿到转换版；
  // 而 API 的 revisions content 返回的是**存储原文**，服务器不会做语言转换。
  // 两条路径都显式带 variant=zh（不转换），双保险。
  async function loadSource() {
    setStatus('加载中…');
    try {
      await detectVariant();          // 先确定本站有哪些转换变体、本次用哪个（默认「不转换」）
      buildVariantPicker();           // 顶栏「转换」下拉：填选项 + 同步当前选择（无变体的站点自动隐藏）
      let text = null, via = '';
      try { text = await loadViaApi(); via = 'api'; }          // 主路径：当前修订的原文
      catch (e) { text = null; }
      if (text == null) { text = await loadRaw(); via = 'raw'; } // 兜底：action=raw
      state.source = (text == null) ? '' : text;
      state.sourceVia = via;
      // 便于在控制台确认「原文到底是怎么取的、有没有钉住不转换」
      try { console.log('[加强编辑] 原文来源=' + via + '，variant=' + (state.variant || '（默认，未钉）') + '，rev=' + (state.loadedRevId || '?')); } catch (e) { }
      state.lines = state.source.split('\n');
      state.originalText = state.source;   // 记录加载时的原始版本，供「保存前差异对比」使用
      state.initialBytes = byteLen(state.source);
      if (HAS_WT) rescan();
      state.activeSeg = -1; state.segments = computeSegments(state.lines);
      state.inlineTable = null;            // 重新加载后退出表格就地编辑
      rebuildLineEditor();                 // 主编辑区（渲染）**始终**重建；源码栏是并列分栏
      refreshSourceView(true);             // 源码栏（若开着）跟着换成新原文
      updateCounters();
      const tag = variantTag();
      setStatus(HAS_WT ? ('已加载最新版本' + tag) : ('已加载最新版本' + tag + '（表格引擎未载入，仅源码编辑）'));
      fetchRevInfo(); // 记录当前最新修订号，便于确认"读到的就是最新"
      detectBadLinks(); // 坏链检测：语法坏链立即标红；其余经 API 校验后补标
      applyPendingFragOnce(); // 带 #片段 打开时，加载完跳该章节
    } catch (e) {
      setStatus('加载失败：' + e.message);
    }
  }

  // 读取当前最新修订号/时间戳（仅用于状态提示与"是否最新"的确认）。
  async function fetchRevInfo() {
    try {
      const url = apiUrl() + '?action=query&prop=revisions&rvprop=ids|timestamp&rvslots=main'
        + '&titles=' + encodeURIComponent(state.title) + variantParam() + '&format=json&_=' + Date.now();
      const r = await fetch(url, { credentials: 'include', cache: 'no-store', headers: { 'Accept': 'application/json' } });
      if (!r.ok) return;
      const j = await r.json();
      const pages = j && j.query && j.query.pages; if (!pages) return;
      const p = pages[Object.keys(pages)[0]];
      const rev = p && p.revisions && p.revisions[0];
      if (rev && rev.revid) {
        state.loadedRevId = rev.revid;
        state.loadedTimestamp = rev.timestamp || '';
        setStatus('已加载最新版本' + variantTag() + '（rev ' + rev.revid + '）');
      }
    } catch (e) {}
  }

  // 兜底：action=raw（同样带 variant=zh，尽量拿到不转换的原文）
  async function loadRaw() {
    const r = await fetch(rawUrl(), {
      credentials: 'include', cache: 'no-store',
      headers: { 'Cache-Control': 'no-cache', 'Accept': 'text/plain,*/*' }
    });
    if (r.status === 404) return '';
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.text();
  }

  // 主路径：API 取「当前修订的原文」。rvprop=content 返回**存储原文**，
  // 服务器不做语言转换（再显式带 variant=zh 双保险）→ 就是「不转换」版本。
  async function loadViaApi() {
    // 不带 rvstartid/rvlimit 即取当前版本；带 ids/timestamp 便于记录「读到的是哪一版」。
    const url = apiUrl() + '?action=query&prop=revisions&rvprop=content|ids|timestamp&rvslots=main'
      + '&titles=' + encodeURIComponent(state.title) + variantParam() + '&format=json&_=' + Date.now();
    const r = await fetch(url, { credentials: 'include', cache: 'no-store', headers: { 'Accept': 'application/json' } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    const pages = j && j.query && j.query.pages;
    if (!pages) throw new Error('API 无返回');
    const p = pages[Object.keys(pages)[0]];
    if (!p || p.missing !== undefined) return '';
    const rev = (p.revisions && p.revisions[0]) || null;
    if (!rev) return '';
    if (rev.revid) { state.loadedRevId = rev.revid; state.loadedTimestamp = rev.timestamp || ''; }
    const slot = rev.slots && rev.slots.main;
    // 服务器若因异常仍返回了转换版，也以这里为准：修订内容即「不转换」原文。
    return (slot && slot['*']) ? slot['*'] : (rev['*'] || '');
  }

  // ---------- 块级可视化编辑器（模板/信息框按整块渲染）----------
  // 段（seg）= 一个 MediaWiki **顶层块**：标题 / 段落 / 列表 / 引用 / 表格 /
  // 模板（transclusion）/ 图片 / pre / hr / 空行。
  //
  // v2.0 重构：段边界改由 lib/wtblock.js 决定（与 Parsoid 的顶层块规则一致），
  // 而不是「每行一段」。这带来三件事：
  //   ① 结构一致：段与原站渲染结果的顶层块**一一对应** → 可以把整页一次
  //      action=parse 的结果按序切给各段，标题层级 / 列表连续编号 /
  //      外链 autonumber 全部天然正确（旧的逐段解析会各自从 1 重排）。
  //   ② 可反查：每段带**字符偏移** [cs,ce)，配合渲染块的文本对齐，
  //      点选渲染内容能精确回指到源码的哪一段（甚至哪一个链接 / 模板）。
  //   ③ 语义正确：连续的普通行会合并成一个段落（与 MediaWiki 一致），
  //      源码里的软换行不再被渲染成多个 <p>。
  // 行号字段（start/end）语义不变，故行增删 / 光标换算 / 表格跳转 / 浮动让位
  // 等既有逻辑全部无需改动。
  function computeSegments(lines) {
    state._segVer = (state._segVer || 0) + 1;   // 段表代次：使标题锚点索引缓存失效
    if (!HAS_BLK) return legacySegments(lines);
    const src = lines.join('\n');
    const segs = WTBlock.segments(src);
    if (!segs.length && lines.length) return legacySegments(lines);  // 兜底：解析不出就用旧逻辑
    return segs;
  }

  // 旧版段切分（仅在 wtblock.js 缺失时使用，保留以确保降级不白屏）
  function legacySegments(lines) {
    const segs = [];
    const n = lines.length;
    let i = 0;
    let tmpl = 0, tbl = 0, link = 0;
    const LIST_LINE_RE = /^\s*[*#:;]/;
    function scan(s) {
      for (let k = 0; k < s.length; k++) {
        const c2 = s.substr(k, 2);
        if (c2 === '[[') { link++; k++; continue; }
        if (c2 === ']]') { if (link > 0) link--; k++; continue; }
        if (link > 0) continue;
        if (c2 === '{{') { tmpl++; k++; continue; }
        if (c2 === '}}') { if (tmpl > 0) tmpl--; k++; continue; }
        if (c2 === '{|') { tbl++; k++; continue; }
        if (c2 === '|}') { if (tbl > 0) tbl--; k++; continue; }
      }
    }
    while (i < n) {
      scan(lines[i]);
      if (tmpl > 0 || tbl > 0) {
        let j = i;
        while (j < n && (tmpl > 0 || tbl > 0)) { j++; if (j < n) scan(lines[j]); }
        if (j >= n) { segs.push({ start: i, end: n - 1, cs: 0, ce: 0, kind: 'paragraph' }); i = n; }
        else { segs.push({ start: i, end: j, cs: 0, ce: 0, kind: 'paragraph' }); i = j + 1; }
      } else {
        if (LIST_LINE_RE.test(lines[i])) {
          let j = i;
          while (j + 1 < n && LIST_LINE_RE.test(lines[j + 1])) j++;
          segs.push({ start: i, end: j, cs: 0, ce: 0, kind: 'list' }); i = j + 1;
        } else {
          segs.push({ start: i, end: i, cs: 0, ce: 0, kind: 'paragraph' }); i++;
        }
      }
    }
    return segs;
  }
  function segText(seg) { return state.lines.slice(seg.start, seg.end + 1).join('\n'); }
  // 段的**全局字符区间**（wtblock 给出；旧版兜底时退化为按行累加）。
  function segRange(seg) {
    if (seg.cs != null && seg.ce != null && seg.ce > seg.cs) return [seg.cs, seg.ce];
    let off = 0;
    for (let i = 0; i < seg.start; i++) off += state.lines[i].length + 1;
    const len = segText(seg).length;
    return [off, off + len];
  }
  // 「整段都是空行」（空行 / 只有空白）的段：
  //   action=parse 对空文本返回空 HTML → 以前会退化成"（无法渲染，显示源码）"占位或一整条空白，
  //   空行因此被"压缩"看不见。改为直接画一个 ↵，空行数与源码一一对应。
  function segIsBlank(seg) { return seg.kind === 'blank' || segText(seg).trim() === ''; }
  function blankRenderHost() {
    const d = document.createElement('div'); d.className = 'render';
    const s = document.createElement('span'); s.className = 'render-blank';
    s.textContent = '↵'; s.title = '空行';
    d.appendChild(s);
    return d;
  }

  // ---------- 渲染结果资源地址绝对化 ----------
  // 原站 action=parse 返回的是相对路径（/zh/images/xxx.png、/zh/wiki/xxx）。
  // 在扩展页（chrome-extension://<id>/）里，这些会被解析到扩展自身，导致
  // 图片/图标全部裂掉、模板链接指向扩展地址。这里统一解析成原站绝对地址。
  function toAbs(u) {
    if (!u) return null;
    if (/^(data:|blob:|mailto:|tel:|javascript:|#)/i.test(u)) return null;
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) return null; // 已是绝对地址，保持不动
    try { return new URL(u, baseUrl() + '/').href; } catch (e) { return null; }
  }
  function absSrcset(v) {
    return v.split(',').map((part) => {
      const t = part.trim(); if (!t) return '';
      const sp = t.split(/\s+/); const a = toAbs(sp[0]);
      if (!a) return t; sp[0] = a; return sp.join(' ');
    }).filter(Boolean).join(', ');
  }
  function absolutizeHtml(html) {
    if (!html) return html;
    try {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      doc.querySelectorAll('[src],[href],[poster],[srcset],[style]').forEach((el) => {
        ['src', 'href', 'poster'].forEach((a) => {
          if (!el.hasAttribute(a)) return;
          const abs = toAbs(el.getAttribute(a)); if (abs) el.setAttribute(a, abs);
        });
        if (el.hasAttribute('srcset')) el.setAttribute('srcset', absSrcset(el.getAttribute('srcset')));
        if (el.hasAttribute('style')) el.setAttribute('style', rewriteCssUrls(el.getAttribute('style'), baseUrl() + '/'));
      });
      return doc.body ? doc.body.innerHTML : html;
    } catch (e) { return html; }
  }

  // ---------- 抓取并应用原站样式（Shadow DOM 隔离）----------
  function absUrl(u, base) { try { return new URL(u, base).href; } catch (e) { return u; } }
  // 把 CSS 里的 url() 解析成绝对地址。
  // 关键：`url(//host/x)` 是"协议相对"，在扩展页里会按 chrome-extension: 协议解析，
  // 变成 chrome-extension://host/x → 必然裂图；必须补成 https://。
  function rewriteCssUrls(css, cssUrl) {
    return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (m, q, u) => {
      const t = u.trim();
      if (/^(data:|https?:|#|blob:|about:)/i.test(t)) return m;
      if (t.indexOf('//') === 0) return 'url(' + q + 'https:' + t + q + ')';
      return 'url(' + q + absUrl(t, cssUrl) + q + ')';
    });
  }
  // 原站样式把链接色等信息定义在 :root 的 CSS 变量上（--wiki-content-link-color、
  // --color-link、--pi-* 等）。:root 在 Shadow DOM 内不匹配 → 变量失效 → 链接、
  // 信息框退化成正文色（这正是"链接要悬停才变色"的原因）。这里改写为 :host，
  // 并把 body{} 的排版声明也搬到 :host。
  function adaptCssForShadow(css) {
    let out = css.replace(/(^|[,\s{}]):root\b/g, '$1:host');
    out = out.replace(/(^|})\s*body\s*\{([^}]*)\}/g, (m, p, decls) => {
      const keep = decls.split(';').filter((d) => /^\s*(font-family|font-size|line-height|color)\s*:/i.test(d)).join(';');
      return p + (keep.trim() ? '\n:host{' + keep + ';}' : '');
    });
    return out;
  }
  // 兜底：若无原站样式或变量仍未定义，链接也保持可见的异色高亮。
  const SHADOW_DEFAULTS = [
    ':host{',
    '  --wiki-content-link-color:#4f9bff;',
    '  --wiki-content-link-color--visited:#8a5cff;',
    '  --wiki-content-link-color--hover:#2a7bff;',
    '  --color-link:#4f9bff;--color-link--visited:#8a5cff;--color-link--active:#2a7bff;',
    '  --color-link-new:#e0560b;--color-link-new--visited:#c0522f;',
    '  --color-link-external:#0a8754;',
    '  font-family:-apple-system,"Segoe UI",Roboto,"Microsoft YaHei",sans-serif;',
    '  color:#2a3142;line-height:1.65;',
    // 宿主盒必须与 .render（padding:0）完全一致：:host 是 shadow 根的格式化根，
    // 原站 body 的 margin/padding 若漏进来（或站点给 .mw-parser-output 之类加了缩进），
    // 渲染文字就会比源码文字多缩进一段 → 切换渲染/源码时整段横向脱节。
    '  margin:0;padding:0;box-sizing:border-box;',
    '}',
    'a{text-decoration:none;}',
    'a:hover{text-decoration:underline;}',
    'a.mw-selflink{color:inherit;font-weight:700;}',
    // 渲染块顶层容器不允许再自带缩进（缩进只由 .vseg 提供，与源码层同源）
    '.mw-parser-output{margin:0;padding:0;}',
    '.mw-parser-output>:first-child{margin-top:0;}',
    '.mw-parser-output>:last-child{margin-bottom:0;}',
    ''
  ].join('\n');
  const IMPORT_RE = /@import\s+(?:url\(\s*(['"]?)([^'")]+)\1\s*\)|(['"])([^'"]+)\3)([^;]*);/gi;
  // 递归解析 @import：同源的内联进来（如 MediaWiki:VariableDefinitions.css 提供信息框主题变量），
  // 跨源的（如 Google Fonts）丢弃。深度与总长度设上限，避免失控。
  // 注意顺序：@import 的内容必须排在「引用它的样式表自身规则」之前（与 CSS 规范一致），
  // 否则被导入的样式会反过来覆盖导入者本地的变量定义。
  async function resolveCss(css, cssUrl, depth, st) {
    const imports = [];
    const body = css.replace(IMPORT_RE, (full, q1, u1, q2, u2) => { imports.push(u1 || u2); return ''; });
    let pre = '';
    if (depth > 0 && st.len < 4000000) {
      for (const raw of imports) {
        if (!raw) continue;
        const u = absUrl(raw, cssUrl);
        if (!/^https?:\/\//i.test(u)) continue;
        try { if (new URL(u).origin !== st.origin) continue; } catch (e) { continue; }
        if (st.seen[u]) continue; st.seen[u] = 1;
        try {
          const rr = await fetch(u, { credentials: 'include' });
          if (rr.ok) {
            const t = await resolveCss(await rr.text(), u, depth - 1, st);
            pre += '\n' + t; st.len += t.length;
            if (st.len > 4000000) break;
          }
        } catch (e) {}
      }
    }
    return pre + '\n' + rewriteCssUrls(body, cssUrl);
  }
  async function loadSiteStyles() {
    try {
      const pageUrl = baseUrl() + '/index.php?title=' + encodeURIComponent(state.title);
      const r = await fetch(pageUrl, { credentials: 'include', headers: { 'Accept': 'text/html' } });
      if (!r.ok) return;
      const html = await r.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const pageBase = r.url || pageUrl;
      const st = { origin: new URL(baseUrl()).origin, seen: {}, len: 0 };
      const hrefs = [];
      doc.querySelectorAll('link[rel~="stylesheet"][href]').forEach((l) => {
        const media = (l.getAttribute('media') || '').toLowerCase();
        if (media.indexOf('print') >= 0) return; // 跳过打印样式，避免污染渲染块
        const u = absUrl(l.getAttribute('href'), pageBase);
        if (u && hrefs.indexOf(u) < 0) hrefs.push(u);
      });
      // 内联 <style> 与外部 <link> 一视同仁：都解析 @import 并绝对化 url()
      let cssText = '';
      for (const s of Array.prototype.slice.call(doc.querySelectorAll('style'))) {
        const t = await resolveCss(s.textContent || '', pageBase, 1, st);
        cssText += '\n' + t; st.len += t.length;
      }
      for (const u of hrefs.slice(0, 20)) {
        if (st.seen[u]) continue; st.seen[u] = 1;
        try {
          const rr = await fetch(u, { credentials: 'include' });
          if (rr.ok) { const t = await resolveCss(await rr.text(), u, 2, st); cssText += '\n' + t; st.len += t.length; }
        } catch (e) {}
      }
      const css = SHADOW_DEFAULTS + '\n' + adaptCssForShadow(cssText);
      if (!css.trim()) return;
      state.siteCssText = css;
      if (typeof CSSStyleSheet !== 'undefined') {
        try { const sheet = new CSSStyleSheet(); sheet.replaceSync(css); state.siteCss = sheet; } catch (e) { state.siteCss = null; }
      }
      repaintAllRendered();
      toast('已应用原站样式');
    } catch (e) {}
  }
  // 渲染兜底样式：确保表格 / 信息框的边框线一定画出来。
  // 放在原站样式「之后」，故用 !important 压过原站可能把边框清掉的规则。
  const BORDER_ASSIST_CSS = [
    'table{border-collapse:collapse !important;}',
    'table td,table th{border:1px solid #c8d2e6 !important;}',
    '.wikitable,.infobox,table.infobox,.portable-infobox,.pi-infobox{border:1px solid #c8d2e6 !important;}',
    '.portable-infobox .pi-data,.portable-infobox .pi-group,.portable-infobox .pi-header{border-top:1px solid #e2e8f5 !important;}',
    ''
  ].join('\n');
  let _borderSheet = null, _borderTried = false;
  function borderSheet() {
    if (_borderSheet || _borderTried) return _borderSheet;
    _borderTried = true;
    try { _borderSheet = new CSSStyleSheet(); _borderSheet.replaceSync(BORDER_ASSIST_CSS); } catch (e) { _borderSheet = null; }
    return _borderSheet;
  }
  // 「渲染层 ↔ 源码层」横向同步的强制复位表。
  // 为什么必须单独一张、且排在原站样式**之后**：
  //   SHADOW_DEFAULTS 是拼在原站 CSS **前面**的（原站规则会反过来覆盖它），
  //   而 shadow 根是独立的格式化作用域，:host 上的 margin/padding 与外面的 .vseg 是两套盒。
  //   一旦原站给 body / .mw-parser-output 之类带了缩进，渲染文字就会比源码文字多缩进一段，
  //   同一段在「渲染态」与「源码态」的文字盒左边界不一致 → 整段横向脱节。
  //   故这里只复位**顶层容器**的水平缩进（列表/引用的缩进是内容语义，必须保留）。
  const RENDER_METRIC_CSS = [
    ':host{margin:0 !important;padding:0 !important;}',
    '.mw-parser-output{margin-left:0 !important;margin-right:0 !important;',
    '  padding-left:0 !important;padding-right:0 !important;}',
    ''
  ].join('\n');
  let _metricSheet = null, _metricTried = false;
  function metricSheet() {
    if (_metricSheet || _metricTried) return _metricSheet;
    _metricTried = true;
    try { _metricSheet = new CSSStyleSheet(); _metricSheet.replaceSync(RENDER_METRIC_CSS); } catch (e) { _metricSheet = null; }
    return _metricSheet;
  }

  // 黑夜主题下的渲染块覆盖样式。
  // 渲染块是原站 action=parse 的 HTML，原站样式（搬进 Shadow DOM）本身是**浅色**配色：
  //   :host{color:#2a3142}、浅底表格/信息框…… → 黑夜主题下"深字深底"根本看不清。
  // 这里把「正文提亮、浅底容器压暗、边框/分隔线转深」，并重定义原站的链接 CSS 变量，
  // 让链接保持可辨识的彩色（外链绿、坏链红）。因为原站样式先注入、本表后注入
  // （adoptedStyleSheets 按数组顺序层叠），再配合 !important 就能稳定胜出。
  const DARK_RENDER_CSS = [
    ':host{',
    '  --wiki-content-link-color:#6fb0ff;',
    '  --wiki-content-link-color--visited:#a893ff;',
    '  --wiki-content-link-color--hover:#9cc8ff;',
    '  --color-link:#6fb0ff;--color-link--visited:#a893ff;--color-link--active:#9cc8ff;',
    '  --color-link-new:#ff8086;--color-link-new--visited:#ff9aa0;',
    '  --color-link-external:#4fd39a;',
    '  color:#e3e9f5 !important;background:transparent !important;',
    '}',
    // 正文：除链接/代码外一律提亮（链接颜色在下面单独给回）
    '.mw-parser-output *:not(a):not(code):not(pre):not(kbd):not(tt){color:#e3e9f5 !important;}',
    // 链接内部常套 <span>（显示名等）：必须继承链接色，否则会被上面那条规则冲成浅色
    '.mw-parser-output a *{color:inherit !important;}',
    '.mw-parser-output,.mw-parser-output p,.mw-parser-output li,.mw-parser-output dt,.mw-parser-output dd,',
    '.mw-parser-output h1,.mw-parser-output h2,.mw-parser-output h3,.mw-parser-output h4,.mw-parser-output h5,.mw-parser-output h6,',
    '.mw-parser-output caption,.mw-parser-output blockquote,.mw-parser-output figcaption{color:#e3e9f5 !important;}',
    // 链接：保持彩色，坏链红、外链绿
    '.mw-parser-output a,.mw-parser-output a:visited{color:#6fb0ff !important;}',
    '.mw-parser-output a.external,.mw-parser-output a.extiw{color:#4fd39a !important;}',
    '.mw-parser-output a.new{color:#ff8086 !important;}',
    // 代码块：深底浅字
    '.mw-parser-output code,.mw-parser-output pre,.mw-parser-output kbd,.mw-parser-output tt{',
    '  background-color:rgba(255,255,255,.08) !important;color:#e3e9f5 !important;border-color:#3a4560 !important;}',
    // 浅底容器压暗：否则"白底 + 提亮后的浅字"反而更难读。
    //
    // ⚠️ 用 `:host *` 而不是逐个 class 枚举：站点的自定义容器（.oni-card、.mbox__*、
    // .t-pic…）根本枚举不完，漏一个就是一块"浅底 + 浅字"的隐形文字区。
    // code/pre/kbd/tt/mark 保留自己的底（它们的代码块底色是语义的一部分）。
    ':host *:not(code):not(pre):not(kbd):not(tt):not(mark):not(.node-src):not(.node-src *){',
    '  background-color:transparent !important;}',
    // 枚举清单仍然保留：有些容器靠 `background`（简写）设色，上面那条只压 background-color
    '.mw-parser-output,table,thead,tbody,tfoot,tr,th,td,caption,.wikitable,.infobox,.portable-infobox,',
    '.pi-data,.pi-group,.pi-header,.pi-title,.pi-secondary-background,.navbox,.thumbinner,.gallery,',
    'figure,blockquote{background-color:transparent !important;}',
    // 边框 / 分隔线
    'td,th,.wikitable,.infobox,.portable-infobox,.pi-data,.pi-group,.pi-header{border-color:#3a4560 !important;}',
    'h1,h2,h3,h4,h5,h6{border-bottom-color:#2c3650 !important;}',
    'hr{border-color:#2c3650 !important;background-color:#2c3650 !important;}',
    ''
  ].join('\n');
  let _darkSheet = null, _darkTried = false;
  function darkSheet() {
    if (_darkSheet || _darkTried) return _darkSheet;
    _darkTried = true;
    try { _darkSheet = new CSSStyleSheet(); _darkSheet.replaceSync(DARK_RENDER_CSS); } catch (e) { _darkSheet = null; }
    return _darkSheet;
  }

  // ---------- 黑夜主题：对比度实测兜底 ----------
  //
  // 【为什么光靠 CSS 不够】CSS 只能按选择器覆盖，穷举不完站点的自定义容器
  // （.oni-card{color:#333;background:#fff}、.mbox__*、.t-pic…），也对付不了
  // 内联 `style="color:#000 !important"`。漏一个就是一块"字直接藏进背景"的死区。
  //
  // 所以这里在渲染完成后**实测**：对每个真正显示文字的元素，取它的 computed color
  // 与「有效背景色」（向上找第一个不透明背景，跨 Shadow 边界时从 ShadowRoot 跳到 host），
  // 算 WCAG 对比度；不足就直接改写 color。CSS 只能保证"大部分字"，这条保证**每个字**。
  const DARK_MIN_CONTRAST = 3.0;     // WCAG 低阈值：低于此值基本看不清
  const DARK_FG_LIGHT = '#f2f6ff';   // 背景偏暗 → 浅字
  const DARK_FG_DARK = '#10151f';    // 背景偏亮（浅底没被压掉时）→ 深字自救
  const DARK_TEXT_SHADOW = '0 0 3px rgba(0,0,0,.95), 0 0 6px rgba(0,0,0,.8)';

  function parseCssColor(s) {
    if (!s) return null;
    const str = String(s).trim();
    if (!str || str === 'transparent') return { r: 0, g: 0, b: 0, a: 0 };
    const m = str.match(/rgba?\(([^)]+)\)/i);
    if (!m) {
      if (str.charAt(0) === '#') {
        const h = str.slice(1);
        const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
        if (full.length >= 6) {
          return { r: parseInt(full.slice(0, 2), 16), g: parseInt(full.slice(2, 4), 16), b: parseInt(full.slice(4, 6), 16), a: 1 };
        }
      }
      return null;
    }
    const p = m[1].split(',').map((x) => parseFloat(x.trim()));
    if (p.length < 3 || p.slice(0, 3).some((x) => !isFinite(x))) return null;
    return { r: p[0], g: p[1], b: p[2], a: p.length > 3 && isFinite(p[3]) ? p[3] : 1 };
  }
  function relLuminance(c) {
    const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }
  function contrastRatio(a, b) {
    const l1 = relLuminance(a), l2 = relLuminance(b);
    const hi = Math.max(l1, l2), lo = Math.min(l1, l2);
    return (hi + 0.05) / (lo + 0.05);
  }
  // 页面深色底（宿主/祖先全透明时的兜底）：取 --bg，取不到就用已知的 #0e131e
  function pageDarkBg() {
    try {
      const v = (getComputedStyle(document.documentElement).getPropertyValue('--bg') || '').trim();
      const c = parseCssColor(v);
      if (c && c.a > 0) return c;
    } catch (e) { }
    return { r: 14, g: 19, b: 30, a: 1 };
  }
  // 有效背景：向上找第一个够不透明的 background-color；跨 Shadow 边界时跳到 host。
  // 遇到 background-image（图片/渐变）返回 null —— 底色无法判定，改字色反而可能更糟。
  function effectiveBgOf(el, fallback) {
    let n = el;
    for (let i = 0; i < 40 && n; i++) {
      let cs = null;
      try { cs = getComputedStyle(n); } catch (e) { return null; }
      if (!cs) return null;
      if (cs.backgroundImage && cs.backgroundImage !== 'none') return null;
      const c = parseCssColor(cs.backgroundColor);
      if (c && c.a >= 0.5) return c;
      let p = n.parentNode;
      if (!p) break;
      if (p.nodeType === 11) p = p.host;              // ShadowRoot → host
      n = (p && p.nodeType === 1) ? p : null;
    }
    return fallback;
  }

  /**
   * 让渲染块里的每个字都从背景里"抠"出来（仅黑夜主题）。
   * @returns {number} 实际改写了多少个元素
   */
  function enforceDarkContrast(root) {
    if (!root || currentTheme() !== 'dark') return 0;
    const fallback = pageDarkBg();
    let els = null;
    try { els = root.querySelectorAll('*'); } catch (e) { return 0; }
    let fixed = 0;
    for (let i = 0; i < els.length; i++) {
      const el = els[i];
      try {
        if (el.closest && el.closest('.node-src')) continue;   // 节点源码框有自己的配色
        // 只处理**直接**含可见文字的元素（纯容器写完颜色也没意义，还波及后代）
        let hasText = false;
        for (let k = 0; k < el.childNodes.length; k++) {
          const c = el.childNodes[k];
          if (c.nodeType === 3 && c.nodeValue && c.nodeValue.trim()) { hasText = true; break; }
        }
        if (!hasText) continue;
        const cs = getComputedStyle(el);
        if (!cs || cs.display === 'none' || cs.visibility === 'hidden') continue;
        const fg = parseCssColor(cs.color);
        if (!fg || fg.a === 0) continue;                        // 完全透明的字（刻意隐藏）不动
        const bg = effectiveBgOf(el, fallback);
        if (!bg) {                                              // 图片/渐变背景 → 描边抠字
          el.style.setProperty('text-shadow', DARK_TEXT_SHADOW, 'important');
          continue;
        }
        if (contrastRatio(fg, bg) >= DARK_MIN_CONTRAST) continue;
        el.style.setProperty('color', relLuminance(bg) > 0.35 ? DARK_FG_DARK : DARK_FG_LIGHT, 'important');
        fixed++;
      } catch (e) { /* 单个元素失败不影响其余 */ }
    }
    return fixed;
  }

  // 对一段（si 指定）或所有段跑一遍对比度兜底。切主题 / 重绘后都要跑。
  function enforceDarkContrastPass(si) {
    if (currentTheme() !== 'dark') return;
    const box = le(); if (!box) return;
    const wraps = (si == null)
      ? box.querySelectorAll('.vseg')
      : box.querySelectorAll('.vseg[data-seg="' + si + '"]');
    wraps.forEach((wrap) => {
      const host = wrap.querySelector('.render'); if (!host) return;
      try { enforceDarkContrast(host.shadowRoot || host); } catch (e) { }
    });
  }
  function applyCssToShadow(shadow) {
    const dark = (currentTheme() === 'dark');
    const sheets = [];
    if (state.siteCss) sheets.push(state.siteCss);
    const bs = borderSheet(); if (bs) sheets.push(bs);
    const ms = metricSheet(); if (ms) sheets.push(ms);   // 横向同步复位：必须排在原站样式之后
    const fs = floatSheet(); if (fs) sheets.push(fs);   // 信息框真浮动（原站 float 规则在 Shadow 里失效）
    const ns = nodeSrcSheet(); if (ns) sheets.push(ns);   // 节点级源码框（editor.css 管不到 shadow 内）
    const ixs = interactSheet(); if (ixs) sheets.push(ixs);  // Tabber/折叠组/导航盒的交互兜底
    if (dark) { const ds = darkSheet(); if (ds) sheets.push(ds); }   // 必须最后 → 才能覆盖原站浅色
    if (sheets.length) { try { shadow.adoptedStyleSheets = sheets; return; } catch (e) {} }
    if (state.siteCssText) { const st = document.createElement('style'); st.textContent = state.siteCssText; shadow.appendChild(st); }
    const st2 = document.createElement('style'); st2.textContent = BORDER_ASSIST_CSS; shadow.appendChild(st2);
    const st2b = document.createElement('style'); st2b.textContent = RENDER_METRIC_CSS; shadow.appendChild(st2b);
    const st3 = document.createElement('style'); st3.textContent = FLOAT_BOX_CSS; shadow.appendChild(st3);
    const st3b = document.createElement('style'); st3b.textContent = nodeSrcCssText(); shadow.appendChild(st3b);
    const st5 = document.createElement('style'); st5.textContent = INTERACT_CSS; shadow.appendChild(st5);
    if (dark) { const st4 = document.createElement('style'); st4.textContent = DARK_RENDER_CSS; shadow.appendChild(st4); }
  }
  // ---------- 渲染宿主（v2.0：带源码区间标注）----------
  // seg 传入时，会在渲染完成后调用 WTBlock.annotate 给每个元素打上
  // data-wt-range="起:止"（全局字符区间）—— 这是「点选渲染内容 → 反查源码」的基础。
  // ---------- 分段渲染（v2.0.3：拆解原文 → 每段独立渲染 + 独立点击）----------
  //
  // 架构原则：**段是唯一的渲染与交互单位**。原文先由 WTBlock.segments 拆成可独立
  // 寻址的块，之后每一段**各自**决定怎么渲染、各自持有自己的渲染宿主与映射表，
  // 点击也只在本段范围内解析。段与段之间**不存在任何共享的序列或分配表**。
  //
  // 【为什么废弃 v2.0 的「整页渲染 → 顶层块分配」】
  //   那条路要求把整页 HTML 的顶层块**分配**给各段，而整页里每个块都会产生顶层元素
  //   （含本地渲染的段落 <p>），于是分配必然要猜：按序取会串行、按类型取又要维护
  //   一张标签白名单，任何一次段边界变化都会让全表错位 —— 表现为「下方又多出一份相同
  //   内容」。更要命的是：从整页搬来的节点是**别人那一段**的渲染结果，它的文字与该段
  //   源码对不上，字符级映射必然为空 → 点击一律定位到第一行。
  //
  // 现在每段独立走 action=parse（带 title=，模板才能拿到正确上下文）：
  //   · 渲染结果与该段源码**天然一一对应** —— 不可能重复，也不可能串行；
  //   · 段编辑后只失效**该段**的缓存（其余段不动）→ 局部增量，无整页抖动；
  //   · 不含 transclusion 的块（标题/段落/列表/引用/pre/hr）仍由 WTBlock **同步本地
  //     渲染**，零网络、编辑后立即可见。
  // 结构性代价（标题 <section> 层级、列表/外链编号跨段连续）由既有的
  // renumberExternalLinks() 等事后统一处理，不值得为此引入一整套分配逻辑。

  // 把段转换成 WTBlock.renderBlock 需要的块对象
  function segBlockOf(seg) {
    return {
      kind: seg.kind, cs: seg.cs, ce: seg.ce, text: segText(seg),
      level: seg.level, listKind: seg.listKind,
      title: seg.kind === 'heading' ? segText(seg).replace(/^\s*={1,6}\s*/, '').replace(/\s*={1,6}\s*$/, '') : undefined,
      items: listItemsOf(seg)
    };
  }

  // 该段的本地渲染 HTML（无 transclusion 时可用；否则 null）。
  // 返回 null 即代表「必须走服务端」—— renderForSeg 据此决定是否查缓存/发请求，
  // 所以不需要另一个 canLocal() 谓词（那个函数已随整页分配逻辑一起删除）。
  function localRenderFor(seg) {
    if (!HAS_BLK) return null;
    if (seg._localHtml !== undefined) return seg._localHtml;
    let h = null;
    try { h = WTBlock.renderBlock(segBlockOf(seg)); } catch (e) { h = null; }
    seg._localHtml = h;
    return h;
  }
  // 从整篇扫描结果里取该段对应块的 items（列表渲染需要）
  function listItemsOf(seg) {
    if (seg.kind !== 'list' && seg.kind !== 'quote') return null;
    try {
      const blocks = WTBlock.scanBlocks(state.lines.join('\n')).blocks;
      for (const b of blocks) if (b.cs === seg.cs && b.ce === seg.ce) return b.items;
    } catch (e) { }
    return null;
  }

  // ---------- 渲染宿主（带源码区间标注）----------
  // seg 传入时，会在渲染完成后调用 WTBlock.annotate 给每个元素打上
  // data-wt-range="起:止"（全局字符区间）—— 这是「点选渲染内容 → 反查源码」的基础。
  // ---------- 节点级源码框的样式（注入 Shadow 根）----------
  // .node-src 出现在**渲染块的 shadow 根**里，editor.css（Light DOM）管不到它，
  // 必须单独注入一份。语法着色用的 --tk-* 变量定义在文档 :root，shadow 内取不到，
  // 故这里在注入时**从文档 computed style 读出实际颜色**再写死进表里；
  // 主题切换时 repaintAllRendered → applyCssToShadow 会重建这张表，颜色自动跟上。
  function nodeSrcCssText() {
    const cs = getComputedStyle(document.documentElement);
    const v = (n, fb) => (cs.getPropertyValue(n) || '').trim() || fb;
    const tk = {
      tpl: v('--tk-tpl', '#b5179e'), bad: v('--tk-bad', '#e5484d'), ref: v('--tk-ref', '#7a8600'),
      head: v('--tk-head', '#e0560b'), list: v('--tk-list', '#0a8754'), table: v('--tk-table', '#7a4bff'),
      bold: v('--tk-bold', '#1f3a93'), italic: v('--tk-italic', '#5a6478'),
      ink: v('--ink', '#2a3142'), pink: v('--pink', '#ff7ab0'),
      soft: v('--pink-soft', '#ffe9f3'), line: v('--line', '#e2e8f5'),
      // 控件配色也取自 :root 变量 → 整段态与节点态**同一套**外观（含 danger 态）
      blue: v('--blue', '#3b6fd4'), blueSoft: v('--blue-soft', '#e8f1ff'),
      danger: v('--danger-fg', '#e5484d'), dangerSoft: v('--danger-soft', '#ffeceb'),
      dangerBd: v('--danger-bd', '#f3b6b3')
    };
    const mono = 'ui-monospace,SFMono-Regular,Menlo,Consolas,"Liberation Mono","Courier New",monospace';
    return [
      '.node-src{display:block !important;box-sizing:border-box !important;',
      '  margin:0 !important;padding:0 !important;max-width:none !important;width:auto !important;',
      '  position:relative;background:' + tk.soft + ' !important;',
      '  border:1px solid ' + tk.pink + ' !important;border-radius:4px;}',
      '.node-src .hl,.node-src .ta{box-sizing:border-box !important;margin:0 !important;border:0 !important;',
      // 字体族跟随 :host（= 原站 body 字体，与渲染层同源）→ 切换时换行点一致
      '  font-family:inherit;font-size:inherit;line-height:inherit;',
      '  font-weight:400;font-style:normal;',
      '  font-variant-ligatures:none;font-kerning:none;',
      '  font-feature-settings:"liga" 0,"clig" 0,"calt" 0,"dlig" 0,"hlig" 0,"kern" 0;',
      // 横向不加 padding：宽度必须与被替换的渲染节点完全一致
      '  padding:2px 0 !important;letter-spacing:0;word-spacing:0;tab-size:2;',
      '  white-space:pre-wrap !important;word-break:break-word !important;',
      '  overflow-wrap:break-word !important;overflow:hidden !important;}',
      '.node-src .hl{position:relative !important;min-height:1.6em;pointer-events:none;',
      '  color:' + tk.ink + ' !important;background:transparent !important;}',
      '.node-src .ta{position:absolute !important;inset:0 !important;width:100% !important;height:100% !important;',
      '  display:block !important;resize:none !important;background:transparent !important;',
      '  color:transparent !important;caret-color:' + tk.pink + ' !important;outline:none !important;}',
      // 语法着色：与 editor.css 的 .t-* 一一对应（同一个着色器，只是换了个作用域）
      '.node-src .hl .t-tpl{color:' + tk.tpl + ' !important;}',
      '.node-src .hl .t-link{color:var(--wiki-content-link-color,#4f9bff) !important;}',
      '.node-src .hl .t-link-bad{color:' + tk.bad + ' !important;text-decoration:underline wavy;}',
      '.node-src .hl .t-ref{color:' + tk.ref + ' !important;}',
      '.node-src .hl .t-head{color:' + tk.head + ' !important;font-weight:700;}',
      '.node-src .hl .t-list{color:' + tk.list + ' !important;}',
      '.node-src .hl .t-table{color:' + tk.table + ' !important;}',
      '.node-src .hl .t-bold{color:' + tk.bold + ' !important;}',
      '.node-src .hl .t-italic{color:' + tk.italic + ' !important;font-style:italic;}',
      '.node-src .hl .blank-mark{position:relative;}',
      '.node-src .hl .blank-mark::after{content:"\\21B5";position:absolute;color:' + tk.line + ';opacity:.75;}',
      // 工具条（与整段态 .ln-bar 同一套 .ln-btn 样式，见 nodeSrcCssText 末尾）
      '.node-bar{position:absolute !important;top:1px !important;right:3px !important;z-index:3;',
      '  display:flex !important;gap:3px !important;opacity:.6;}',
      '.node-src:hover .node-bar,.node-src:focus-within .node-bar{opacity:1 !important;}',
      '.node-src .ln-btn{font-family:' + mono + ';font-size:11px !important;line-height:1 !important;',
      '  padding:2px 5px !important;border:1px solid ' + tk.line + ' !important;border-radius:5px;',
      '  background:' + tk.soft + ' !important;color:' + tk.blue + ' !important;cursor:pointer;}',
      '.node-src .ln-btn:hover{background:' + tk.blueSoft + ' !important;border-color:' + tk.blue + ' !important;}',
      // 删除按钮与整段态同为 danger 外观（统一控件的一部分）
      '.node-src .ln-btn.danger{color:' + tk.danger + ' !important;}',
      '.node-src .ln-btn.danger:hover{background:' + tk.dangerSoft + ' !important;border-color:' + tk.dangerBd + ' !important;}',
      ''
    ].join('\n');
  }
  let _nodeSheet = null;
  function nodeSrcSheet() {
    const text = nodeSrcCssText();
    try {
      if (!_nodeSheet) { _nodeSheet = new CSSStyleSheet(); }
      _nodeSheet.replaceSync(text);
      return _nodeSheet;
    } catch (e) { return null; }
  }

  // 渲染片段统一补一层 `.mw-parser-output`。
  //
  // 【为什么必须补】原站页面里正文确实包在 .mw-parser-output 里（Parsoid/皮肤都这么做），
  // 但**我们拿到的不是整页**：action=parse 的 text['*'] 与 WTBlock 本地渲染都只给裸片段
  // （<p> / <table> / <ul>…）。而大量规则是**挂在 .mw-parser-output 前缀下**的：
  //   · 黑夜主题的正文提亮 / 链接配色 / 浅底压暗（DARK_RENDER_CSS）
  //   · 左右 margin、padding 归零（RENDER_METRIC_CSS）
  //   · 浮动盒注入（FLOAT_BOX_CSS 的 :host 之外的部分）
  // 缺了这层容器 → 这些规则**一条都匹配不到** → 黑夜模式下子元素沿用原站的深色字，
  // 压在深色背景上 = 字直接藏进背景（"深字深底"）。
  function wrapParserOutput(html) {
    const s = String(html == null ? '' : html);
    if (!s.trim()) return s;
    if (/class=["'][^"']*\bmw-parser-output\b/.test(s)) return s;   // 已经有了就别重复包
    return '<div class="mw-parser-output">' + s + '</div>';
  }

  function makeRenderHost(html, seg, opts) {
    const host = document.createElement('div');
    host.className = 'render' + ((opts && opts.cls) ? (' ' + opts.cls) : '');
    const frag = wrapParserOutput(html);
    let root;
    if (state.siteCss || state.siteCssText) {
      const shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = frag;
      applyCssToShadow(shadow);
      root = shadow;
    } else {
      host.innerHTML = frag;
      root = host;
    }
    // 顺序很重要：先打「源码区间」标注（我们自己新增的交互节点不该进入区间映射），
    // 再补原站 JS 才会有的交互（页签切换 / 折叠组 / 导航盒折叠）。
    if (seg) annotateSegShadow(root, seg);
    // 标记「这一段渲染的是导航盒」：{{xx导航}} 在原站是整宽横条，不能被信息框挤窄（见 applyFloatLayout）
    try { if (/\bclass\s*=\s*("|')[^"']*\bnavbox\b/.test(frag)) host.classList.add('has-navbox'); } catch (e) { }
    try { if (decorateRenderInteractions(root)) scheduleLanes(); } catch (e) { }
    return host;
  }
  // 给渲染块打源码区间标注。失败（DOM 环境异常）时静默跳过 —— 标注只是增强功能，
  // 不能影响渲染本身（旧行为必须完整保留）。
  function annotateSegShadow(root, seg) {
    if (!HAS_BLK || !seg) return;
    try {
      const r = segRange(seg);
      WTBlock.annotate(root, {
        src: segText(seg), off: r[0], whole: r,
        srcFull: state.lines.join('\n')
      });
    } catch (e) { /* 忽略 */ }
  }
  // 段 si 的渲染 HTML：**本段自己**的渲染结果，与别的段毫无关系。
  //   ① 本地渲染（无 transclusion 的块：标题/段落/列表/引用/pre/hr）→ 同步、零网络；
  //   ② 否则查本段缓存；③ 都没有 → pending（由 renderVisible 触发本段请求）。
  // 返回 { html, blank } —— html 为 null 表示尚未拿到。
  function renderForSeg(si) {
    const seg = state.segments[si];
    if (!seg) return { html: '' };
    if (segIsBlank(seg)) return { html: '', blank: true };
    // 选了会转换的变体时禁用本地渲染 → 每段都走 action=parse&variant=…（见 variantForcesServer）
    const local = variantForcesServer() ? null : localRenderFor(seg);
    if (local != null) return { html: local };
    const key = segText(seg);
    if (state.renderCache[key] !== undefined) return { html: state.renderCache[key] };
    return { html: null, pending: true };
  }

  // 用 renderForSeg 的结果构建**本段**的渲染宿主。
  function buildSegHost(si) {
    const seg = state.segments[si];
    const r = renderForSeg(si);
    if (r.blank) return blankRenderHost();
    if (r.html == null) return null;   // 还没渲染好 → 等本段请求回来再刷
    return makeRenderHost(r.html || '<span class="render-placeholder">（无法渲染，显示源码）</span>', seg);
  }

  function repaintAllRendered() {
    if (!state.segments.length) return;
    le().querySelectorAll('.vseg').forEach((wrap) => {
      const si = Number(wrap.dataset.seg);
      if (si === state.activeSeg) return;
      // 就地编辑中的表格段是我们自己的可编辑网格 → 主题切换/整页重绘都不能替换它
      if (state.inlineTable && state.inlineTable.si === si) return;
      const seg = state.segments[si]; if (!seg) return;
      const host = buildSegHost(si);
      if (!host) return;                 // 尚未拿到 HTML → 保持现状，等本段请求回来再刷
      replaceRenderHost(wrap, host);
    });
    afterRenderPass();
  }

  /**
   * 把一段的渲染内容**幂等地**替换为 host —— 这是「每份内容只出现一次」的唯一通道。
   *
   * ⚠️ 旧实现是 `if (old) replaceChild else appendChild`：
   *    一旦 `.render` 查不到（被节点框替换、或结构被别处动过），就会 **appendChild 追加一份**，
   *    页面下方于是「又多出一份相同内容」。
   *    现在无论 `old` 是否存在，都保证「先清空该段所有既有渲染内容，再放入唯一的一份」。
   */
  function replaceRenderHost(wrap, host) {
    // ⚠️ 必须**无条件先清干净**再挂新的，不能只替换 .render：
    // 段里可能同时残留 .render 与 .node-src（节点态未干净退出、或渲染被中断），
    // 只换掉 .render 会把 .node-src 留在原地 → 同一个段挂着两份内容
    // （= 用户反馈的「下方又重复渲染出一份相同内容」的第二条通道）。
    // 也绝不走 `if (old) replaceChild else appendChild` —— 查不到就 append 同样会累积。
    const olds = [];
    wrap.querySelectorAll('.render, .node-src').forEach((n) => { if (n !== host) olds.push(n); });
    for (let i = 0; i < olds.length; i++) {
      const n = olds[i];
      if (n.parentNode) n.parentNode.removeChild(n);
    }
    wrap.appendChild(host);
  }

  // 每次渲染块重绘后都要做的一致化善后：外链序号全局重排 + 坏链标红 + 链接行为标记。
  // 让位计算放最后：segFloatBox 依赖渲染出的 DOM（信息框要 action=parse 回来才存在）。
  // si 给定 → 只处理这一段（paintSeg 路径，避免每段重绘都全量扫描）；
  // 不给定 → 全部段（主题切换 / 整体重绘）。
  function afterRenderPass(si) {
    renumberExternalLinks();
    markRenderedBadLinks();
    annotateRenderedLinks();
    enforceDarkContrastPass(si);   // 黑夜主题：实测对比度，保证每个字都看得见
    scheduleLanes();
  }

  // ---------- 渲染层 / 源码层 横向同步（脱节修复）----------
  // 不变量：**同一段**在「渲染态」与「源码态」下的文字盒必须完全重合。
  //   源码态：.vseg.active padding 归零，文字盒 = .active-line 内容盒，左右缩进各 var(--seg-px)；
  //   渲染态：.vseg padding 左右各 var(--seg-px)，.render padding:0 → 文字盒与之等宽等位。
  // 这条等式**由 CSS 契约 + RENDER_METRIC_CSS 从结构上保证**，无需任何 JS 实测校正：
  //   · RENDER_METRIC_CSS 用 !important 把 :host 与 .mw-parser-output 的左右 margin/padding 归零
  //     （且排在 state.siteCss 之后注入，不会被原站规则反覆盖）→ 渲染层顶层内容盒左边界恒等于
  //     .vseg 内容盒左边界，与源码层同源。
  //   · 真实浏览器实测（tools/browser_align/）：真实站点 CSS + 真实 {{元素信息框}} action=parse 产物下，
  //     两种状态首行文字 left 完全一致（Δ=0），让位段文字右边界 = 浮动盒 border 左边界 - FLOAT_GAP。
  //
  // 历史教训（v1.9.2 删除）：v1.9.1 曾在这里加过一个 `syncRenderInset()`「实测兜底」——
  // 以活动段 .hl 左边界为基准，量 shadow 顶层元素左边界，差多少就写 host.style.marginLeft。
  // 但它是一个**不幂等的反馈环**：写入 margin 会改变下一次的测量结果（既不收敛又可能写出
  // -591px 这类荒谬值：当 shadow 首元素带左缩进、或本身就是 float:right 的浮动盒时，
  // innerL 严重偏右 → diff 变成大负值）。更关键：`:host{margin:0 !important}` 会**完全压制**
  // 该行内 margin —— 实测 computed margin-left 恒为 0px，即它从头到尾是个**空操作**，
  // 既没修好任何东西，又埋着「一旦 !important 被改动就整块被拉左一大段」的陷阱。故删除。

  function escH(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  // 高亮层每行之间的连接符：必须是「真实换行 \n」，不能是 <br>。
  // <br> 与 textarea 的 \n 在行盒模型上并不等价（尾随 <br> 是否产生行盒、<br> 与软换行叠加
  // 等因浏览器而异）→ 多行文本会「差一行」。让着色层文本与 textarea 的 value 逐字符相同，
  // 只把相同字符包上颜色 span，两层在 white-space:pre-wrap 下的换行/行盒规则即完全一致
  // （这也是 Prism / react-simple-code-editor 的通行做法）。
  const HL_JOIN = '\n';
  // wikitext 语法着色：一趟主正则扫描，「先匹配者优先」。顺序即优先级：
  //   注释 > 重定向 > <ref>块 > 其它标签 > 魔术字/解析函数 > 模板 > 链接 > 标题 >
  //   行为开关 > 水平线 > 列表/缩进 > 表格 > 粗体 > 斜体。
  // 规则：所有内层一律用**非捕获组**（编号稳定）；只上色不改字重/字形（否则字符宽度变 → 光标漂移）。
  function highlightWikitext(text) {
    const re = /(<!--[\s\S]*?-->)|(^[ \t]*#[A-Za-z\u4e00-\u9fff]+(?=[ \t]*\[\[))|(<ref\b[^>]*>[\s\S]*?<\/ref>|<ref\b[^>]*\/>)|(<\/?(?:gallery|math|nowiki|syntaxhighlight|source|code|pre|poem|tabber|references|br|hr|div|span|sup|sub|small|big|center|blockquote|ruby)\b[^>]*\/?>)|(\{\{(?:#[^{}]*|[A-Z][A-Z0-9_]*)(?:[:|][^{}]*)?\}\})|(\{\{[^{}]*\}\})|(\[\[[^\[\]]*\]\])|(^[=]{1,6}[^=\n].*?[=]{1,6}[ \t]*$)|(__[A-Z][A-Z0-9]*__)|(^[ \t]*-{4,}[ \t]*$)|(^[ \t]*[*#;:]+[ \t].*$)|(^[ \t]*\{\|.*$|^[ \t]*\|-.*$|^[ \t]*\|\+.*$|^[ \t]*\|\}.*$|^[ \t]*[|!].*$)|('''[^'\n]*''')|(''[^'\n]*'')/gm;
    let out = '', last = 0, m;
    while ((m = re.exec(text))) {
      out += escH(text.slice(last, m.index));
      const tok = m[0]; let cls = '';
      if (m[1]) cls = 't-comment';                                 // <!-- 注释 -->
      else if (m[2]) cls = 't-redirect';                           // #REDIRECT / #重定向
      else if (m[3]) cls = 't-ref';                                // <ref>…</ref>
      else if (m[4]) cls = 't-tag';                                // 其它扩展/HTML 标签
      else if (m[5]) cls = 't-magic';                              // {{PAGENAME}} / {{#if:…}} 等魔术字、解析函数
      else if (m[6]) cls = 't-tpl';                                // 普通模板
      else if (m[7]) cls = state.badLinks.has(m[7]) ? 't-link-bad' : 't-link';
      else if (m[8]) cls = 't-head';
      else if (m[9]) cls = 't-switch';                             // __NOTOC__ 等行为开关
      else if (m[10]) cls = 't-hr';                                // ----
      else if (m[11]) cls = 't-list';
      else if (m[12]) cls = 't-table';
      else if (m[13]) cls = 't-bold';
      else if (m[14]) cls = 't-italic';
      out += '<span class="' + cls + '">' + escH(tok) + '</span>';
      last = m.index + tok.length;
    }
    out += escH(text.slice(last));
    return out;
  }

  // 着色层「单行 → HTML」的唯一入口（活动行 / 纯源码模式共用）。
  // 空行（''）用一个 .blank-mark 包裹零宽占位符 U+200B：CSS 的 ::after 用**绝对定位**画出 ↵
  // ——绝对定位不参与布局，行宽/行高与 textarea 逐字一致，所以既让用户看见"这里有一个空行"，
  // 又不破坏双层对齐（零宽占位符仍保证该行有真实行盒）。
  function hlLine(ln) {
    if (ln === '') return '<span class="blank-mark">\u200b</span>';
    return highlightWikitext(ln) + '\u200b';
  }

  // ---------- 坏链检测（无法解析的链接 → 着色器标红 + 页首提示）----------
  // 两类会被判为「坏链」：
  //   1) 语法损坏：`[[` 未闭合、目标为空（[[]] / [[|x]]）、目标含非法字符（[]{}<>）；
  //   2) 解析不到：内部链接目标经 API 查询为 missing（红链）或 invalid（非法标题）。
  // 说明：以 API 结果为准，能解析（存在/重定向/跨语言）的一律不标；跨语言/跨 wiki 前缀直接跳过。
  const INTERWIKI_PREFIXES = new Set([
    'w', 'wikipedia', 'commons', 'wikt', 'wiktionary', 'wikiquote', 'wikisource', 'wikinews',
    'wikibooks', 'wikiversity', 'wikispecies', 'meta', 'mw', 'phab', 'species', 'voy',
    'en', 'ja', 'zh', 'de', 'fr', 'ru', 'es', 'ko', 'pt', 'it', 'ar', 'pl', 'nl', 'uk', 'vi', 'tr', 'cs', 'fi', 'sv', 'id', 'th'
  ]);
  const URL_SCHEME_RE = /^(https?|mailto|ftp|ftps|tel|news|irc|ircs|sms|gopher|ssh|geo|urn):/i;

  // 从一个 [[...]] 的 inner 文本里抽出「目标页名」；返回 null 表示不是本 wiki 的页面链接（跳过）
  function linkTargetOf(inner) {
    let t = (inner || '').split('|')[0].trim();
    if (!t) return { empty: true };
    if (t[0] === ':') t = t.slice(1).trim();          // [[:Category:x]] 形式
    if (t[0] === '#') return null;                    // 同页锚点，跳过
    if (URL_SCHEME_RE.test(t)) return null;           // 外链/协议链接，跳过
    const hash = t.indexOf('#');
    if (hash >= 0) t = t.slice(0, hash).trim();       // 去掉 #section
    if (!t) return { empty: true };
    const colon = t.indexOf(':');
    if (colon > 0) {
      const pfx = t.slice(0, colon).toLowerCase();
      if (INTERWIKI_PREFIXES.has(pfx)) return null;   // 跨语言 / 跨 wiki，跳过
    }
    if (/[\[\]{}<>]/.test(t)) return { bad: true };   // 目标含非法字符 → 必然解析不出
    return { target: t };
  }

  // 扫描全文，返回 { entries, candidates }：entries 含已判定的坏链；candidates 待 API 校验
  function scanLinks(src) {
    const entries = [];           // { at, line, raw, reason }
    const candidates = [];        // { at, line, raw, target }
    const spans = [];
    // 与着色器 highlightWikitext 的链接正则保持一致（[^\[\]]*），确保被判坏的 token 一定能被标红
    const re = /\[\[([^\[\]]*)\]\]/g;
    let m;
    const lineOf = (idx) => { let n = 0; for (let k = 0; k < idx; k++) if (src.charCodeAt(k) === 10) n++; return n; };
    while ((m = re.exec(src))) {
      spans.push([m.index, m.index + m[0].length]);
      const info = linkTargetOf(m[1]);
      if (info) {
        const base = { at: m.index, line: lineOf(m.index), raw: m[0] };
        if (info.bad) entries.push(Object.assign({ reason: '目标含非法字符' }, base));
        else if (info.empty) entries.push(Object.assign({ reason: '目标为空' }, base));
        else candidates.push(Object.assign({ target: info.target }, base));
      } else {
        // 非本 wiki 链接：其内容不参与「未闭合 [[」的判定
      }
    }
    // 未闭合的 [[：把已匹配区间剔除后再找残留的 [[
    let masked = src;
    if (spans.length) {
      const arr = masked.split('');
      spans.forEach(([a, b]) => { for (let k = a; k < b; k++) arr[k] = ' '; });
      masked = arr.join('');
    }
    const re2 = /\[\[/g;
    let m2;
    while ((m2 = re2.exec(masked))) {
      const line = lineOf(m2.index);
      const nl = src.indexOf('\n', m2.index);
      entries.push({ at: m2.index, line, raw: src.slice(m2.index, nl < 0 ? src.length : nl), reason: '链接未闭合（缺少 ]]）' });
    }
    return { entries, candidates };
  }

  function renderLinkWarn() {
    const el = $('linkWarn'); if (!el) return;
    const list = state.badLinkList || [];
    el.innerHTML = '';
    if (!list.length) { el.hidden = true; return; }
    el.hidden = false;
    const title = document.createElement('div'); title.className = 'lw-title';
    title.textContent = '⚠ 检测到 ' + list.length + ' 处无法解析的链接（已在下方源码中标红，点击可跳转）：';
    el.appendChild(title);
    const box = document.createElement('div'); box.className = 'lw-list';
    list.forEach((b) => {
      const row = document.createElement('button'); row.type = 'button'; row.className = 'lw-item';
      row.textContent = '第 ' + (b.line + 1) + ' 行：' + (b.raw || '').replace(/\n/g, ' ') + (b.reason ? '（' + b.reason + '）' : '');
      row.title = b.reason || '';
      row.addEventListener('click', () => jumpToLine(b.line));
      box.appendChild(row);
    });
    el.appendChild(box);
  }

  // 跳到指定行：主编辑区激活其所在段并把光标放到该行。
  // 分栏里的源码栏开着时，**优先**把光标与滚动落到源码栏（用户此刻多半在那侧工作），
  // 同时把主编辑区滚到该段，两侧都能看到同一处。
  function jumpToLine(line) {
    if (viewOpen('source')) {
      const ta = $('srcSource');
      if (ta) {
        const t = ta.value;
        let off = 0;
        for (let l = 0; l < line; l++) {
          const nl = t.indexOf('\n', off);
          if (nl < 0) { off = t.length; break; }
          off = nl + 1;
        }
        ta.focus();
        ta.setSelectionRange(off, off);
        const lh = parseFloat(getComputedStyle(ta).lineHeight) || 21;
        ta.scrollTop = Math.max(0, (line - 3) * lh);
        syncSourceScroll();
        // 主编辑区只滚动到该段（不激活，避免与源码栏抢焦点）
        const segs0 = state.segments || [];
        for (let i = 0; i < segs0.length; i++) {
          if (line >= segs0[i].start && line <= segs0[i].end) {
            const w0 = le().querySelector('.vseg[data-seg="' + i + '"]');
            if (w0) w0.scrollIntoView({ block: 'center' });
            break;
          }
        }
        return;
      }
    }
    const segs = state.segments || [];
    for (let i = 0; i < segs.length; i++) {
      const s = segs[i];
      if (line >= s.start && line <= s.end) {
        activateSeg(i, line);
        const wrap = le().querySelector('.vseg[data-seg="' + i + '"]');
        if (wrap) wrap.scrollIntoView({ block: 'center' });
        return;
      }
    }
  }

  // ================= 目录（TOC）与标题锚点跳转 =================
  //
  // 仿原站：按页面里的**标题字段**（== x == / === x === …）在正文首部生成一个目录框，
  // 并接上 MediaWiki 的「片段链接」语义：
  //   [[#xx|yy]]   → 跳到**本页** xx 章节（目标为空 = 本页）
  //   [[z#xx|yy]]  → 跳到 **z 页面**的 xx 章节（z 不存在/红链时按本页处理）
  //   /wiki/X#xx   → 同上（X == 当前页则页内跳转）
  // 关键：片段 xx 与标题锚点都走 WTBlock.headingId（与渲染结果同一套计算）→ 必然对得上。
  let _hidx = null, _hidxVer = -1;
  function headingIndexOf() {
    if (_hidx && _hidxVer === state._segVer) return _hidx;
    const list = [];
    const map = new Map();
    (state.segments || []).forEach((seg, si) => {
      if (!seg || seg.kind !== 'heading') return;
      const raw = segText(seg).replace(/^\s*={1,6}\s*/, '').replace(/\s*={1,6}\s*$/, '');
      let id = '';
      try { id = WTBlock.headingId(raw); } catch (e) { id = ''; }
      const item = { si, level: seg.level || 2, title: raw, id };
      list.push(item);
      if (id) map.set(id, item);
      const alt = id.replace(/_/g, ' ').trim();               // 兼容空格写法
      if (alt && alt !== id) map.set(alt.replace(/\s+/g, '_'), item);
    });
    _hidx = { list, map }; _hidxVer = state._segVer;
    return _hidx;
  }
  // 片段 → 归一化 key（与 headingIndexOf 的 id 同一套规则）
  function fragKey(f) {
    let s = String(f == null ? '' : f).replace(/^#/, '');
    try { s = decodeURIComponent(s); } catch (e) { }
    s = s.replace(/_/g, ' ').trim();
    try { return WTBlock.headingId(s); } catch (e) { return s; }
  }
  // 片段 → 命中的标题段（找不到返回 null）
  function resolveFrag(frag) {
    const key = fragKey(frag);
    if (key) { const hit = headingIndexOf().map.get(key); if (hit) return hit; }
    return null;
  }
  // 目录里显示的标题：去掉常见 wikitext 标记，只留可读文字
  function tocLabel(t) {
    return String(t == null ? '' : t)
      .replace(/\[\[[^\]|]*\|([^\]]*)\]\]/g, '$1')
      .replace(/\[\[([^\]]*)\]\]/g, '$1')
      .replace(/'''''|'''|''/g, '')
      .replace(/<[^>]*>/g, '')
      .replace(/\{\{[^}]*\}\}/g, '')
      .trim();
  }
  // 滚到某个段（渲染区）。正在编辑别的段时先退出编辑态，保证目标段可见。
  function jumpToSegment(si, alignTop) {
    const segs = state.segments || [];
    if (!segs[si]) return false;
    if (state.activeSeg >= 0 && state.activeSeg !== si) {
      state.activeSeg = -1; state._pendingCaret = null; state._pendingPoint = null;
      rebuildLineEditor();
    }
    const wrap = le().querySelector('.vseg[data-seg="' + si + '"]');
    if (wrap) { try { wrap.scrollIntoView({ block: alignTop ? 'start' : 'center' }); } catch (e) { wrap.scrollIntoView(); } }
    return true;
  }
  // 页内片段跳转：frag 为空 → 回顶部；否则找对应标题段
  function jumpToFrag(frag) {
    if (!frag) { const box = le(); if (box) box.scrollTop = 0; return true; }
    const hit = resolveFrag(frag);
    if (hit) return jumpToSegment(hit.si, true);
    toast('本页没有名为「' + String(frag) + '」的章节');
    return false;
  }
  // 生成 / 刷新目录框（作为 #lineEditor 的第一个子节点）。无标题字段则不生成。
  function renderToc() {
    const box = le(); if (!box) return;
    const old = box.querySelector(':scope > .wt-toc'); if (old) old.remove();
    if (/__NOTOC__/i.test(state.source || '')) return;   // 页面声明「不要目录」→ 遵循
    const list = headingIndexOf().list;
    if (!list.length) return;
    const nav = document.createElement('nav');
    nav.className = 'wt-toc' + (state.tocCollapsed ? ' collapsed' : '');
    const items = list.map((h) => {
      const lv = Math.max(2, Math.min(6, h.level));
      const pad = 6 + (lv - 2) * 12;
      const label = tocLabel(h.title) || h.title || ('第 ' + (h.si + 1) + ' 段');
      const labelAttr = WTBlock.esc(label).replace(/"/g, '&quot;');
      return '<li class="wt-toc-lv' + lv + '"><a href="#' + encodeURIComponent(h.id) + '"'
        + ' data-toc-si="' + h.si + '" style="padding-left:' + pad + 'px"'
        + ' title="跳到章节：' + labelAttr + '">' + WTBlock.esc(label) + '</a></li>';
    }).join('');
    nav.innerHTML = '<div class="wt-toc-head"><span>目录</span><span class="wt-toc-grow"></span>'
      + '<button type="button" class="wt-toc-fold" title="折叠 / 展开目录">' + (state.tocCollapsed ? '▸' : '▾') + '</button></div>'
      + '<ol class="wt-toc-list">' + items + '</ol>';
    // 插到**第一个标题段之前**（导言/信息框之后、正文首章之前），并左浮动（见 .wt-toc CSS）。
    // 若首个标题就是首段（页面没有导言）→ 落到最前。
    const firstSi = list[0].si;
    const anchor = box.querySelector('.vseg[data-seg="' + firstSi + '"]');
    if (anchor) box.insertBefore(nav, anchor); else box.insertBefore(nav, box.firstChild);
  }
  // 目录与右侧信息框的**遮挡避让**：左浮的目录若与浮动信息框横向相撞（面板太窄放不下两者），
  // 改为整行堆叠（clear:right）并放弃左浮 —— 宁可目录下移，也不让信息框压住它。
  function layoutTocAgainstFloats() {
    const box = le(); if (!box) return;
    const nav = box.querySelector(':scope > .wt-toc'); if (!nav) return;
    const floats = [];
    box.querySelectorAll('.vseg').forEach((wrap) => {
      const fb = segFloatBox(Number(wrap.dataset.seg)); if (!fb) return;
      const r = fb.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) floats.push(r);
    });
    if (!floats.length) { nav.classList.remove('wt-toc-stack'); return; }
    const nr = nav.getBoundingClientRect();
    let clash = false;
    for (const fr of floats) {
      const ov = Math.min(nr.bottom, fr.bottom) - Math.max(nr.top, fr.top);
      if (ov <= 1) continue;                          // 纵向不重叠 → 不构成遮挡
      if (nr.right > fr.left - 8) { clash = true; break; }
    }
    nav.classList.toggle('wt-toc-stack', clash);
  }
  // 目录「折叠」按钮：委托在 #lineEditor 上（目录框每次重建，不能绑在框本身上）
  function wireToc() {
    const box = le(); if (!box || box._wtTocWired) return;
    box._wtTocWired = true;
    box.addEventListener('click', (e) => {
      const fold = (e.target && e.target.closest) ? e.target.closest('.wt-toc-fold') : null;
      if (!fold) return;
      e.preventDefault(); e.stopPropagation();
      state.tocCollapsed = !state.tocCollapsed;
      try { localStorage.setItem('tocCollapsed', state.tocCollapsed ? '1' : ''); } catch (e2) { }
      const nav = fold.closest('.wt-toc');
      if (nav) { nav.classList.toggle('collapsed', state.tocCollapsed); fold.textContent = state.tocCollapsed ? '▸' : '▾'; }
    }, true);
  }
  // 首次加载后按 URL 上的 #片段 做一次章内跳转（跨页 [[z#xx]] 打开新编辑器时用）
  function applyPendingFragOnce() {
    const f = state.pendingFrag; if (!f) return;
    state.pendingFrag = '';
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { }
    setTimeout(() => { try { jumpToFrag(f); } catch (e) { } }, 60);
  }

  // 检测完成后就地重绘「活动段」的高亮层（不重建 DOM，避免丢焦点/光标）
  function repaintActiveHighlight() {
    const wrap = le().querySelector('.active-line'); if (!wrap) return;
    const ta = wrap.querySelector('.ta'); const pre = wrap.querySelector('.hl');
    if (ta && pre) {
      // 与 makeActiveSeg 的 renderHl 保持一致：逐行 + 每行末尾补 U+200B + 行间真实换行
      pre.innerHTML = ta.value.split('\n').map(hlLine).join(HL_JOIN);
    }
  }

  const _badCache = new Map();   // target(小写) -> true 表示不存在（跨次检测复用，减少请求）
  const _existsCache = new Set(); // target(小写) -> 已确认存在，编辑后重查时不再打 API
  async function detectBadLinks() {
    if (!state.title) return;
    let src; try { src = state.lines.join('\n'); } catch (e) { return; }
    const { entries, candidates } = scanLinks(src);
    // 去重待查目标（同一目标只查一次）
    const uniq = []; const seen = new Set();
    candidates.forEach((c) => { const k = c.target.toLowerCase(); if (!seen.has(k)) { seen.add(k); uniq.push(c.target); } });
    const missing = new Set();
    for (let i = 0; i < uniq.length && i < 500; i += 50) {
      const batch = uniq.slice(i, i + 50);
      batch.forEach((t) => { const k = t.toLowerCase(); if (_badCache.has(k)) missing.add(k); });
      const query = batch.filter((t) => { const k = t.toLowerCase(); return !_badCache.has(k) && !_existsCache.has(k); });
      if (!query.length) continue;
      try {
        const url = apiUrl() + '?action=query&format=json&redirects=1&titles=' + encodeURIComponent(query.join('|'));
        const r = await fetch(url, { credentials: 'include', cache: 'no-store', headers: { 'Accept': 'application/json' } });
        if (!r.ok) continue;
        const j = await r.json();
        if (!j || !j.query) continue;
        const reverse = {};
        (j.query.normalized || []).forEach((n) => { reverse[n.to] = n.from; });
        Object.keys(j.query.pages || {}).forEach((k) => {
          const p = j.query.pages[k]; if (!p) return;
          const orig = reverse[p.title !== undefined ? p.title : k] || (p.title !== undefined ? p.title : k);
          const key = String(orig).toLowerCase();
          if (p.interwiki !== undefined) return;                            // 跨 wiki，跳过
          if (p.missing !== undefined || p.invalid !== undefined) { missing.add(key); _badCache.set(key, true); }
          else _existsCache.add(key);                                       // 存在 / 重定向 → 记住，避免反复查询
        });
      } catch (e) { /* 网络失败：仅保留本轮已判定的语法坏链 */ }
    }
    const badEntries = entries.slice();
    candidates.forEach((c) => {
      if (missing.has(c.target.toLowerCase())) badEntries.push(Object.assign({ reason: '目标页面不存在' }, c));
    });
    badEntries.sort((a, b) => a.at - b.at);
    state.badLinks = new Set(badEntries.map((b) => b.raw));
    state.badLinkList = badEntries;
    // 坏链「目标页名」集合：供渲染块标红用（渲染块里的锚点是按页面名匹配的，不是源码里的 [[...]] 原文）
    const tset = new Set();
    badEntries.forEach((b) => { if (b.target) tset.add(String(b.target).toLowerCase()); });
    state.badTargets = tset;
    renderLinkWarn();
    repaintActiveHighlight();
    repaintSourceHighlight();   // 纯源码模式：把红标同步刷到整篇着色层
    markRenderedBadLinks();     // 可视化模式：把红标同步刷到已渲染块的锚点上
  }
  function scheduleBadLinkCheck(delay) {
    clearTimeout(state._badTimer);
    state._badTimer = setTimeout(() => { detectBadLinks(); }, delay || 1200);
  }

  // ---------- 信息框右侧浮动（float box，v1.9.0）----------
  // 需求：信息框（.infobox / .portable-infobox）像原站一样「贴右侧浮动、左侧文字环绕」，
  // 原文与源码行的**所有控件都移到与信息框的分界处**，**低于信息框的部分恢复全宽**，
  // 并且**不要任何拖动条/分栏带**来划分边界。
  //
  // 关键事实（决定了实现方式）—— v1.9.2 更正：
  //   Shadow DOM **只隔离选择器与事件，不隔离布局**。渲染块虽挂在 shadow 内，里面的 float
  //   仍会沿布局树向上逃逸到「最近的非 BFC 祖先」，即 .line-editor（overflow:auto → BFC）：
  //     ① 逃逸后的 float 会压迫 .line-editor 里**所有后续兄弟段**的文字盒 → 后续段被压窄；
  //        而且活动段的 .hl（在流内 BFC）会收缩避让，.ta（position:absolute）不会 → 两层不等宽 → 脱节。
  //     ② 百分比宽度（`width:min(22em,42%)`）要相对 shadow 宿主（= 段内容宽）算，故仍按宿主收窄。
  //   解决办法：CSS 给 .vseg .render 加 display:flow-root **自建 BFC**，把 float 关在本段内、不再逃逸；
  //   于是「真浮动」只负责**段内**环绕；**段与段之间**的让位再由 JS 按实测几何补 padding。
  //
  // v1.9.0 的做法（对比 v1.8.8 的分栏带）：
  //   · 浮动本体：由 FLOAT_BOX_CSS 注入 Shadow 根（:host 作用域）显式 float:right → 段内文字真环绕；
  //   · 让位判定：applyFloatLayout() 用 getBoundingClientRect 测出每个浮动盒的真实矩形，
  //     只给「与浮动盒**垂直重叠**」的段加 .beside-float，
  //     --box-pad = 该段右边界到浮动盒左边界的距离 + 间距；
  //   · 一旦某段不再与浮动盒重叠（低于信息框下边缘）→ 去掉 .beside-float → padding 归零 → **恢复全宽**；
  //   · 让位会改变段高 → 段高又影响重叠判定，故最多迭代 3 轮至稳定（stabilizeFloatLayout）；
  //   · 没有 .float-lane 容器、没有 col-resize 把手、没有 state.laneW / laneWidth 存储。
  //
  // 关键不变量：
  //   · 段边界完全不变（computeSegments 未动）→ 行号、段号、光标↔行映射一律不受影响；
  //   · 活动段（正在编辑源码的那行）也参与让位，且留白必须加在 .hl/.ta 双层自身
  //     （父级 padding 压不窄 position:absolute;inset:0 的 .ta → 两层宽度不一致 → 光标漂移）；
  //   · 只改 class 与行内 CSS 变量，**从不移动 / 删除任何段节点**（不会让 textarea 失焦）。
  //   · 点选定位用 caretPositionFromPoint / pointToOffsetFallback（按真实排版）
  //     → 宽度变化后自动跟随，无需改代码。
  const FLOAT_SEL = '.wt-pi-tabs-wrap,.infobox,.portable-infobox,.pi-infobox,table.infobox';
  const FLOAT_GAP = 16;            // 文字与浮动盒之间的间距（px）
  const FLOAT_MIN_PAD = 10;        // 让位留白的下限（px），保证段内文字不贴死
  // 注入 Shadow 根的浮动样式：原站的 float 规则挂在 .mw-parser-output 下，
  // Shadow DOM 的 :host 没有这条祖先链 → 浮动在渲染块里「从未生效」，这里自己补一条。
  const FLOAT_BOX_CSS = [
    ':host .infobox,:host .portable-infobox,:host .pi-infobox,:host table.infobox{',
    '  float:right !important;clear:right;',
    // 宽度按 shadow 宿主（= 段内容宽）取百分比，并设下限保证窄屏也不至于压没正文
    '  width:min(22em,42%);min-width:150px;max-width:100%;box-sizing:border-box;',
    '  margin:0 0 10px ' + FLOAT_GAP + 'px;',
    // ⚠️ 关键：把「绝对定位 / 固定定位」的浮层**拉回普通流**。
    //    有些站点的信息框用 position:absolute（或内部浮层用 absolute）实现悬浮，
    //    此时 float 会被浏览器完全忽略（CSS 规定：绝对定位盒的 float 计算为 none），
    //    于是 ① 下方段落的文字不会绕开它 → 被整块盖住（看起来像「下方又多了一份内容」）；
    //    ② 绝对定位盒处于更高的绘制层 → 点击永远命中浮层，被覆盖的段落完全点不到。
    //    强制 position:static 让它重新参与浮动流，文字正常环绕、让位逻辑也才成立。
    '  position:static !important;',
    '  z-index:auto !important;',
    '}',
    // 「多样式」合并后的包装盒：**它**才是浮动盒（一个框），里面的各个信息框回到普通流、
    // 只显示当前样式那一个 —— 否则内层再 float 一次会把包装盒高度压塌。
    ':host .wt-pi-tabs-wrap{',
    '  float:right !important;clear:right;position:static !important;z-index:auto !important;',
    '  width:min(22em,42%);min-width:150px;max-width:100%;box-sizing:border-box;',
    '  margin:0 0 10px ' + FLOAT_GAP + 'px;',
    '}',
    ':host .wt-pi-tabs-wrap .infobox,:host .wt-pi-tabs-wrap .portable-infobox,:host .wt-pi-tabs-wrap .pi-infobox{',
    '  float:none !important;clear:none !important;width:100% !important;max-width:100% !important;',
    '  min-width:0 !important;margin:0 !important;',
    '}',
    ''
  ].join('\n');
  let _floatSheet = null, _floatTried = false;
  function floatSheet() {
    if (_floatSheet || _floatTried) return _floatSheet;
    _floatTried = true;
    try { _floatSheet = new CSSStyleSheet(); _floatSheet.replaceSync(FLOAT_BOX_CSS); } catch (e) { _floatSheet = null; }
    return _floatSheet;
  }
  // ---------- 渲染块内交互的兜底样式 ----------
  //
  // 【为什么需要】渲染块是 action=parse 的产物 + Shadow DOM：原站的 JS（TabberNeue 切页签、
  // PortableInfobox 折叠组、jquery.makeCollapsible）**都不会在 Shadow 里运行**。结果：
  //   · <tabber> 的多个面板「全部显示出来」（用户看到的就是这个）；
  //   · pi-collapse 折叠组点了没反应；
  //   · 导航盒（mw-collapsible）没有折叠开关。
  // 所以这里自己补一份「交互兜底」：JS 负责切换（见 decorateRenderInteractions），
  // CSS 负责保证可见性规则一定成立（原站 CSS 不一定被完整取到，且顺序不保证）。
  const INTERACT_CSS = [
    /* —— TabberNeue（.tabber__header/.tabber__tab/.tabber__section/.tabber__panel）—— */
    '.tabber.wt-tabs-ready > .tabber__section > .tabber__panel{display:none !important;}',
    '.tabber.wt-tabs-ready > .tabber__section > .tabber__panel.wt-tab-active{display:block !important;}',
    '.tabber > .tabber__header .tabber__tab{cursor:pointer;}',
    '.tabber > .tabber__header .tabber__tab.wt-tab-active{font-weight:700;box-shadow:inset 0 -2px 0 currentColor;}',
    /* 站点 JS 的左右翻页按钮在没有 JS 时只是两个空块 → 直接隐藏 */
    '.tabber > .tabber__header > .tabber__header__prev,',
    '.tabber > .tabber__header > .tabber__header__next{display:none !important;}',
    /* —— 旧版 Extension:Tabber（.tabbertab + title 属性）—— */
    '.tabber.wt-tabs-classic > .tabbertab{display:none !important;}',
    '.tabber.wt-tabs-classic > .tabbertab.wt-tab-active{display:block !important;}',
    '.wt-classic-tabs{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 6px;}',
    '.wt-classic-tab{cursor:pointer;font:inherit;font-size:12.5px;padding:2px 10px;border:1px solid #c8d2e6;',
    '  border-radius:12px;background:#f6f8ff;color:#1f6fe0;}',
    '.wt-classic-tab.wt-tab-active{background:#1f6fe0;color:#fff;border-color:#1f6fe0;font-weight:700;}',
    /* —— PortableInfobox 折叠组（.pi-collapse / .pi-collapse-open / .pi-collapse-closed）—— */
    '.pi-collapse > .pi-header, .pi-collapse > .pi-section-header{cursor:pointer;}',
    '.pi-collapse-closed > *:not(.pi-header):not(.pi-section-header){display:none !important;}',
    '.pi-collapse > .pi-header::after{content:" ▾";opacity:.6;font-size:.9em;}',
    '.pi-collapse-closed > .pi-header::after{content:" ▸";}',
    /* —— 「多样式」信息框：一个页面里多个便携信息框 → 合并成一个框 + 可点击页签 —— */
    '.wt-pi-tabs{display:flex;flex-wrap:wrap;gap:4px;margin:0 0 4px;}',
    '.wt-pi-tab{cursor:pointer;font:inherit;font-size:12px;line-height:1.6;padding:2px 9px;border:1px solid #c8d2e6;',
    '  border-radius:11px;background:#f6f8ff;color:#1f6fe0;}',
    '.wt-pi-tab.wt-tab-active{background:#1f6fe0;color:#fff;border-color:#1f6fe0;font-weight:700;}',
    /* 未选中的样式整块隐藏：站点 CSS 常给 .portable-infobox 设了 display:flex，必须 !important 压过 */
    '.wt-pi-tabbed[hidden]{display:none !important;}',
    /* —— 一个信息框里有多个折叠组时的「一键收成一个框」 —— */
    '.wt-collapse-all{display:flex;justify-content:flex-end;margin:0 0 2px;}',
    '.wt-collapse-all-btn{cursor:pointer;font:inherit;font-size:11.5px;padding:1px 8px;border:1px solid #c8d2e6;',
    '  border-radius:10px;background:#f6f8ff;color:#1f6fe0;}',
    '.wt-collapse-all-btn:hover{background:#e8f0ff;}',
    /* —— 导航盒（{{xx导航}}）：整宽 + 不与浮动盒并排 —— */
    '.navbox{width:100% !important;clear:both !important;box-sizing:border-box !important;}',
    /* —— 用 PortableInfobox 做的「导航盒」（.pi-navbox / pi-theme-navbox）：它不是信息框，是通栏横条 ——
          必须整宽、不浮动、不限宽（否则会被当成信息框右浮 42% 宽，看起来就是「导航盒又窄又靠右」）。 */
    '.pi-navbox{width:100% !important;clear:both !important;float:none !important;box-sizing:border-box !important;}',
    '.pi-navbox .portable-infobox,.pi-navbox .infobox,.pi-navbox .pi-infobox,',
    '.portable-infobox.pi-theme-navbox,.infobox.pi-theme-navbox,.pi-infobox.pi-theme-navbox{',
    '  float:none !important;clear:both !important;width:100% !important;max-width:100% !important;',
    '  min-width:0 !important;margin:0 !important;',
    '}',
    /* —— 信息框「多项切换」（pi-panel）：只显示当前一项，其余隐藏 —— */
    '.pi-panel.wt-panel-ready .pi-section-content{display:none !important;}',
    '.pi-panel.wt-panel-ready .pi-section-content.pi-section-active{display:block !important;}',
    '.pi-panel .pi-section-tab{cursor:pointer;}',
    '.pi-panel .pi-section-tab.pi-section-active{font-weight:700;}',
    /* —— mw-collapsible（导航盒 / 可折叠表格）：折叠时只留第一行，与 jquery.makeCollapsible 一致 —— */
    '.mw-collapsible.wt-mwc > .mw-collapsible-toggle{cursor:pointer;user-select:none;}',
    '.mw-collapsible.wt-mwc.wt-mwc-tbl.mw-collapsed > tbody > tr:not(:first-child),',
    '.mw-collapsible.wt-mwc.wt-mwc-tbl.mw-collapsed > tr:not(:first-child){display:none !important;}',
    '.mw-collapsible.wt-mwc:not(.wt-mwc-tbl).mw-collapsed > *:not(.mw-collapsible-toggle){display:none !important;}',
    /* 参考栏里的链接：可点（点击行为由 wireRefLinks 接） */
    ':host(.ref-render) a{cursor:pointer;}',
    ''
  ].join('\n');
  let _interactSheet = null, _interactTried = false;
  function interactSheet() {
    if (_interactSheet || _interactTried) return _interactSheet;
    _interactTried = true;
    try { _interactSheet = new CSSStyleSheet(); _interactSheet.replaceSync(INTERACT_CSS); } catch (e) { _interactSheet = null; }
    return _interactSheet;
  }

  // ---------- 给渲染块补上原站 JS 才会有的交互 ----------
  // 只做三件事：TabberNeue 页签切换、PortableInfobox 折叠组、mw-collapsible 折叠开关。
  // 所有处理都会 stopPropagation —— 否则点「折叠/页签」会冒泡到 #lineEditor 的点击处理，
  // 把这一段变成源码编辑态（那是另一件事，不能混在一起）。
  function decorateRenderInteractions(root) {
    if (!root || !root.querySelectorAll) return false;
    // 逐个装饰、各自兜错：某一项失败不影响其余几项（否则一个异常会让页签/折叠全都不生效）
    const steps = [decorateInfoboxTabs, decoratePiPanels, decorateCollapseGroups, decorateCollapseAll, decorateMwc, decorateTabbers];
    let touched = false;
    for (let i = 0; i < steps.length; i++) {
      try { if (steps[i](root)) touched = true; } catch (e) { /* 装饰只是增强，绝不因此让渲染失败 */ }
    }
    return touched;
  }
  // ---------- 信息框「多项切换」（pi-panel）----------
  //
  // 【站点实况】同一个信息框里放多个形态/变体（本站的 {{小动物信息框}} 就是这样）：
  //   <section class="pi-item pi-panel">
  //     <ul class="pi-section-navigation">
  //       <li class="pi-section-tab pi-section-active" data-ref="0">尖块兽</li>
  //       <li class="pi-section-tab" data-ref="1">叶块兽</li>
  //     </ul>
  //     <div class="pi-section-contents">
  //       <div class="pi-section-content pi-section-active" data-ref="0">…</div>
  //       <div class="pi-section-content" data-ref="1">…</div>
  //     </div>
  //   </section>
  // 原站靠 JS 按 data-ref 切换；Shadow 里没有那个 JS → **所有** pi-section-content 一起显示出来。
  // 这里接管：只显示当前项，点页签（或键盘）切换。
  // ⚠️ CSS 里的隐藏规则限定在 `.wt-panel-ready` 之下，只有我们真的能驱动切换时才加这个类，
  //    否则遇到畸形结构会把内容整块藏掉。
  function decoratePiPanels(root) {
    let touched = false;
    root.querySelectorAll('.pi-panel').forEach((panel) => {
      if (panel._wtDeco) return;
      // 只认自己的页签/内容：嵌套 panel 的内层不能被外层接管
      const mine = (el) => {
        let n = el.parentElement;
        while (n && n !== panel) { if (n.classList && n.classList.contains('pi-panel')) return false; n = n.parentElement; }
        return true;
      };
      const tabs = Array.prototype.filter.call(panel.querySelectorAll('.pi-section-tab'), mine);
      const contents = Array.prototype.filter.call(panel.querySelectorAll('.pi-section-content'), mine);
      if (!tabs.length || !contents.length) return;        // 驱动不了 → 什么都不动，内容照旧显示
      panel._wtDeco = true; touched = true;
      panel.classList.add('wt-panel-ready');
      const refOf = (el, i) => (el.getAttribute('data-ref') != null ? String(el.getAttribute('data-ref')) : String(i));
      const setActive = (ref) => {
        tabs.forEach((t, i) => {
          const on = refOf(t, i) === ref;
          t.classList.toggle('pi-section-active', on);
          t.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        contents.forEach((c, i) => {
          const on = refOf(c, i) === ref;
          c.classList.toggle('pi-section-active', on);
          c.hidden = !on;                                   // 双保险：CSS 与 hidden 一起保证只显示一项
        });
      };
      tabs.forEach((t, i) => {
        const ref = refOf(t, i);
        t.setAttribute('role', 'tab');
        t.setAttribute('tabindex', '0');
        t.style.cursor = 'pointer';
        const act = (e) => {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          setActive(ref); scheduleLanes();
        };
        t.addEventListener('click', act);
        t.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') act(e); });
      });
      // 初始项：服务端标了 pi-section-active 的那个；没有就取第一个页签
      const activeTab = tabs.filter((t) => t.classList.contains('pi-section-active'))[0];
      const activeContent = contents.filter((c) => c.classList.contains('pi-section-active'))[0];
      setActive(activeTab ? refOf(activeTab, 0) : (activeContent ? refOf(activeContent, 0) : refOf(tabs[0], 0)));
    });
    return touched;
  }
  // ---------- 「多样式」信息框：多个框 → 一个框 + 可点击页签 ----------
  //
  // 【站点实况】本站的 {{元素信息框}} 由 Module:信息框 按**多条 data**（每个样式/形态一条）
  // 渲染出**多个** <aside class="portable-infobox">；原站靠 JS 把它们并成一个框、上方是页签。
  // Shadow 里没有那个 JS → 多个框上下堆着全显示出来（＝用户说的「多样式都显示出来」）。
  // 这里自己合并：包一层浮动盒 + 一条页签栏，只显示当前样式；内层框回归普通流。
  function nextElem(el) {
    if (!el) return null;
    if (el.nextElementSibling) return el.nextElementSibling;
    let n = el.nextSibling;                                   // 兼容没有 nextElementSibling 的环境
    while (n && n.nodeType !== 1) n = n.nextSibling;
    return n;
  }
  function decorateInfoboxTabs(root) {
    const boxes = Array.prototype.slice.call(root.querySelectorAll('.portable-infobox, .pi-infobox, .infobox'));
    if (boxes.length < 2) return false;
    const byParent = new Map();
    boxes.forEach((b) => {
      if (b._wtTabbed) return;
      const p = b.parentNode; if (!p) return;
      if (!byParent.has(p)) byParent.set(p, []);
      byParent.get(p).push(b);
    });
    let touched = false;
    byParent.forEach((list, parent) => {
      // 只合并**相邻**的多个信息框（中间夹着正文的就不算同一组「多样式」）
      const runs = [];
      list.forEach((b) => {
        const last = runs[runs.length - 1];
        if (last && nextElem(last[last.length - 1]) === b) last.push(b);
        else runs.push([b]);
      });
      runs.forEach((run) => { if (run.length > 1 && mergeInfoboxRun(parent, run)) touched = true; });
    });
    return touched;
  }
  function mergeInfoboxRun(parent, run) {
    try {
      const wrap = document.createElement('div');
      wrap.className = 'wt-pi-tabs-wrap';
      const bar = document.createElement('div');
      bar.className = 'wt-pi-tabs';
      wrap.appendChild(bar);
      parent.insertBefore(wrap, run[0]);
      const setActive = (i) => {
        run.forEach((b, k) => { b.hidden = (k !== i); b.classList.toggle('wt-pi-active', k === i); });
        Array.prototype.forEach.call(bar.children, (t, k) => t.classList.toggle('wt-tab-active', k === i));
      };
      run.forEach((b, i) => {
        b._wtTabbed = true;
        b.classList.add('wt-pi-tabbed');
        // 页签文字：优先信息框标题，其次第一个分组标题，最后兜底「样式 N」
        const labelEl = b.querySelector('.pi-title, .pi-header, .pi-data-label');
        const label = String((labelEl && labelEl.textContent) || '').trim() || ('样式 ' + (i + 1));
        wrap.appendChild(b);                       // 移进包装盒（原有先后顺序不变）
        const btn = document.createElement('button');
        btn.type = 'button'; btn.className = 'wt-pi-tab';
        btn.textContent = label; btn.title = label;
        btn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); setActive(i); scheduleLanes(); });
        bar.appendChild(btn);
      });
      setActive(0);                                 // 默认显示第一个样式（站点行为）
      return true;
    } catch (e) { return false; }
  }
  function decorateCollapseGroups(root) {
    let touched = false;
    root.querySelectorAll('.pi-collapse').forEach((sec) => {
      if (sec._wtDeco) return;
      sec._wtDeco = true; touched = true;
      // 标题：优先直接子节点；兼容被包一层的情况；再兜底第一个元素子节点
      let head = sec.querySelector(':scope > .pi-header, :scope > .pi-section-header');
      if (!head) head = sec.querySelector('.pi-header, .pi-section-header');
      if (!head) {
        const kids = Array.prototype.slice.call(sec.children).filter((n) => n.nodeType === 1);
        head = kids[0] || null;
      }
      // 折叠 = 把「除标题（或标题所在的那个直接子容器）以外的直接子元素」隐藏掉 →
      // 整组收成一个只剩标题的框。用行内 display 而不是纯 CSS：标题被包过一层时 CSS 选择器会失灵。
      const hideOthers = (closed) => {
        const kids = Array.prototype.slice.call(sec.children).filter((n) => n.nodeType === 1);
        kids.forEach((k) => {
          if (k === head || (head && k.contains && k.contains(head))) return;   // 标题自身 / 装着标题的容器
          if (closed) {
            if (k._wtDisp === undefined) k._wtDisp = k.style.display || '';
            k.style.display = 'none';
          } else if (k._wtDisp !== undefined) {
            k.style.display = k._wtDisp;
            k._wtDisp = undefined;
          }
        });
      };
      const apply = (closed) => {
        sec.classList.toggle('pi-collapse-closed', closed);
        sec.classList.toggle('pi-collapse-open', !closed);
        hideOthers(closed);
      };
      apply(sec.classList.contains('pi-collapse-closed'));   // 服务端就给了 folded 状态 → 保持一致
      sec._wtApply = apply;                                  // 供「折叠全部分组」复用同一套显示/隐藏逻辑
      if (!head) return;
      head.setAttribute('role', 'button');
      head.setAttribute('tabindex', '0');
      head.setAttribute('title', '点击折叠 / 展开');
      const toggle = (e) => {
        if (e) { e.preventDefault(); e.stopPropagation(); }
        const closed = !sec.classList.contains('pi-collapse-closed');
        apply(closed);
        scheduleLanes();                                     // 高度变了 → 重算信息框让位
      };
      head.addEventListener('click', toggle);
      head.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') toggle(e); });
    });
    return touched;
  }
  // 一个信息框里有**多个**折叠组时，给一个「一键收成一个框」的开关：
  // 全部折叠后整个信息框就只剩几行标题（= 折叠回一个框），再点全部展开。
  function decorateCollapseAll(root) {
    let touched = false;
    root.querySelectorAll('.portable-infobox, .pi-infobox, .infobox').forEach((box) => {
      if (box._wtCollapseAll) return;
      const secs = Array.prototype.filter.call(box.querySelectorAll('.pi-collapse'), (s) => !!(s && s._wtApply));
      if (secs.length < 2) return;
      box._wtCollapseAll = true; touched = true;
      const bar = document.createElement('div'); bar.className = 'wt-collapse-all';
      const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'wt-collapse-all-btn';
      const allClosed = () => secs.every((s) => s.classList.contains('pi-collapse-closed'));
      const paint = () => {
        btn.textContent = allClosed() ? '展开全部分组' : '折叠全部分组';
        btn.title = btn.textContent;
      };
      const setAll = (closed) => { secs.forEach((s) => { try { s._wtApply(closed); } catch (e) { } }); paint(); };
      btn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); setAll(!allClosed()); scheduleLanes(); });
      bar.appendChild(btn);
      box.insertBefore(bar, box.firstChild);
      paint();
    });
    return touched;
  }
  function decorateMwc(root) {
    let touched = false;
    root.querySelectorAll('.mw-collapsible').forEach((box) => {
      if (box._wtDeco || box.classList.contains('mw-collapsible-toggle')) return;
      box._wtDeco = true; touched = true;
      if (box.querySelector('.mw-collapsible-toggle')) return;   // 已有站点生成的开关就不插手
      const isTable = (box.tagName === 'TABLE');
      box.classList.add('wt-mwc');
      if (isTable) box.classList.add('wt-mwc-tbl');
      const expandText = box.getAttribute('data-expandtext') || '展开';
      const collapseText = box.getAttribute('data-collapsetext') || '折叠';
      const tog = document.createElement('span');
      tog.className = 'mw-collapsible-toggle';
      tog.setAttribute('role', 'button');
      tog.setAttribute('tabindex', '0');
      const paint = () => {
        const collapsed = box.classList.contains('mw-collapsed');
        tog.textContent = collapsed ? ('[' + expandText + ']') : ('[' + collapseText + ']');
        tog.setAttribute('title', collapsed ? '展开' : '折叠');
      };
      const toggle = (e) => {
        if (e) { e.preventDefault(); e.stopPropagation(); }
        const collapsed = box.classList.toggle('mw-collapsed');
        box.classList.toggle('mw-expanded', !collapsed);
        paint();
        scheduleLanes();          // 高度变了 → 重算信息框让位
      };
      tog.addEventListener('click', toggle);
      tog.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') toggle(e); });
      // 表格：开关放进第一行第一个单元格（与 MediaWiki 的做法一致）；其它：放最前面
      let host = null;
      if (isTable) {
        const firstRow = box.querySelector(':scope > tbody > tr, :scope > tr');
        if (firstRow) host = firstRow.querySelector('th, td') || firstRow;
      }
      if (host) host.insertBefore(tog, host.firstChild);
      else box.insertBefore(tog, box.firstChild);
      paint();
    });
    return touched;
  }
  function decorateTabbers(root) {
    let touched = false;
    root.querySelectorAll('.tabber').forEach((tb) => {
      if (tb._wtDeco) return;
      tb._wtDeco = true; touched = true;
      // 只认「自己的」页签/面板：嵌套 tabber 的内层不能被外层接管
      const mine = (el) => {
        let n = el.parentElement;
        while (n && n !== tb) { if (n.classList && n.classList.contains('tabber')) return false; n = n.parentElement; }
        return true;
      };
      const tabs = Array.prototype.filter.call(tb.querySelectorAll('.tabber__tab'), mine);
      const panels = Array.prototype.filter.call(tb.querySelectorAll('.tabber__panel'), mine);
      if (tabs.length && panels.length) {
        // ⚠️ `wt-tabs-ready` 是「已经能驱动切换」的标记，它一旦生效就会隐藏非活动面板。
        //    所以**必须**在确认有页签可点之后再加 —— 否则遇到「有面板但没有页签」的畸形结构，
        //    我们既不会切换、CSS 又把面板全藏起来，内容会整块消失。
        tb.classList.add('wt-tabs-ready');
        const setActive = (i) => {
          tabs.forEach((a, k) => {
            a.classList.toggle('wt-tab-active', k === i);
            a.setAttribute('aria-selected', k === i ? 'true' : 'false');
          });
          panels.forEach((p, k) => {
            p.classList.toggle('wt-tab-active', k === i);
            p.hidden = (k !== i);      // 双保险：CSS 与 hidden 一起保证只有一个是显示的
          });
        };
        tabs.forEach((a, i) => {
          a.setAttribute('tabindex', '0');
          a.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); setActive(i); scheduleLanes(); });
          a.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.stopPropagation(); setActive(i); }
          });
        });
        setActive(0);                 // 默认显示第一个页签（站点行为）
      } else {
        // 旧版 <tabber>：每个 .tabbertab 自带 title → 自己造一条页签栏
        const classic = Array.prototype.filter.call(tb.querySelectorAll('.tabbertab'), mine);
        if (!classic.length) return;  // 什么都不加：内容原样显示，绝不因我们而消失
        tb.classList.add('wt-tabs-classic');
        const bar = document.createElement('div'); bar.className = 'wt-classic-tabs';
        const setActiveClassic = (i) => {
          classic.forEach((p, k) => { p.classList.toggle('wt-tab-active', k === i); p.hidden = (k !== i); });
          Array.prototype.forEach.call(bar.children, (b, k) => b.classList.toggle('wt-tab-active', k === i));
        };
        classic.forEach((p, i) => {
          const b = document.createElement('button');
          b.type = 'button'; b.className = 'wt-classic-tab';
          b.textContent = p.getAttribute('title') || ('标签 ' + (i + 1));
          b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); setActiveClassic(i); scheduleLanes(); });
          bar.appendChild(b);
        });
        tb.insertBefore(bar, tb.firstChild);
        setActiveClassic(0);
      }
    });
    return touched;
  }
  // 段内是否已渲染出信息框（需要穿透 shadowRoot）
  //
  // ⚠️ 「导航盒」要排除掉：本站的 {{小动物导航}} / {{植物导航}} 这类模板**不是** navbox 表格，
  //    而是 PortableInfobox 做的通栏横条：<div class="pi-navbox"><aside class="portable-infobox pi-theme-navbox">。
  //    它们也匹配 FLOAT_SEL（.portable-infobox），若当成信息框处理就会被右浮 + 限宽 42%，
  //    表现就是「导航盒很窄」。所以浮动盒的挑选必须跳过这类导航用的信息框。
  function isNavStyleInfobox(el) {
    if (!el) return false;
    try {
      if (el.closest && el.closest('.pi-navbox')) return true;
      const cls = String(el.className || '');
      if (/(^|\s)pi-theme-navbox(\s|$)/.test(cls)) return true;
      if (el.getAttribute && el.getAttribute('data-navbox') != null) return true;
    } catch (e) { }
    return false;
  }
  function segFloatBox(si) {
    const host = le().querySelector('.vseg[data-seg="' + si + '"] > .render'); if (!host) return null;
    const root = host.shadowRoot || host;
    if (!root.querySelectorAll) return null;
    const all = root.querySelectorAll(FLOAT_SEL);
    for (let i = 0; i < all.length; i++) {
      if (!isNavStyleInfobox(all[i])) return all[i];      // 跳过导航用的信息框
    }
    return null;
  }

  function buildFloatLayout() {
    // 只需在窗口尺寸变化时重算（宽度变化会影响是否重叠与留白宽度）
    if (!state._floatResizeWired) {
      state._floatResizeWired = true;
      window.addEventListener('resize', () => { scheduleLanes(); });
    }
    scheduleLanes();
  }

  // 渲染块重绘后调用：按实际几何给与浮动盒重叠的段让位。
  // 段是异步 fetch 回来的，故用 rAF 合并多次触发；每次都是幂等的，可反复重入。
  let _laneRaf = 0;
  function scheduleLanes() {
    if (_laneRaf) return;
    _laneRaf = requestAnimationFrame(() => {
      _laneRaf = 0;
      stabilizeFloatLayout();
      layoutTocAgainstFloats();   // 让位重排后，再判一次目录是否被信息框遮挡
    });
  }
  // 让位 padding 会改变段高 → 段高又影响「与浮动盒是否重叠」的判定。
  // 故最多迭代 3 轮：一旦本轮结果与上轮完全一致就提前停（绝大多数页面第 2 轮即稳定）。
  function stabilizeFloatLayout() {
    let sig = '';
    for (let i = 0; i < 3; i++) {
      sig = applyFloatLayout();
      if (i > 0 && sig === state._floatSig) return;   // 已收敛
      state._floatSig = sig;
    }
  }
  // 把「哪些段与哪个浮动盒重叠、重叠处的让位宽度」抽成纯函数，便于单测覆盖。
  // rects: [{ si, top, bottom, left, right }]（浮动盒，视口坐标；si = 承载它的段号）
  // segs:  [{ si, top, bottom, right }]（各段，视口坐标）
  // 返回 Map<segIndex, padPx>：只含需要让位的段；padPx = 段右边界 → 浮动盒左边界 + 间距。
  // 承载浮动盒的那一段**要让位**吗？—— 不要：它在 shadow 内已经真环绕，
  // 而且给它加 padding 会把 shadow 宿主压窄 → 浮动盒自身变窄 → 位置左移 → 来回抖动。
  function computeFloatPads(segs, rects) {
    const pads = new Map();
    segs.forEach((sg) => {
      let pad = 0;
      rects.forEach((fr) => {
        if (fr.si === sg.si) return;                   // 承载段自身不参与（见上）
        // 垂直重叠判定：段顶 < 盒底 且 段底 > 盒顶（有交集即可，1px 容差避免亚像素抖动）
        const ov = Math.min(sg.bottom, fr.bottom) - Math.max(sg.top, fr.top);
        if (ov <= 1) return;
        const p = sg.right - fr.left + FLOAT_GAP;
        if (p > pad) pad = p;
      });
      if (pad > 0) pads.set(sg.si, Math.max(FLOAT_MIN_PAD, Math.round(pad)));
    });
    return pads;
  }
  // 返回本轮结果的指纹（供 stabilizeFloatLayout 判收敛）；无返回值时返回空串。
  // 段内渲染的是「导航盒」吗？（{{xx导航}} / navbox）
  // 这类块在原站是**整宽**横条；出现在文末时应排在信息框下方，而不是被浮动区挤窄。
  // 判定用 makeRenderHost 打的标记（避免每轮都去扫一遍 shadow 子树）。
  const NAV_GAP = 8;              // 导航盒与浮动盒底部的间距（px）
  function segIsNavbox(wrap) {
    return !!(wrap && wrap.querySelector && wrap.querySelector(':scope > .render.has-navbox'));
  }

  function applyFloatLayout() {
    const box = le();
    if (!box || !state.segments.length) return '';
    // 先复位（幂等）：让位留白、导航盒的整宽标记与下移都要先清掉再重算
    box.querySelectorAll('.vseg').forEach((v) => {
      v.classList.remove('beside-float');
      v.classList.remove('vseg-navbox');
      v.style.removeProperty('--box-pad');
      v.style.removeProperty('margin-top');
    });
    // 0) 导航盒段：**先无条件**打上「通栏整宽」标记 —— 与页面上有没有浮动盒无关。
    //    （早先这里写在 rects 判空之后，导致「只有导航盒、没有信息框」的页面
    //     —— 例如纯植物/小动物导航页 —— 永远拿不到全宽处理，正是用户报的那条。）
    const navWraps = new Set();
    box.querySelectorAll('.vseg').forEach((w) => {
      if (segIsNavbox(w)) { w.classList.add('vseg-navbox'); navWraps.add(w); }
    });
    // 1) 收集浮动盒（含其在页面上的真实矩形）
    const rects = [];
    box.querySelectorAll('.vseg').forEach((wrap) => {
      const si = Number(wrap.dataset.seg);
      const fb = segFloatBox(si); if (!fb) return;
      const r = fb.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;      // 未布局 / 隐藏 → 跳过
      rects.push({ si, top: r.top, bottom: r.bottom, left: r.left, right: r.right });
    });
    if (!rects.length) return '';
    // 2) 收集各段矩形（只取真正要判定让位的：非空段 + 活动段；空行段太矮，让位无意义）
    //    顺手给「导航盒段」打上整宽标记：**必须在这里打**，因为下面 rects 为空时会提前 return，
    //    那样只有导航盒、没有信息框的页面（如纯植物页）就永远拿不到全宽处理。
    const segs = [];
    box.querySelectorAll('.vseg').forEach((wrap) => {
      const si = Number(wrap.dataset.seg);
      const seg = state.segments[si];
      if (seg && segIsBlank(seg)) return;
      const r = wrap.getBoundingClientRect();
      segs.push({ si, top: r.top, bottom: r.bottom, right: r.right, nav: navWraps.has(wrap) });
    });
    // 3) 按几何算让位并写 class + 变量（只改属性，不动 DOM 顺序 → 不可能失焦）
    //    · 普通段：右侧留白，让文字绕开浮动盒；
    //    · 导航盒段：**整宽**，改为整体下移到浮动盒底部之下（否则会被信息框压住右半边）。
    const navSet = new Set();
    segs.forEach((sg) => { if (sg.nav) navSet.add(sg.si); });
    const pads = computeFloatPads(segs.filter((sg) => !navSet.has(sg.si)), rects);
    const parts = [];
    pads.forEach((pad, si) => {
      const wrap = box.querySelector('.vseg[data-seg="' + si + '"]'); if (!wrap) return;
      wrap.classList.add('beside-float');
      wrap.style.setProperty('--box-pad', pad + 'px');
      parts.push(si + ':' + pad);
    });
    segs.forEach((sg) => {
      if (!sg.nav) return;
      const wrap = box.querySelector('.vseg[data-seg="' + sg.si + '"]'); if (!wrap) return;
      wrap.classList.add('vseg-navbox');                     // 幂等：上面已加，这里兜底
      let need = 0;
      rects.forEach((fr) => {
        if (fr.si === sg.si) return;
        const ov = Math.min(sg.bottom, fr.bottom) - Math.max(sg.top, fr.top);
        if (ov <= 1) return;                                  // 与浮动盒不重叠 → 本来就在下方
        need = Math.max(need, fr.bottom - sg.top + NAV_GAP);   // 推到浮动盒底部之下
      });
      if (need <= 0) { parts.push('n' + sg.si + ':0'); return; }
      wrap.style.marginTop = Math.round(need) + 'px';
      parts.push('n' + sg.si + ':' + Math.round(need));
    });
    return parts.join(',');
  }

  function rebuildLineEditor() {
    imeReset();   // 组合中的 textarea 会被销毁 → 必须复位，否则 IME.composing 卡住、之后输入全不回写
    state._rebuilding = true;   // 重建期间移除旧活动框会同步触发其 blur；标记它，避免 blur 二次重建退出激活态
    const box = le(); box.innerHTML = '';
    state.segments = computeSegments(state.lines);
    // 段对象是新建的 → 本地渲染缓存随对象一起没了（正确：源码可能已变）
    state.segments.forEach((seg, si) => {
      const isTbl = segIsTable(seg);
      const wrap = document.createElement('div');
      wrap.className = 'vseg' + (si === state.activeSeg ? ' active' : '') + (isTbl ? ' vseg-table' : '');
      wrap.dataset.seg = si;
      if (si === state.activeSeg) {
        wrap.appendChild(makeActiveSeg(seg));
      } else if (isTbl && state.inlineTable && state.inlineTable.si === si && state.tables[state.inlineTable.idx]) {
        // 该表格处于「就地编辑」态 → 直接画可编辑表格 + 浮动在表头的工具栏
        wrap.appendChild(makeTableEditHost(seg, si, state.inlineTable.idx));
      } else {
        if (isTbl) wrap.appendChild(makeTableJumpBar(si)); // 表格块顶部：点击进入单元格编辑
        wrap.appendChild(makeRenderedSeg(seg, si));
      }
      box.appendChild(wrap);
    });
    renderToc();       // 页首目录：按标题字段生成（无标题则不生成）
    renderVisible();
    scheduleLanes();   // 渲染态：按实际几何给与信息框重叠的段让位（渲染完成后会再触发一次）
    state._rebuilding = false;
  }

  // ---------- 行级操作（可视化模式）----------
  // 「实时渲染模式」下每个段落是一个 textarea，没有显式行号。这里的做法是：
  //   1) 先把 textarea 的当前值回写到 state.lines（否则行号会算错）；
  //   2) 用光标偏移算出它落在段内第几行（logicalLineIndex）；
  //   3) 直接改 state.lines，再把光标目标写进 state._pendingCaret / _pendingPoint 后重建编辑器。
  // 由于段落边界会随行增删变化（普通单行段会分裂/合并），重建是唯一可靠的做法。
  function caretLineIdx(ta) {
    const v = ta.value || '';
    const pos = (ta.selectionStart != null) ? ta.selectionStart : v.length;
    let idx = 0;
    for (let i = 0; i < pos && i < v.length; i++) if (v[i] === '\n') idx++;
    return idx;
  }

  // 把 textarea 的当前内容同步回 state.lines（激活段之外的行不受影响）
  function syncActiveSegToLines() {
    const wrap = le().querySelector('.active-line'); if (!wrap) return null;
    const ta = wrap.querySelector('.ta'); if (!ta) return null;
    const seg = state.segments[state.activeSeg]; if (!seg) return null;
    const parts = ta.value.split('\n');
    state.lines.splice(seg.start, seg.end - seg.start + 1, ...parts);
    syncSource();
    return { ta, seg };
  }

  // 把某块的源码替换为新文本，并重建 + 把光标落回 caretLine / caretCol
  function applyBlockEdit(startLine, endLine, newText, caretLine, caretCol) {
    const parts = String(newText).split('\n');
    state.lines.splice(startLine, endLine - startLine + 1, ...parts);
    syncSource(); updateCounters();
    const segs = computeSegments(state.lines);
    // 光标目标行（未指定时取块首行）所在的段，就是重建后要激活的段
    const wantLine = (caretLine == null) ? startLine : Math.max(startLine, Math.min(caretLine, state.lines.length - 1));
    let want = 0;
    for (let i = 0; i < segs.length; i++) {
      if (wantLine >= segs[i].start && wantLine <= segs[i].end) { want = i; break; }
      if (segs[i].start > wantLine) { want = Math.max(0, i - 1); break; }
      want = i;
    }
    // _pendingCaret 必须相对「目标段的起点」计算（段起点不一定等于块起点：
    // 例如把某行上移后，它与上一行合并成新的模板块，段会往前扩）。
    const s2 = segs[want];
    let off = 0;
    for (let l = s2.start; l < wantLine; l++) off += state.lines[l].length + 1;
    off += Math.max(0, Math.min(caretCol || 0, (state.lines[wantLine] || '').length));
    state.activeSeg = want;
    state._pendingPoint = null;
    state._pendingCaret = off;
    rebuildLineEditor();
  }

  // Ctrl+↑ / Ctrl+↓：在光标所在行上/下方插入空行（光标随之落到新行）
  function insertLineAt(where) {
    const sync = syncActiveSegToLines(); if (!sync) return false;
    const { ta, seg } = sync;
    const li = caretLineIdx(ta);
    const gLine = Math.min(seg.end, seg.start + li);
    const parts = ta.value.split('\n');
    if (where === 'above') parts.splice(li, 0, '');
    else parts.splice(li + 1, 0, '');
    const newCaretLine = (where === 'above') ? gLine : gLine + 1;
    applyBlockEdit(seg.start, seg.end, parts.join('\n'), newCaretLine, 0);
    toast(where === 'above' ? '已在当前行上方插入空行' : '已在当前行下方插入空行');
    return true;
  }

  // Ctrl+Shift+Backspace：删除光标所在行（块内只剩一行时，退化为清空该行内容）
  function deleteLineAt() {
    const sync = syncActiveSegToLines(); if (!sync) return false;
    const { ta, seg } = sync;
    const li = caretLineIdx(ta);
    const gLine = Math.min(seg.end, seg.start + li);
    const parts = ta.value.split('\n');
    if (parts.length <= 1) {
      if (parts[0] === '' && state.lines.length > 1) {
        // 段本身就是一个空行 → 直接删掉这一整行
        state.lines.splice(gLine, 1);
        syncSource(); updateCounters();
        state.activeSeg = -1; state._pendingPoint = null; state._pendingCaret = null;
        rebuildLineEditor();
        toast('已删除空行');
        return true;
      }
      applyBlockEdit(seg.start, seg.end, '', gLine, 0);
      toast('已清空该行内容');
      return true;
    }
    parts.splice(li, 1);
    // 删除后光标落到原行的位置（若删的是末行，则落到新的末行）
    const targetLine = Math.min(gLine, seg.start + parts.length - 1);
    applyBlockEdit(seg.start, seg.end, parts.join('\n'), targetLine, 0);
    toast('已删除当前行');
    return true;
  }

  // Ctrl+Shift+↑ / Ctrl+Shift+↓：复制当前行（新行紧跟其后，光标落在副本上）
  function duplicateLineAt() {
    const sync = syncActiveSegToLines(); if (!sync) return false;
    const { ta, seg } = sync;
    const li = caretLineIdx(ta);
    const gLine = Math.min(seg.end, seg.start + li);
    const parts = ta.value.split('\n');
    parts.splice(li + 1, 0, parts[li]);
    applyBlockEdit(seg.start, seg.end, parts.join('\n'), gLine + 1, 0);
    toast('已复制当前行');
    return true;
  }

  // Alt+↑ / Alt+↓：把光标所在行与上/下一行整行交换
  // 做法：先回写段内容，然后在「全文行数组」上交换相邻两行（跨越段边界也成立），
  // 再交给 applyBlockEdit 以全文替换 + 光标定位重建。
  // 这样不必区分"段内交换"与"跨段交换"，逻辑单一可靠。
  function moveLineAt(dir) {
    const sync = syncActiveSegToLines(); if (!sync) return false;
    const { ta, seg } = sync;
    const li = caretLineIdx(ta);
    const gLine = Math.min(seg.end, seg.start + li);
    const to = (dir === 'up') ? gLine - 1 : gLine + 1;
    if (to < 0) { toast('已到最上'); return true; }
    if (to >= state.lines.length) { toast('已到最下'); return true; }
    // 保留列位置：光标在当前逻辑行内的第几个字符
    const pos = (ta.selectionStart != null) ? ta.selectionStart : 0;
    const col = pos - (ta.value.lastIndexOf('\n', pos - 1) + 1);
    const a = state.lines[gLine], b = state.lines[to];
    state.lines[gLine] = b; state.lines[to] = a;
    // 全文替换 + 光标落回移动后的行（applyBlockEdit 里会重新计算段号，跨段也成立）
    applyBlockEdit(0, state.lines.length - 1, state.lines.join('\n'), to, Math.max(0, col));
    toast('已移动当前行');
    return true;
  }

  // 把「块内 newText 里第 caretPos 个字符」换算成 (块内行号, 列号)
  function caretInBlock(newText, caretPos) {
    const before = newText.slice(0, caretPos);
    const lineIdx = (before.match(/\n/g) || []).length;
    const lineStart = before.lastIndexOf('\n') + 1;
    return { line: lineIdx, col: caretPos - lineStart };
  }

  // 换行增强：Enter 时按 wikitext 语法自动续行（列表 * # : ; 与表格 | 的续行/新行）
  // 注意：必须走 applyBlockEdit（与 insertLineAt 等行操作一致），由它重算段边界并重建——
  // 否则会像旧实现那样只改 ta.value + 派发合成 input，导致 seg.end 落后于真实行数，
  // 之后每次 input（中文输入法组合期间尤其频繁）都用陈旧行数 splice，多插出空行
  //（用户反馈的「每个拼音变一行 / 续行失控」）。
  function handleEnterKey(ta, e) {
    // 代次守卫：旧输入框事件一律不接管（见 makeActiveSeg 注释）。
    if (ta.__wtEpoch != null && ta.__wtEpoch !== state.editEpoch) return false;
    const v = ta.value || '';
    const pos = ta.selectionStart;
    if (pos !== ta.selectionEnd) return false;          // 有选区时交给浏览器（=替换选区为换行）
    const seg = state.segments[state.activeSeg]; if (!seg) return false;
    const lineStart = v.lastIndexOf('\n', pos - 1) + 1;
    const line = v.slice(lineStart, pos);
    // 空列表项（只剩前缀、无任何内容）：Enter 结束列表（清空前缀、落到新空行），
    // 避免「一直按 Enter 就一直续行」的失控（用户反馈的「递归每个输入字符」）。
    if (/^\s*[*#:;]+\s*$/.test(line)) {
      e.preventDefault();
      const before = v.slice(0, lineStart);
      const after = v.slice(pos);
      const newText = before + after;                  // 去掉前缀，原列表行变成普通空行
      const c = caretInBlock(newText, before.length);  // 光标落到该空行行首
      applyBlockEdit(seg.start, seg.end, newText, seg.start + c.line, c.col);
      return true;
    }
    let insert = null;
    let m;
    if ((m = line.match(/^(\*+|\#+|\:+|\;+)/))) insert = '\n' + m[1] + ' '; // 列表 / 缩进（续行带一个空格，光标落在 # 之后）
    else if (line.match(/^(\|-.*|\|.*|\!.*)$/)) insert = '\n|-';           // 表格：下一行起
    else if (/^\{\|/.test(line)) insert = '\n|-';
    if (insert == null) {
      // 普通段落：Enter = 新段落（前后各留空行分隔），光标落到新行、
      // 焦点自然切到新建的活动框（rebuildLineEditor 会重建并聚焦）。
      e.preventDefault();
      const before = v.slice(0, pos), after = v.slice(pos);
      const newText = before + '\n\n' + after;            // 在上一框后插入一个空行，再起新行
      const c = caretInBlock(newText, before.length + 2); // 光标落在空行之后的新行行首
      applyBlockEdit(seg.start, seg.end, newText, seg.start + c.line, c.col);
      return true;
    }
    e.preventDefault();
    const before = v.slice(0, pos), after = v.slice(pos);
    const newText = before + insert + after;
    const c = caretInBlock(newText, pos + insert.length);  // 光标落在续行前缀之后
    applyBlockEdit(seg.start, seg.end, newText, seg.start + c.line, c.col);
    return true;
  }

  // ---------- 包裹符号（选中 → [[x]] / {{物品|x}} …）----------
  // 统一入口：能在可视化编辑的 textarea 里做，就在原地做（保留撤销栈）；
  // 否则退化为在纯源码 textarea（#srcSource）或整篇文本上做。
  function applyWrap(w) {
    // 节点态源码框（在 shadow 根里）：必须第一个判，否则会掉进 wrapWholeDoc
    // 把整篇文档都包起来 —— 表现为「在节点框里按包裹快捷键，全文被改了」。
    if (state.activeNode) {
      const box = nodeHostOf(state.activeNode.si);
      const nta = box && box.querySelector('.ta');
      if (nta && isFocused(nta)) { wrapInTextarea(nta, w); return; }
    }
    const wrap = le().querySelector('.active-line');
    const ta = wrap && wrap.querySelector('.ta');
    if (ta && isFocused(ta)) { wrapInTextarea(ta, w); return; }
    const src = $('srcSource');
    if (src && !src.hidden && isFocused(src)) { wrapInTextarea(src, w); return; }
    wrapWholeDoc(w);
  }

  // 元素是否真的持有焦点。**Shadow DOM 陷阱**：节点框的 ta 在 shadow 根内，
  // document.activeElement 拿到的是 shadow **host**（.render），不是 ta 本身 ——
  // 直接用 === 比较永远为 false。
  function isFocused(el) {
    if (!el) return false;
    try { if (document.activeElement === el) return true; } catch (e) { }
    // 逐层穿透 shadow：activeElement.shadowRoot.activeElement
    let a = null;
    try { a = document.activeElement; } catch (e) { a = null; }
    for (let d = 0; a && d < 8; d++) {
      if (a === el) return true;
      let inner = null;
      try { inner = a.shadowRoot ? a.shadowRoot.activeElement : null; } catch (e) { inner = null; }
      if (!inner || inner === a) return false;
      a = inner;
    }
    return false;
  }

  // ---------- 「先脱旧符号，再套新符号」----------
  //
  // 需求：选中一段**已经有完整符号对**的文本时（例如选中 `[[氧气]]`、`'''氧气'''`、
  // `{{物品|氧气}}`，或者只选中括号**里面**的 `氧气`），再按包裹快捷键，
  // 应当**先去掉原有符号**，再套上这次要求的符号 —— 得到 `{{物品|氧气}}`，
  // 而不是 `{{物品|[[氧气]]}}` / `'''[[氧气]]'''` 这种越包越多的嵌套。
  //
  // 判定只用「成对符号表」：内置常用 wikitext 成对符号 + 用户在「⌘ 包裹符号」里
  // 自己配置的符号（open/close 相同也可以，如 '''…'''）。
  const BUILTIN_PAIRS = [
    ['[[', ']]'], ['{{', '}}'], ["'''", "'''"], ["''", "''"],
    ['<nowiki>', '</nowiki>'], ['<ref>', '</ref>'], ['<!--', '-->']
  ];
  function wrapPairs() {
    const out = BUILTIN_PAIRS.map((p) => ({ open: p[0], close: p[1] }));
    (state.wraps || []).forEach((w) => {
      if (w && w.open && w.close) out.push({ open: w.open, close: w.close });
    });
    return out;
  }

  // 动态补充规则：模板调用 `{{名字|值}}` 里，「名字|」也是左符号的一部分。
  // 这样选中整个 `{{游戏版本|build=481350}}` 时能剥成 `build=481350`，
  // 而不是剩下半个模板（`'''游戏版本|build=481350'''`）。
  // （默认包裹表里已有 `{{物品|` / `{{元素|` / `{{图标|`，这条规则覆盖其余模板。）
  function templatePrefixPair(text) {
    if (text.slice(0, 2) !== '{{' || text.slice(-2) !== '}}') return null;
    const bar = text.indexOf('|');
    if (bar < 0) return null;
    return { open: text.slice(0, bar + 1), close: '}}', score: bar + 1 + 2 };
  }

  // 选区**自身**被某个成对符号完整包住？→ 返回包得最紧（符号最长）的那一对。
  // 用「符号总长最大」挑最外层匹配，保证 `'''x'''` 命中 `'''` 而不是 `''`。
  function enclosingPair(text) {
    if (!text) return null;
    let best = templatePrefixPair(text);
    wrapPairs().forEach((p) => {
      if (p.open.length + p.close.length >= text.length) return;   // 里面得留得下内容
      if (text.slice(0, p.open.length) !== p.open) return;
      if (text.slice(text.length - p.close.length) !== p.close) return;
      const score = p.open.length + p.close.length;
      if (!best || score > best.score) best = { open: p.open, close: p.close, score: score };
    });
    // 模板规则里的内容不能为空（`{{x|}}` 不该被剥成空）
    if (best && best.open && best.open.length + best.close.length >= text.length) return null;
    return best;
  }

  // 选区**外沿紧贴**某个成对符号？→ 选中 `[[x]]` 里的 `x` 时，连这对外符号一起替换。
  function surroundingPair(text, s, e) {
    let best = null;
    wrapPairs().forEach((p) => {
      const a = s - p.open.length, b = e + p.close.length;
      if (a < 0 || b > text.length) return;
      if (text.slice(a, s) !== p.open || text.slice(e, b) !== p.close) return;
      const score = p.open.length + p.close.length;
      if (!best || score > best.score) best = { open: p.open, close: p.close, s: a, e: b, score: score };
    });
    return best;
  }

  // 把一段文本上**所有**完整的成对符号逐层剥掉，返回最内层内容。
  // 例：`'''[[氧气]]'''` → `氧气`（多层嵌套也一次剥干净）。
  function unwrapSymbols(text) {
    let inner = String(text == null ? '' : text), removed = null;
    for (let guard = 0; guard < 8; guard++) {
      const p = enclosingPair(inner);
      if (!p) break;
      const nx = inner.slice(p.open.length, inner.length - p.close.length);
      if (!nx.length) break;                 // 只剩符号（如 `[[]]`）→ 别再剥，留个空壳
      inner = nx; removed = removed || p;
    }
    return { inner: inner, removed: removed };
  }

  function wrapInTextarea(ta, w) {
    const open = w.open || '', close = w.close || '';
    const v = ta.value;
    let s = ta.selectionStart, e = ta.selectionEnd;
    if (s == null) { s = e = v.length; }
    if (s > e) { const t = s; s = e; e = t; }
    const selRaw = v.slice(s, e);
    // ① 选区自身带完整符号对 → 逐层剥掉；
    // ② 否则看选区外沿是否紧贴符号对 → 把这对外符号也纳入替换范围（等于一并去掉）。
    let inner = selRaw, from = s, to = e, removed = false;
    const strip = unwrapSymbols(selRaw);
    if (strip.removed) {
      inner = strip.inner; removed = true;
    } else if (selRaw) {
      const sp = surroundingPair(v, s, e);
      if (sp) { from = sp.s; to = sp.e; removed = true; }
    }
    // 未选中：插入「左 + 右」，光标落在中间（caret:'in'）或整体之后（caret:'after'）
    const caretAt = (w.caret === 'after' && !inner) ? 'after' : 'in';
    const tail = v.slice(to);                // 替换范围之后的内容必须原样保留
    const head = v.slice(0, from);
    const nv = head + open + inner + close + tail;
    const midStart = inner ? (from + open.length) : ((caretAt === 'after') ? (from + open.length + close.length) : (from + open.length));
    const midEnd = inner ? (from + open.length + inner.length) : midStart;
    // 用 execCommand 让 Ctrl+Z 还能撤销这次包裹（不可用时退回直接赋值）。
    // 必须走 editTextarea 的闸门：execCommand 会**同步**派发一次 input，
    // 若再手动派发一次，回写就会跑两遍（IME 组合期更是会打断组合）。
    editTextarea(ta, () => {
      let ok = false;
      try {
        ta.setSelectionRange(from, to);
        ok = document.execCommand('insertText', false, open + inner + close);
        if (ok) {                               // insertText 会替换选区并保留尾部，无需再拼接
          if (document.activeElement !== ta) ta.focus();
          ta.setSelectionRange(midStart, midEnd);
        }
      } catch (err) { ok = false; }
      if (!ok) {
        ta.value = nv;
        ta.selectionStart = midStart; ta.selectionEnd = midEnd;
      }
    });
    toast(wrapToast(w, open, close, removed));
  }

  function wrapToast(w, open, close, removed) {
    const name = w.label || (open + '…' + close);
    return removed ? ('已先去掉原有符号，再套上 ' + name) : ('已套上 ' + name);
  }

  // 没有活动编辑框：按「当前选区在整篇源码里的位置」包裹（点选不到行时用）
  function wrapWholeDoc(w) {
    const open = w.open || '', close = w.close || '';
    const full = state.lines.join('\n');
    const selText = String(window.getSelection ? (window.getSelection() || '').toString() : '');
    const target = selText || '';
    if (!target) { toast('请先在文本中添加/选中内容'); return; }
    const at = full.indexOf(target);
    if (at < 0) { toast('未能在源码中定位所选内容'); return; }
    // 同样的「先脱旧符号」规则：整段选区被成对符号包住时，整段替换掉（旧符号一并消失）
    const strip = unwrapSymbols(target);
    const inner = strip.removed ? strip.inner : target;
    const wrapped = open + inner + close;
    const newFull = full.slice(0, at) + wrapped + full.slice(at + target.length);
    const caretLine = newFull.slice(0, at + open.length).split('\n').length - 1;
    const caretCol = (at + open.length) - (newFull.lastIndexOf('\n', at + open.length - 1) + 1);
    applyBlockEdit(0, state.lines.length - 1, newFull, caretLine, caretCol);
    toast(wrapToast(w, open, close, !!strip.removed));
  }


  // ---------- IME（中文/日文输入法）安全输入层（v2.0.5）----------
  //
  // 【症状】中文输入法下打字 + 符号自动补全（成对标点），会出现「输入的字符被递归重复、
  // 多出一段」的脏数据。三个触发点，原先各写各的且覆盖不全：
  //
  //  ① input 事件在**组合期间**回写 model
  //     IME 每更新一次候选就发一次 input，若每次都把 ta.value splice 回 state.lines，
  //     行数会按候选个数被反复改写（表现：每个拼音变一行 / 多插空行）。
  //
  //  ② compositionend 之后浏览器补发的**收尾 input**
  //     Chrome/Edge 在 compositionend 之后还会再发一次 input，且此时 isComposing 已为
  //     false、inputType 可能退化成 insertText → 原判据漏掉它 → 同一份内容回写两遍；
  //     若第二次用的是**已陈旧**的段行号，就会多插出内容。
  //
  //  ③ 用 Enter **确认候选词 / 确认符号补全**
  //     部分 IME（搜狗等）在 keydown 上报的是 isComposing=false、keyCode=13（不是 229），
  //     于是这下 Enter 被当成普通回车 → 触发列表/表格续行（handleEnterKey）→ 凭空多出
  //     一份 `* ` / `|-` 前缀。**用户每确认一个词就多一份 = 看到的「递归输入的字符」**。
  //
  // 统一由本层判定，三处（整段态 / 节点态 / 纯源码态）共用同一份实现 —— 与「控件只有一版」
  // 的原则一致，杜绝两处行为不一致。
  const IME = { composing: false, lastEndAt: 0 };
  const IME_TAIL_MS = 200;   // compositionend 之后仍视为「IME 确认键」的时间窗

  function imeMarkStart() { IME.composing = true; }
  function imeMarkEnd() { IME.composing = false; IME.lastEndAt = Date.now(); }
  function imeReset() { IME.composing = false; }

  /**
   * 该键盘事件是否属于输入法组合（含「刚确认完候选的那一下 Enter」）。
   * 只有一次 compositionend 发生过，lastEndAt 才近；纯英文/符号输入不会触发 compositionend，
   * 因而不会误吞用户真正的回车换行。
   */
  function isImeKeyEvent(e) {
    if (!e) return false;
    if (e.isComposing === true) return true;
    if (e.keyCode === 229) return true;          // 浏览器/IME 占位键
    if (IME.composing) return true;
    // 组合刚刚结束，且这一下是 Enter：它是 IME 的**确认键**，不是用户要换行。
    // 必须交还浏览器默认行为（= 提交候选），程序一律不接管。
    if (e.key === 'Enter' && IME.lastEndAt && (Date.now() - IME.lastEndAt) < IME_TAIL_MS) return true;
    return false;
  }

  /**
   * 把 textarea 的「刷显示」与「回写 model」绑成一对，并挡掉上面全部 IME 陷阱。
   *
   * 三道闸门（缺一不可）：
   *   - 组合闸门：组合期间只刷显示，绝不回写；
   *   - 幂等闸门：值没变就不回写（吞掉 compositionend 之后的收尾 input）；
   *   - 重入闸门：回写过程中若又触发 input（execCommand / 程序化赋值），不再二次回写。
   *
   * @param {HTMLTextAreaElement} ta
   * @param {Function} paint  只刷显示（重设高亮层），组合中也会调用
   * @param {Function} commit 把 ta.value 回写 model（只在非组合、且值真的变了时调用）
   * @returns {{program:Function, flush:Function, reset:Function}}
   */
  function bindImeInput(ta, paint, commit) {
    const noop = { program: (fn) => { if (fn) fn(); }, flush: () => { }, reset: () => { } };
    if (!ta || typeof ta.addEventListener !== 'function') return noop;

    // 幂等：同一个 textarea 反复调用只**换回调**、不重复挂监听。
    // （showSourceMode 每次切模式都会调用一次；旧写法靠给 oninput 直接赋值天然幂等，
    //   换成 addEventListener 后若不幂等，切几次模式就会挂上几份 → 一次输入回写 N 遍。）
    let st = null;
    try { st = ta.__wtImeState; } catch (e) { st = null; }
    if (!st) {
      st = { busy: false, prog: false, lastValue: ta.value, paint: null, commit: null };
      try { ta.__wtImeState = st; } catch (e) { }
    }
    if (paint) st.paint = paint;
    if (commit) st.commit = commit;

    const doPaint = () => { try { if (st.paint) st.paint(); } catch (e) { } };
    const doCommit = (force) => {
      if (st.busy) return;                                      // 重入：不再二次回写
      if (!force && st.prog) return;                            // 程序化写入引发的 input：调用方自己回写
      if (!force && st.lastValue === ta.value) return;          // 幂等：值没变（吞掉收尾 input）
      st.busy = true;
      try { if (st.commit) st.commit(); } finally { st.busy = false; st.lastValue = ta.value; }
    };
    const composingNow = (e) =>
      IME.composing ||
      !!(e && e.isComposing === true) ||
      !!(e && e.inputType && String(e.inputType).indexOf('Composition') >= 0);

    if (!st.wired) {
      st.wired = true;
      ta.addEventListener('compositionstart', () => { imeMarkStart(); });
      ta.addEventListener('compositionupdate', () => { imeMarkStart(); });
      ta.addEventListener('compositionend', () => { imeMarkEnd(); doCommit(true); });
      ta.addEventListener('input', (e) => {
        doPaint();                        // 高亮层始终跟随（只重设 innerHTML，不动 value/光标）
        if (composingNow(e)) return;
        doCommit(false);
      });
      // 组合中被销毁/失焦：必须复位，否则 IME.composing 永远为真 → 之后所有输入都不回写
      ta.addEventListener('blur', () => { if (IME.composing) imeMarkEnd(); });
    }

    let api = null;
    try { api = ta.__wtIme; } catch (e) { api = null; }
    if (api) return api;
    api = {
      /** 程序化改写内容：闸门内改值 + 只回写一次（execCommand 自带的 input 会被吞掉） */
      program(fn) {
        st.prog = true;
        try { if (fn) fn(); } finally { st.prog = false; }
        doPaint();
        doCommit(true);
      },
      flush() { doCommit(true); },
      reset() { st.lastValue = ta.value; }
    };
    try { ta.__wtIme = api; } catch (e) { }
    return api;
  }

  /** 程序化改写 textarea（走 IME 闸门）；没绑过输入层时退化为直接改 + 派发 input */
  function editTextarea(ta, fn) {
    if (!ta) return;
    const api = ta.__wtIme;
    if (api && typeof api.program === 'function') {
      api.program(() => {
        try { fn(); } catch (e) { }
        try { ta.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { }
      });
      return;
    }
    try { fn(); } catch (e) { }
    try { ta.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { }
  }

  // ---------- 全局文本快捷键 ----------
  function bindGlobalTextKeys() {
    document.addEventListener('keydown', (e) => {
      // Esc：优先关掉最上层的弹窗（包裹符号设置 / 快捷键指南）
      if (e.key === 'Escape') {
        // v2.0：节点源码框优先退出（比整段更细的粒度先关）
        if (state.activeNode) { e.preventDefault(); e.stopPropagation(); closeNodeSource(); return; }
        if (closeTopModal()) { e.preventDefault(); e.stopPropagation(); }
        return;   // 没有弹窗时交给活动行自己的 Esc（退出该行编辑）
      }
      // F1 / Alt+/：开合快捷键指南（任何模式下都可用）
      if (e.key === 'F1' || (e.altKey && !e.ctrlKey && !e.metaKey && (e.key === '/' || e.code === 'Slash'))) {
        e.preventDefault();
        const m = $('helpModal');
        if (m && !m.hidden) modalClose(m); else openHelp();
        return;
      }
      // Alt+W：开合「包裹符号」设置弹窗
      if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && e.code === 'KeyW') {
        e.preventDefault();
        const m = $('wrapModal');
        if (m && !m.hidden) { modalClose(m); } else if (m) { renderHelpWrapTable(); modalOpen(m); }
        return;
      }
      // Ctrl+K：开合「搜索 / 跳转」弹窗。搜索框已有焦点时按 Ctrl+K 直接再搜一次。
      if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && (e.code === 'KeyK' || e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        const inp = $('seInput'), m = $('searchModal');
        if (m && !m.hidden && inp && document.activeElement === inp) { runSearch(inp.value); return; }
        if (m && !m.hidden) modalClose(m); else openSearch();
        return;
      }
      // 弹窗打开时，其余全局快捷键一律让路（避免在弹窗输入框里还能触发行操作/包裹）
      if (anyModalOpen()) return;

      // 表格就地编辑的 Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y 撤销-重做：焦点在表格内时拦截，
      // 走表格级撤销栈（覆盖单元格内容 / 结构 / 跨行跨列 / 表头等所有改动）。
      if (state.inlineTable) {
        let el = e.target; let inTbl = false;
        while (el && el !== document && el.nodeType === 1) {
          if (el.classList && el.classList.contains('tbl-edit')) { inTbl = true; break; }
          el = el.parentElement;
        }
        if (inTbl && (e.ctrlKey || e.metaKey) && !e.altKey) {
          const k = (e.key || '').toLowerCase();
          if (k === 'z' && !e.shiftKey) { e.preventDefault(); tableUndo(state.inlineTable.idx); return; }
          if ((k === 'z' && e.shiftKey) || k === 'y') { e.preventDefault(); tableRedo(state.inlineTable.idx); return; }
        }
      }

      // 注意：这里**不再**按「模式」早早 return。渲染栏现在始终可见，源码栏是并列的分栏，
      // 敲键时到底作用在哪一侧由 applyWrap/下面的行操作按**焦点**判断（源码栏里的包裹
      // 由 applyWrap 的 $('srcSource') 分支处理）。若还按模式拦截，源码栏里的快捷键就全废了。
      // 中文输入法组合中别抢键；**含用 Enter 确认候选/符号补全的那一下**（见 isImeKeyEvent）——
      // 否则 Enter 会被当成普通回车 → 列表/表格续行凭空多插一份前缀（「递归输入的字符」）。
      if (isImeKeyEvent(e)) return;

      // 包裹快捷键：优先于行操作，且在任何焦点位置（含 body）都生效
      if (state.wraps.length) {
        const comb = keyStr(e);
        if (comb) {
          const w = state.wraps.find((x) => x.key === comb);
          if (w) { e.preventDefault(); applyWrap(w); return; }
        }
      }

      // 行操作：只在「源码态的输入层」内生效，避免误伤表格单元格等其它输入框。
      // 【两版控件统一】这里必须同时认**整段态**（.active-line 的 ta）与
      // **节点态**（.node-src 的 ta，且它住在 shadow 根里）—— 旧实现只认前者，
      // 于是节点框里按 Ctrl/Alt+↑↓ 完全没有反应，而按钮又能用 → 两版控件行为不一致。
      // 两边都交给同一组操作（stdLineOps 的语义），差异只在作用域（整段 / 节点区间）。
      //
      // 【Shadow DOM 注意】节点框的 ta 在 shadow 根内，事件到达 document 时
      // `e.target` 已被 retarget 成 shadow host（.render）→ 必须用 composedPath()
      // 才能拿到真实的 ta，否则节点态的快捷键永远判不中。
      const evtPath = (typeof e.composedPath === 'function') ? e.composedPath() : null;
      const pathHas = (n) => !!(evtPath && evtPath.indexOf(n) >= 0);
      let isNodeTa = null;
      if (state.activeNode) {
        const box = nodeHostOf(state.activeNode.si);
        const t = box && box.querySelector('.ta');
        if (t && (e.target === t || pathHas(t))) isNodeTa = t;
      }
      const wrapA = le().querySelector('.active-line');
      const taA = wrapA && wrapA.querySelector('.ta');
      const isSegTa = (!isNodeTa && taA && e.target === taA);
      if (!isNodeTa && !isSegTa) return;
      const ta = isNodeTa || taA;
      const meta = state.activeNode;
      const run = (w) => {
        if (isNodeTa) { nodeLineOp(meta, w); return true; }
        if (w === 'above') return insertLineAt('above');
        if (w === 'below') return insertLineAt('below');
        if (w === 'dup') return duplicateLineAt();
        if (w === 'del') return deleteLineAt();
        return false;
      };

      const mod = e.ctrlKey || e.metaKey;
      if (mod && !e.altKey && !e.shiftKey && e.key === 'ArrowUp') { e.preventDefault(); run('above'); return; }
      if (mod && !e.altKey && !e.shiftKey && e.key === 'ArrowDown') { e.preventDefault(); run('below'); return; }
      if (mod && e.shiftKey && !e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) { e.preventDefault(); run('dup'); return; }
      if (mod && e.shiftKey && !e.altKey && (e.key === 'Backspace' || e.key === 'Delete')) { e.preventDefault(); run('del'); return; }
      // Alt+↑↓ 整行上移/下移：跨段语义只在整段态成立，节点态不做（会让区间外的行错位）
      if (!isNodeTa && e.altKey && !mod && !e.shiftKey && e.key === 'ArrowUp') { e.preventDefault(); moveLineAt('up'); return; }
      if (!isNodeTa && e.altKey && !mod && !e.shiftKey && e.key === 'ArrowDown') { e.preventDefault(); moveLineAt('down'); return; }
      // Enter 续行：节点态区间可能只是整段的一部分，applyBlockEdit 的行号换算不适用
      if (!isNodeTa && e.key === 'Enter' && !mod && !e.altKey && !e.shiftKey) { handleEnterKey(ta, e); return; }
    }, true);
  }

  function makeActiveSeg(seg) {
    const wrap = document.createElement('div'); wrap.className = 'active-line';
    // 可见层：语法着色的 <pre>（它决定高度）；输入层：透明文字的 <textarea> 绝对定位覆盖其上。
    // 两层度量完全一致 → 换行点相同 → 光标与可见文字对齐。
    const pre = document.createElement('pre'); pre.className = 'hl';
    const ta = document.createElement('textarea'); ta.className = 'ta'; ta.spellcheck = false; ta.rows = 1;
    ta.value = segText(seg);
    // 代次：本活动框一旦被重建（重建会新建 textarea 并自增 editEpoch），旧框的回写/Enter 一律作废。
    const myEpoch = ++state.editEpoch;
    ta.__wtEpoch = myEpoch;

    // 严格按「排版视觉规则」渲染高亮层：
    //   1) 逐行处理，行间用**真实换行 HL_JOIN('\n')**（不是 <br>）——让高亮层文本与
    //      textarea 的 value 逐字符相同，二者在 pre-wrap 下的换行/行盒规则一致，多行不再「差一行」；
    //   2) 每行末尾补一个 U+200B 零宽字符——它让「空行」和「以 \n 结尾的最后一行」都有真实行盒，
    //      避免空行/末行高度塌陷导致光标偏移；零宽 → 不影响字宽与换行点；
    //   3) 只改颜色、不改字重/字形（见 CSS 注释），保证换行点与 textarea 逐字符一致。
    const renderHl = (text) => {
      pre.innerHTML = text.split('\n').map(hlLine).join(HL_JOIN);
    };
    renderHl(ta.value);

    wrap.appendChild(pre); wrap.appendChild(ta);
    // 行操作按钮：与快捷键一一对应；与**节点级源码框共用同一套实现**（makeEditBar/stdLineOps），
    // 两处按钮的标签、顺序、样式类、点击约定完全一致 —— 不再各写一份。
    // 点击后必须把焦点还给 textarea：mousedown 已阻止默认抢焦点，click 里显式 focus 复位。
    const bar = makeEditBar(
      stdLineOps((w) => {
        if (w === 'above') insertLineAt('above');
        else if (w === 'below') insertLineAt('below');
        else if (w === 'dup') duplicateLineAt();
        else deleteLineAt();
      }),
      null,
      'ln-bar',
      () => { try { ta.focus(); } catch (e) { } }
    );
    wrap.appendChild(bar);
    const sync = () => { renderHl(ta.value); };
    // 把 textarea 当前内容回写 model（用「活段号」state.segments[activeSeg]，避免陈旧段号错位）
    const commit = () => {
      // 代次守卫：旧输入框（已被重建替换、脱离文档）的任何回写都作废，
      // 否则「换行后旧框的收尾 input/compositionend 又把陈旧内容写回」→ 改动递归重复。
      if (ta.__wtEpoch !== state.editEpoch) return;
      const s = state.segments[state.activeSeg]; if (!s) return;
      const parts = ta.value.split('\n');
      state.lines.splice(s.start, s.end - s.start + 1, ...parts);
      syncSource(); updateCounters();
    };
    // IME 安全输入层（v2.0.5）：组合期间只刷高亮、绝不回写 model；compositionend 与
    // 浏览器紧随其后的「收尾 input」只会回写一次（幂等闸门 + 重入闸门）。
    // 与节点态共用同一份实现，两处行为不可能再不一致。
    bindImeInput(ta, sync, commit);
    ta.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); ta.blur(); } });
    ta.addEventListener('blur', () => {
      // 守卫①：重建期间移除旧框触发的 blur → 忽略（否则会 activeSeg=-1 再重建，把刚建的编辑框又退回渲染态）
      if (state._rebuilding) return;
      // 守卫②：代次不符的旧框（已被重建替换、脱离文档）→ 忽略其 blur
      if (ta.__wtEpoch != null && ta.__wtEpoch !== state.editEpoch) return;
      state.activeSeg = -1; rebuildLineEditor();
    });
    setTimeout(() => {
      ta.focus();
      // 重建后把两层的滚动位置对齐（若任一层曾滚动过）
      pre.scrollTop = ta.scrollTop;
      const pt = state._pendingPoint; state._pendingPoint = null;
      let placed = false;
      // ① 优先用**字符级**偏移（activateSeg 从渲染块 __wtMap 反查出来的，精确到被点的那一格）
      if (state._pendingCaret != null) {
        const p = Math.max(0, Math.min(state._pendingCaret, ta.value.length));
        ta.setSelectionRange(p, p); placed = true;
      }
      // ② 次选：重建后的 textarea 上按点击坐标视觉定位（反查失败时的兜底）
      if (!placed && pt) {
        const r = ta.getBoundingClientRect();
        const inside = pt.x >= r.left - 2 && pt.x <= r.right + 2 && pt.y >= r.top - 2 && pt.y <= r.bottom + 2;
        if (inside) { const off = pointToOffset(ta, pt.x, pt.y); if (off != null) { ta.setSelectionRange(off, off); placed = true; } }
      }
      // ③ 都没有 → 段末（既有行为）
      if (!placed) ta.setSelectionRange(ta.value.length, ta.value.length);
      state._pendingCaret = null;
    }, 0);
    return wrap;
  }

  // 把鼠标点击坐标映射为 textarea 内的字符偏移：让光标落在"你点的那一格"，而不是整行行首。
  // 优先用浏览器原生的 caretPositionFromPoint / caretRangeFromPoint（二者严格按实际排版
  // 计算命中位置，天然正确）；均不可用（Firefox 等）时，退化为按「等宽字体 + 文本区实际
  // 宽度」逐行推算的视觉定位，同样遵循 textarea 的换行与行高规则。
  function pointToOffset(ta, x, y) {
    try {
      if (document.caretPositionFromPoint) {
        const p = document.caretPositionFromPoint(x, y);
        if (p && p.offsetNode === ta) return p.offset;
      }
      if (document.caretRangeFromPoint) {
        const r = document.caretRangeFromPoint(x, y);
        if (r && r.startContainer === ta) return r.startOffset;
      }
    } catch (e) { }
    return pointToOffsetFallback(ta, x, y);
  }

  // 退化方案：按 textarea 的实际盒模型与等宽字体度量，逐行推算点击落在第几个字符。
  function pointToOffsetFallback(ta, x, y) {
    try {
      const cs = getComputedStyle(ta);
      const r = ta.getBoundingClientRect();
      const padL = parseFloat(cs.paddingLeft) || 0;
      const padR = parseFloat(cs.paddingRight) || 0;
      const padT = parseFloat(cs.paddingTop) || 0;
      const lh = parseFloat(cs.lineHeight) || (parseFloat(cs.fontSize) * 1.2);
      const avail = Math.max(1, r.width - padL - padR);
      const cw = Math.max(1, charWidth(ta));
      const perLine = Math.max(1, Math.floor((avail + 0.5) / cw)); // 每行可容纳的"字符格"数
      const text = ta.value;
      const relY = y - r.top - padT + ta.scrollTop;
      const relX = x - r.left - padL;
      let line = Math.floor(relY / lh); if (line < 0) line = 0;
      let col = Math.round(relX / cw); if (col < 0) col = 0;
      // 逐行按 perLine 折行，累加得到字符偏移（与 textarea 的软换行规则一致）
      const lines = text.split('\n');
      let off = 0, cur = 0;
      for (let i = 0; i < lines.length; i++) {
        const segs = Math.max(1, Math.ceil(lines[i].length / perLine)); // 该逻辑行占几个视觉行
        if (line < cur + segs) {
          const vi = line - cur;
          return Math.min(off + vi * perLine + col, off + lines[i].length);
        }
        cur += segs; off += lines[i].length + 1;
      }
      return text.length;
    } catch (e) { return null; }
  }

  // 用 canvas 量出当前等宽字体下单字符宽度（用于退化定位的列数换算）
  let _cwCache = null, _cwKey = '';
  function charWidth(el) {
    try {
      const cs = getComputedStyle(el);
      const key = cs.font || (cs.fontSize + ' ' + cs.fontFamily);
      if (_cwCache && _cwKey === key) return _cwCache;
      const cv = document.createElement('canvas');
      const ctx = cv.getContext('2d');
      ctx.font = cs.font || (cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily);
      _cwCache = ctx.measureText('M').width || (parseFloat(cs.fontSize) * 0.6);
      _cwKey = key;
      return _cwCache;
    } catch (e) { return 8; }
  }

  function makeRenderedSeg(seg, si) {
    if (segIsBlank(seg)) return blankRenderHost();   // 空行段 → 直接显示 ↵，不走 API
    const r = renderForSeg(si);
    if (r.html != null) return buildSegHost(si);
    // HTML 还没到：先占位，并登记待渲染（renderVisible 会去取）
    const ph = document.createElement('div'); ph.className = 'render';
    ph.innerHTML = '<span class="render-placeholder">（渲染中…）</span>';
    return ph;
  }

  /**
   * 整段进入编辑态。
   *
   * 【定位】clickLine 之前一律传 seg.start → activateSeg 里算出 off=0 → 光标落在段首，
   * 表现为「点段落下半部分也跳到第一行」。现在改为：
   *   · 若能从点击坐标反查到源码偏移（渲染块有 __wtMap），直接用**字符级**偏移；
   *   · 否则回落到 clickLine 指定的行。
   * 两级都拿不到才落到段末（makeActiveSeg 的既有兜底）。
   */
  function activateSeg(si, clickLine, point) {
    if (si === state.activeSeg) return;
    // 点到别的段 → 退出表格就地编辑（该表格恢复成渲染外观 + 提示条）
    if (state.inlineTable && state.inlineTable.si !== si) state.inlineTable = null;
    const seg = state.segments[si];
    state.activeSeg = si;
    state._pendingPoint = point || null;
    let off = null;
    // ① 字符级：渲染块还在 DOM 上时先反查（必须趁 render 宿主未被重建前查）
    if (HAS_BLK && point && seg) {
      const wrap0 = le().querySelector('.vseg[data-seg="' + si + '"]');
      const h = wrap0 && wrap0.querySelector('.render');
      const root = h ? (h.shadowRoot || h) : null;
      if (root) {
        const v = sourceOffsetAtPoint(root, point.x, point.y, null);
        if (v != null) {
          const rs = segRange(seg);
          off = Math.max(0, Math.min(v - rs[0], segText(seg).length));
        }
      }
    }
    // ② 原子块兜底（**本次的核心修复**）：模板/表格这类段，源码是 `{{…}}` / `{|…|}` 原子，
    //    project() 后不产生任何字符，而服务端展开出一大片文字 → 字符级映射**必然全空**
    //    → ① 拿不到偏移，旧代码就落到 off=0 = **第一行**。
    //    这正是「整个使用原站渲染风格的区域点击都只能得到第一行源代码」的根因。
    //    这里按「点击 y 落在本段渲染盒的垂直比例」估算它对应源码的第几行：
    //    点上半部分 → 靠前的参数行，点下半部分 → 靠后的参数行。
    //    不追求逐字精确（原子块在原理上做不到），但绝不再是「永远第一行」。
    //
    //    ⚠️ 必须排在**行级兜底之前**：click 一路传进来的 clickLine 就是 seg.start，
    //    行级兜底会算出 off=0（= 第一行），把本兜底完全挡住 —— 那等于没修。
    if (off == null && point && seg) off = segOffsetByRatio(si, point);
    // ③ 行级兜底：仅在**没有点击坐标**、但调用方明确给了行号时才用
    //    （click 路径的 clickLine 恒为 seg.start，对它而言这分支只会算出第一行）。
    if (off == null && clickLine != null && seg && clickLine >= seg.start) {
      off = 0;
      for (let l = seg.start; l < clickLine && l <= seg.end; l++) off += state.lines[l].length + 1;
      if (clickLine > seg.end) off = segText(seg).length;
    }
    state._pendingCaret = off;
    rebuildLineEditor();
  }

  /**
   * 原子块（模板/表格）的定位兜底：按垂直比例把点击位置换算成**段内**字符偏移。
   *
   * @returns {number|null} 段内偏移；取不到段几何时返回 null
   */
  function segOffsetByRatio(si, pt) {
    const seg = state.segments[si];
    if (!seg) return null;
    const wrap = le().querySelector('.vseg[data-seg="' + si + '"]');
    if (!wrap) return null;
    const r = wrap.getBoundingClientRect();
    if (!(r.height > 0)) return null;
    const t = Math.max(0, Math.min(1, (pt.y - r.top) / r.height));
    const n = seg.end - seg.start + 1;
    if (n <= 0) return null;
    let line = Math.floor(t * n);
    if (line >= n) line = n - 1;
    let off = 0;
    for (let l = seg.start; l < seg.start + line && l < state.lines.length; l++) off += state.lines[l].length + 1;
    return off;
  }

  /**
   * 命中判定：某个视口坐标该由**哪一段**接管点击。
   *
   * 【为什么不能直接用 e.target.closest('.vseg')】
   * 信息框（浮动盒）会**溢出**它所在的承载段（浮动盒通常比承载段高得多），
   * 溢出部分在视觉上盖住了下方若干段。此时点击重叠区：
   *   · e.target 被 retarget 成承载段的 .render（因为浮层在承载段的 shadow 内）
   *   · 于是点击永远落到**承载段**，被盖住的下方段落**完全点不到**。
   *
   * 修正规则：
   *   1. 找出所有「矩形覆盖该点」的段；
   *   2. 找出所有「矩形覆盖该点」的浮动盒，并判断它是否**溢出了自己的承载段**；
   *   3. 若该点被某个**溢出的**浮层盖住，则把「溢出浮层的所属段」从候选里排除，
   *      点击归还给真正被压住的那个段；
   *   4. 点在浮层承载段范围内时不做修正 → 信息框本身仍可正常点击编辑。
   */
  function hitSegAt(x, y) {
    const box = le();
    if (!box) return null;
    const wraps = [];
    box.querySelectorAll('.vseg').forEach((w) => wraps.push(w));
    if (!wraps.length) return null;
    const inRect = (r) => (r && r.height > 0 && x >= r.left - 1 && x <= r.right + 1 && y >= r.top - 1 && y <= r.bottom + 1);

    // 1) 矩形覆盖该点的段（按文档顺序）
    const hit = [];
    for (const w of wraps) { if (inRect(w.getBoundingClientRect())) hit.push(w); }
    if (!hit.length) return null;

    // 2) 矩形覆盖该点的浮动盒，以及它是否溢出了自己的承载段
    const spilling = [];
    for (const w of wraps) {
      const si = Number(w.dataset.seg);
      const fb = segFloatBox(si);
      if (!fb) continue;
      const fr = fb.getBoundingClientRect();
      if (!inRect(fr)) continue;
      const own = w.getBoundingClientRect();
      // 浮层矩形纵向超出承载段 → 溢出（盖到了别的段头上）
      if (fr.bottom > own.bottom + 1 || fr.top < own.top - 1) spilling.push(si);
    }
    if (!spilling.length) return hit[hit.length - 1];

    // 3) 排除「溢出浮层的所属段」，把点击归还给被压住的段
    const clean = hit.filter((w) => spilling.indexOf(Number(w.dataset.seg)) < 0);
    return clean.length ? clean[clean.length - 1] : hit[hit.length - 1];
  }

  // 点击归还给被覆盖段之后，**坐标本身还在别人的浮层上**。若直接拿它去反查源码偏移，
  // caretPositionFromPoint 命中的是浮层里的文字（属于承载段的 __wtMap），本段的
  // __wtMap 里根本没有那个文本节点 → 反查失败 → 回落行首（= 用户反馈的「跳第一行」）。
  // 修正：保持 y（垂直位置就是用户点的那一行），把 x 挪到浮层左侧的正文区。
  function clampPointToSeg(si, x, y) {
    const wrap = le().querySelector('.vseg[data-seg="' + si + '"]');
    if (!wrap) return { x: x, y: y };
    const r = wrap.getBoundingClientRect();
    if (r.height <= 0) return { x: x, y: y };
    const ny = Math.max(r.top + 2, Math.min(y, r.bottom - 2));
    let nx = x;
    le().querySelectorAll('.vseg').forEach((w) => {
      if (nx !== x) return;
      const fb = segFloatBox(Number(w.dataset.seg));
      if (!fb) return;
      const fr = fb.getBoundingClientRect();
      if (x >= fr.left - 1 && x <= fr.right + 1 && ny >= fr.top - 1 && ny <= fr.bottom + 1) {
        nx = fr.left - 8;
      }
    });
    nx = Math.max(r.left + 4, Math.min(nx, r.right - 4));
    return { x: nx, y: ny };
  }

  function wireLineEditor() {
    const box = le();
    // 捕获阶段先拦链接：渲染块在 Shadow DOM 内，只有在捕获阶段用 composedPath() 才能拿到
    // 真实 <a> 并阻止默认导航（否则当前编辑标签页会被导航走，未保存内容丢失）。
    box.addEventListener('click', (e) => {
      if (handleRenderedLinkClick(e)) { e.stopPropagation(); return; }
    }, true);
    box.addEventListener('click', (e) => {
      // 命中判定走 hitSegAt：**不能**用 e.target.closest('.vseg') ——
      // 信息框溢出区会把点击全部劫持到承载段，导致被覆盖的段落点不到（见 hitSegAt 注释）。
      const v = hitSegAt(e.clientX, e.clientY) || (e.target.closest && e.target.closest('.vseg'));
      if (!v) return;
      if (e.target.closest('a')) return; // 兜底：Light DOM 下的链接（正常不会走到）
      // 目录（TOC）左浮动在正文之上，其矩形会与首段重叠 → hitSegAt 会误判成"点到了段"。
      // 目录自身的点击（含标题行、内边距）一律不进入整段编辑。
      if (e.target.closest && e.target.closest('.wt-toc')) return;
      // 表格就地编辑态：栏内（单元格 / 工具栏）的点击一律交给它自己处理，
      // 否则会再次进入编辑 → 重建 DOM → 正在输入的单元格丢焦点、光标消失
      if (e.target.closest && e.target.closest('.tbl-edit')) return;
      const si = Number(v.dataset.seg); if (si === state.activeSeg) return;
      const seg = state.segments[si];
      // 表格块：点击即**就地**进入单元格编辑（Alt+点击仍走下面的整段源码态）
      if (seg && v.classList.contains('vseg-table') && !e.altKey) { enterTableEdit(si); return; }

      // v2.1（按需求调整回「整段」）：在渲染区**单击**就直接把**整段**变成源码态，
      // 不再先把命中的那一个节点（列表项 / 段落里的一行 / 单元格）单独切出来编辑 ——
      // 那样只会"先显示一行"，想改整段还得再点一次「⤢ 整段」。
      //
      // v2.0 的节点级能力仍然保留：**Alt+单击**精确到被点的那一个节点。
      //
      // ⚠️ 归属校验（v2.0.2）：e.target 与 hitSegAt 判定的段**可能不是同一个**。
      // 点在溢出信息框上时，e.target 被 retarget 成承载段的 .render，composedPath 里
      // 全是承载段渲染树的节点 → 若直接 pickAt，拿到的会是**信息框**的源码区间，
      // 再套到被覆盖段的 si 上就是张冠李戴（clamp 后退化成乱七八糟的区间）。
      // 只有两者同段时才允许节点级定位；否则被覆盖段只做整段激活 ——
      // 那块区域本来就不属于它的可见渲染内容，整段进入编辑才语义正确。
      const hitRender = e.target.closest ? e.target.closest('.render') : null;
      const ownerSeg = hitRender && hitRender.closest ? hitRender.closest('.vseg') : null;
      const sameSeg = ownerSeg && Number(ownerSeg.dataset.seg) === si;
      const pt = { x: e.clientX, y: e.clientY };
      if (HAS_BLK && hitRender && sameSeg && e.altKey) {
        const path = typeof e.composedPath === 'function' ? e.composedPath() : [];
        const hit = WTBlock.pickAt(path, 'line');
        if (hit && hit.el) {
          // 传入点击坐标：节点框据此把光标落到**被点的那一格**，而不是节点首字符
          openNodeSource(si, hit.s, hit.e, hit.kind, false, pt);
          return;
        }
      }
      // 单击（以及 Alt+单击但没命中到具体节点）→ 整段进入源码态；
      // 点击落在溢出浮层上（本段是被覆盖段）→ 坐标要挪到本段自己的正文区，否则反查失败跳首行
      activateSeg(si, seg ? seg.start : null, (hitRender && !sameSeg) ? clampPointToSeg(si, pt.x, pt.y) : pt);
    });
    let tick = null;
    box.addEventListener('scroll', () => { if (tick) return; tick = setTimeout(() => { tick = null; renderVisible(); }, 120); });
  }

  // ========== 节点级「渲染 ⇄ 源码」双向切换（v2.0）==========  //
  // 与 v1.x 的区别：v1.x 只能**整段**切换（点哪行都是把整段变成 textarea）；
  // v2.0 精确到**节点**——点段落里的某个链接 / 某个列表项 / 某个单元格 /
  // 某个信息框，就只把那一条 wikitext 拿出来编辑，其余部分保持渲染。
  //
  // 三条硬约束（决定了这里的实现方式）：
  //  ① **零横向错位**：源码框与它替换的渲染节点在同一个父容器里，用同一套
  //     box 模型与 --seg-px 缩进 → 左右边界天然重合，不产生横向滚动。
  //     绝不「量一次再补 margin」（那是 v1.9.1 syncRenderInset 的教训：不幂等反馈环）。
  //  ② **零布局跳动**：切换前量下渲染节点的高度，源码框以它为 min-height；
  //     再用 FLIP（记录点击点的视口坐标 → 切换后补偿 scrollTop）保证被点的
  //     那行文字仍停在屏幕同一处。下方内容不会被顶下去。
  //  ③ **高亮不丢**：源码框内部就是既有的双层结构（.hl 着色 + .ta 输入），
  //     复用 hlLine/highlightWikitext —— 与整段编辑、纯源码模式**同一套着色器**。
  //
  // 状态：state.activeNode = { si, s, e, kind }（s/e 是**全局字符偏移**）。

  /**
   * 渲染树上的点击坐标 → 源码全局字符偏移。
   *
   * 必须用浏览器原生的 caretPositionFromPoint / caretRangeFromPoint：它按**实际排版**
   * 命中所点的那一个字，天然正确（含软换行、嵌套 span、shadow 穿透）。
   * 拿到文本节点 + 节点内下标后，交给 WTBlock.sourceOffsetAt 换成源码偏移。
   *
   * @param {ShadowRoot|Element} root 渲染块根（annotate 挂过 __wtMap 的那个对象）
   * @param {number} x,y 视口坐标
   * @param {number} fallback 无命中时的兜底偏移（一般是节点起点）
   */
  function sourceOffsetAtPoint(root, x, y, fallback) {
    if (!HAS_BLK) return fallback;
    let node = null, off = 0;
    try {
      if (document.caretPositionFromPoint) {
        const p = document.caretPositionFromPoint(x, y);
        if (p && p.offsetNode) { node = p.offsetNode; off = p.offset; }
      }
      if (!node && document.caretRangeFromPoint) {
        const r = document.caretRangeFromPoint(x, y);
        if (r && r.startContainer) { node = r.startContainer; off = r.startOffset; }
      }
    } catch (e) { }
    if (!node) return fallback;
    // 命中的可能是元素节点（点到了两字之间）→ 向下取第一个文本节点
    if (node.nodeType !== 3) {
      let found = null;
      const walk = (n) => {
        if (found) return;
        for (let i = 0; i < n.childNodes.length; i++) {
          const c = n.childNodes[i];
          if (c.nodeType === 3) { if (c.nodeValue) { found = c; return; } }
          else if (c.nodeType === 1) walk(c);
        }
      };
      if (node.nodeType === 1) walk(node);
      if (!found) return fallback;
      node = found; off = 0;
    }
    const v = WTBlock.sourceOffsetAt(root, node, off, fallback);
    return (v == null) ? fallback : v;
  }

  // 当前打开的节点源码框（DOM 引用，便于回滚与定位）
  // 【必须穿透 shadowRoot】节点框是插在**渲染块的 shadow 根内部**的（见 openNodeSource：
  // 它替换的是 shadow 里的某个渲染节点）。若只对 .vseg 宿主做 querySelector，
  // 一律返回 null —— 于是节点框上的 ⏎+ / +⏎ / 🗑 按钮、以及 commitNodeText
  // 全部静默失效（点按钮没反应、不报错）。这正是「两版控件只有一版能用」的根因之一。
  function nodeHostOf(si) {
    const wrap = le().querySelector('.vseg[data-seg="' + si + '"]'); if (!wrap) return null;
    const shadowHost = wrap.querySelector('.render');
    const root = shadowHost ? (shadowHost.shadowRoot || shadowHost) : wrap;
    return root.querySelector('.node-src');
  }

  /**
   * 把段 si 内 [s,e) 区间的渲染节点换成源码编辑框。
   * @param {number} si     段号
   * @param {number} s,e    全局字符偏移（闭区间外的半开区间 [s,e)）
   * @param {string} kind   节点类型（p/li/cell/link/table…），用于选择编辑粒度
   * @param {boolean} whole true = 强制整段（Alt+点击）
   * @param {Object} pt     点击坐标 {x,y} —— 用于把光标落到被点的那一格
   */
  function openNodeSource(si, s, e, kind, whole, pt) {
    if (!HAS_BLK) return false;
    const seg = state.segments[si];
    if (!seg || segIsBlank(seg)) return false;
    const full = state.lines.join('\n');
    // 夹紧到段内，并去掉首尾换行（避免把相邻段的内容吃掉）
    const rs = segRange(seg);
    s = Math.max(rs[0], Math.min(s, rs[1]));
    e = Math.max(rs[0], Math.min(e, rs[1]));
    if (whole || e <= s) { s = rs[0]; e = rs[1]; }
    // 修剪到整行边界：只切一部分会让 textarea 里出现"半个列表项"这类不可编辑的片段
    const g = trimToLines(full, s, e);
    s = g[0]; e = g[1];
    if (e <= s) return false;

    // 已在编辑同一个节点 → 不重复打开
    if (state.activeNode && state.activeNode.si === si && state.activeNode.s === s) return true;

    // 注意顺序：closeNodeSource 内部会 rebuildLineEditor()，**必须先关旧的再取 DOM**，
    // 否则拿到的 wrap/host 会是已被替换掉的陈旧节点（插入到脱离文档的树上 → 看不见）。
    closeNodeSource();

    const wrap = le().querySelector('.vseg[data-seg="' + si + '"]'); if (!wrap) return false;

    const host = wrap.querySelector('.render');
    if (!host) return false;                      // 还没渲染出来 → 交给整段切换
    const root = host.shadowRoot || host;

    // 找到被点中的那个元素（它此刻还在 DOM 里）
    const target = findNodeEl(root, s, e) || topLevelElements(root)[0];
    if (!target) return false;

    // 【定位】先在**替换之前**把点击坐标换算成源码偏移。
    // 顺序很重要：一旦把 target 摘走，原节点的布局就没了，caretPositionFromPoint
    // 命中的就不再是那个文本节点 → 只能回落行首（用户反馈的「进编辑就跳第一行」）。
    // 原子块（模板/表格）字符级映射为空 → 反查失败。此时不能落回 0（又是第一行），
    // 用垂直比例估算后换算成**节点框内**的光标位置（见 segOffsetByRatio 注释）。
    let srcOff = pt ? sourceOffsetAtPoint(root, pt.x, pt.y, s) : null;
    if (srcOff == null && pt) {
      const ratio = segOffsetByRatio(si, pt);
      if (ratio != null) srcOff = rs[0] + ratio;
    }
    const caret = (srcOff == null) ? 0 : Math.max(0, Math.min(srcOff - s, e - s));

    // ② 零跳动：记录被点节点的几何（高度用作 min-height，top 用作 FLIP 基准）
    const rect = target.getBoundingClientRect();

    // 腾位：把 target 从渲染树里摘出来暂存（不是删除，close 时原样放回）
    const saved = { el: target, parent: target.parentNode, next: target.nextSibling };
    state._nodeSave = saved;
    if (target.parentNode) target.parentNode.removeChild(target);

    const box = makeNodeSourceBox(full.slice(s, e), { si, s, e, kind }, caret);
    // 插到 target 原来的位置（保持内容语义位置，不改变它在段内的先后）
    if (saved.parent) saved.parent.insertBefore(box, saved.next);
    else host.appendChild(box);

    // ① 宽度：与被替换节点同父同宽 —— 只靠 box-sizing + 零横向 margin 继承父级内容盒，
    //    **不给固定 px 宽度**（那会在窗口缩放后错位；v1.9.1 的 marginLeft 反馈环就是这么坏的）。
    // ② 高度：以原节点高度为下限 → 切换时下方内容不会被顶下去
    try {
      const h = Math.max(0, Math.round(rect.height));
      if (h > 0) box.style.minHeight = h + 'px';
    } catch (e) { }

    state.activeNode = { si, s, e, kind, segStart: seg.start, segEnd: seg.end, caret };
    // FLIP：被点内容的顶端仍停在切换前的视口位置
    try {
      const nb = box.getBoundingClientRect();
      const delta = rect.top - nb.top;
      if (Math.abs(delta) > 1) le().scrollTop += delta;
    } catch (e) { }
    box.classList.add('node-src-open');
    return true;
  }

  // 把 [s,e) 修剪到整行边界（不吞掉换行符本身，避免把下一行拉进来）
  function trimToLines(full, s, e) {
    let a = s, b = e;
    while (a > 0 && full.charAt(a - 1) !== '\n') a--;
    while (b < full.length && full.charAt(b) !== '\n') b++;
    return [a, b];
  }

  // 在渲染树里找区间为 [s,e) 的最深元素
  function findNodeEl(root, s, e) {
    let best = null;
    const all = root.querySelectorAll('[data-wt-range]');
    for (let i = 0; i < all.length; i++) {
      const v = all[i].getAttribute('data-wt-range');
      if (!v) continue;
      const p = v.split(':'); const a = Number(p[0]), b = Number(p[1]);
      if (a === s && b === e) { best = all[i]; break; }   // 精确命中优先
      if (!best && a <= s && b >= e && b > a) best = all[i];
    }
    return best;
  }
  function topLevelElements(root) {
    if (root.topLevelElements) return root.topLevelElements();
    const out = [];
    const kids = root.children || [];
    for (let i = 0; i < kids.length; i++) out.push(kids[i]);
    return out;
  }

  /**
   * 统一的行操作控件工厂 —— 整段编辑（.active-line）与节点编辑（.node-src）**共用同一份实现**。
   *
   * 【为什么要统一】此前存在两套并行控件：
   *   · 整段态 .ln-bar：⏎+ / +⏎ / ⧉ / 🗑，操作走 insertLineAt/duplicateLineAt/deleteLineAt（有 toast、有重建）
   *   · 节点态 .node-bar：◀渲染 / ⤢整段 / ⏎+ / +⏎ / 🗑，操作走 nodeLineOp（无 ⧉、无 toast、语义也不一致）
   * 两套的按钮标签、样式类、点击行为各写一份 → 用户看到「两个版本的控件」，
   * 且行为不一致（节点态缺「复制行」，节点态的删除不弹提示）。
   * 现在统一到 makeEditBar()：同一份按钮定义 + 同一份点击约定（mousedown 阻止默认、
   * click 阻止冒泡、执行后把焦点与光标还给输入层），差异只体现在传入的 ops 回调上。
   *
   * @param {Array}  ops   行操作 [{label,title,fn,danger}]
   * @param {Array}  extra 前置按钮（节点态的「◀ 渲染 / ⤢ 整段」）
   * @param {string} cls   容器类名
   * @param {Function} restore 执行后恢复焦点/光标的回调
   */
  function makeEditBar(ops, extra, cls, restore) {
    const bar = document.createElement('div');
    bar.className = cls;
    const mk = (label, title, fn, danger) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'ln-btn' + (danger ? ' danger' : '');
      b.textContent = label; b.title = title;
      // mousedown 阻止默认：否则按钮抢走 textarea 焦点 → 按键处理与光标全丢
      b.addEventListener('mousedown', (ev) => { ev.preventDefault(); ev.stopPropagation(); });
      b.addEventListener('click', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        fn();
        if (restore) { try { restore(); } catch (e) { } }
      });
      return b;
    };
    (extra || []).forEach((x) => bar.appendChild(x));
    ops.forEach((o) => bar.appendChild(mk(o.label, o.title, o.fn, o.danger)));
    return bar;
  }

  // 四个标准行操作（整段与节点同款、同序、同提示）
  function stdLineOps(run) {
    return [
      { label: '⏎+', title: '在上方插入空行（Ctrl+↑）', fn: () => run('above') },
      { label: '+⏎', title: '在下方插入空行（Ctrl+↓）', fn: () => run('below') },
      { label: '⧉', title: '复制当前行（Ctrl+Shift+↑/↓）', fn: () => run('dup') },
      { label: '🗑', title: '删除当前行（Ctrl+Shift+Backspace）', fn: () => run('del'), danger: true }
    ];
  }

  /**
   * 节点源码框：与整段编辑完全同构的双层结构（.hl 着色 + .ta 输入）。
   * 复用 hlLine / highlightWikitext → 语法着色、缩进层级、标题/模板/链接的
   * 差异化样式与其它模式**完全一致**（高亮不会因切换而丢失）。
   * @param {number} caret 初始光标在框内的偏移（**必须**由点击位置算出，见 openNodeSource）
   */
  function makeNodeSourceBox(text, meta, caret) {
    const wrap = document.createElement('div'); wrap.className = 'node-src';
    const pre = document.createElement('pre'); pre.className = 'hl';
    const ta = document.createElement('textarea'); ta.className = 'ta'; ta.spellcheck = false; ta.rows = 1;
    ta.value = text;
    const paint = () => { pre.innerHTML = ta.value.split('\n').map(hlLine).join(HL_JOIN); };
    paint();
    wrap.appendChild(pre); wrap.appendChild(ta);

    // 光标/焦点恢复到「本次点击所对应的位置」，而不是行首。
    // 记下的是**框内偏移**：节点框内容一旦变化（插入/删除行），按行号重新折算，
    // 这样连续点行操作按钮时光标不会莫名其妙跳走。
    const focusAt = (want) => {
      const box = nodeHostOf(meta.si);
      const t = box && box.querySelector('.ta');
      if (!t) return;
      t.focus();
      const p = Math.max(0, Math.min(want == null ? 0 : want, t.value.length));
      try { t.setSelectionRange(p, p); } catch (e) { }
    };
    meta._caret = caret || 0;

    const mkExtra = (label, title, fn) => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'ln-btn'; b.textContent = label; b.title = title;
      b.addEventListener('mousedown', (ev) => { ev.preventDefault(); ev.stopPropagation(); });
      b.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); fn(); });
      return b;
    };
    // 前置：返回渲染 / 展开整段（这两个是节点态**特有**的粒度切换，不属于行操作）
    const backBtn = mkExtra('◀ 渲染', '回到渲染结果（保留刚才的编辑，Esc）', () => { closeNodeSource(); });
    const wholeBtn = mkExtra('⤢ 整段', '把这一段完整展开为源码编辑', () => {
      // 把节点框内的光标位置换算回**全局行号**，展开整段后光标仍落在同一行
      // （而不是像以前那样一律 activateSeg(si, seg.start) → 跳段首）。
      const box = nodeHostOf(meta.si);
      const t = box && box.querySelector('.ta');
      const rel = (t && t.selectionStart != null) ? t.selectionStart : 0;
      const seg = state.segments[meta.si];
      if (!seg) { closeNodeSource(); return; }
      const full = state.lines.join('\n');
      // 节点框内容已被 trimToLines 对齐整行，故 meta.s 一定在行首
      const abs = meta.s + Math.max(0, Math.min(rel, Math.max(0, meta.e - meta.s)));
      // 字符偏移 → 全局行号（WTBlock 提供纯函数；缺失时回落到段首）
      let line = seg.start;
      if (HAS_BLK) {
        try { line = WTBlock.lineIndexOf(WTBlock.lineStarts(full), abs); } catch (e) { line = seg.start; }
      }
      line = Math.max(seg.start, Math.min(line, seg.end));
      closeNodeSource();
      activateSeg(meta.si, line, null);
    });
    // 行操作：与整段态**完全相同**的一套（统一控件的核心）
    const bar = makeEditBar(
      stdLineOps((w) => nodeLineOp(meta, w)),
      [backBtn, wholeBtn],
      'node-bar',
      () => focusAt(meta._caret)
    );
    wrap.appendChild(bar);

    // 回写：把 textarea 内容按 [s,e) 写回 model（**字符级** splice，与行级模型无关）
    const commit = () => {
      const full = state.lines.join('\n');
      if (meta.e > full.length) return;
      // 偏移漂移保护：源码在别处被改过导致区间不再对应当前内容 → 放弃这次回写
      if (full.slice(meta.s, meta.e) !== state._nodeOrigin) { state._nodeOrigin = ta.value; return; }
      const next = full.slice(0, meta.s) + ta.value + full.slice(meta.e);
      state.lines = next.split('\n');
      state._nodeOrigin = ta.value;
      syncSource(); updateCounters();
      // 区间长度变了 → 后续 splice 的 e 要跟着走
      meta.e = meta.s + ta.value.length;
      if (state.activeNode && state.activeNode.si === meta.si) { state.activeNode.s = meta.s; state.activeNode.e = meta.e; }
    };
    state._nodeOrigin = text;
    // 与整段态**同一个**输入层（v2.0.5）：组合期只 paint、不回写；收尾 input 不重复回写。
    bindImeInput(ta, paint, commit);
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeNodeSource(); return; }
      // 行操作快捷键**不在这里**处理：统一交给 bindGlobalTextKeys（它同时认整段态与
      // 节点态，且用 composedPath 定位 shadow 内的 ta）。两处都绑会一次按键触发两次。
    });
    ta.addEventListener('blur', () => {
      // 失焦不自动关闭（用户可能只是去点别处看渲染）；点「◀ 渲染」或按 Esc 才关
    });
    ta.addEventListener('keyup', (e) => {
      // 记住光标：行操作后据此复位（而不是每次都跳到末尾/行首）
      if (ta.selectionStart != null) meta._caret = ta.selectionStart;
    });
    ta.addEventListener('click', () => { if (ta.selectionStart != null) meta._caret = ta.selectionStart; });
    // 初始光标 = 点击所对应的字符（**不是行首**）。
    // 用户反馈「进入编辑状态就跳到第一行」的根因就是这里写死了 setSelectionRange(0,0)。
    setTimeout(() => focusAt(meta._caret), 0);
    return wrap;
  }

  // 节点级行操作：作用在「节点区间」内，而不是整段。
  // 与整段的 insertLineAt/duplicateLineAt/deleteLineAt 语义保持一致（含 toast 提示）。
  function nodeLineOp(meta, where) {
    const box = nodeHostOf(meta.si);
    const ta = box && box.querySelector('.ta');
    if (!ta) return false;
    const v = ta.value, pos = ta.selectionStart != null ? ta.selectionStart : v.length;
    const parts = v.split('\n');
    let li = 0; for (let i = 0; i < pos && i < v.length; i++) if (v.charCodeAt(i) === 10) li++;
    if (li >= parts.length) li = parts.length - 1;
    let caret;
    if (where === 'above') { parts.splice(li, 0, ''); caret = pos + 1; }
    else if (where === 'below') { parts.splice(li + 1, 0, ''); caret = pos + 1; }
    else if (where === 'dup') { parts.splice(li + 1, 0, parts[li]); caret = pos + parts[li].length + 1; }
    else {
      if (parts.length <= 1) { parts[0] = ''; caret = 0; }
      else {
        parts.splice(li, 1);
        // 删除后光标落到被删行的原起始位置
        let base = 0; for (let i = 0; i < li && i < parts.length; i++) base += parts[i].length + 1;
        caret = base;
      }
    }
    const nv = parts.join('\n');
    meta._caret = caret;
    commitNodeText(meta, nv);
    const t2 = nodeHostOf(meta.si) && nodeHostOf(meta.si).querySelector('.ta');
    if (t2) { t2.focus(); try { t2.setSelectionRange(caret, caret); } catch (e) { } }
    const tips = { above: '已在当前行上方插入空行', below: '已在当前行下方插入空行', dup: '已复制当前行', del: parts.length <= 1 && where === 'del' ? '已清空该行内容' : '已删除当前行' };
    if (tips[where]) toast(tips[where]);
    return true;
  }
  // 节点文本变更的统一入口：写回 model + 就地刷新着色 + 通知外层
  function commitNodeText(meta, nv) {
    const box = nodeHostOf(meta.si); if (!box) return;
    const ta = box.querySelector('.ta'), pre = box.querySelector('.hl');
    if (!ta || !pre) return;
    const full = state.lines.join('\n');
    const next = full.slice(0, meta.s) + nv + full.slice(meta.e);
    state.lines = next.split('\n');
    state._nodeOrigin = nv;
    meta.e = meta.s + nv.length;
    ta.value = nv;
    pre.innerHTML = nv.split('\n').map(hlLine).join(HL_JOIN);
    syncSource(); updateCounters();
    if (state.activeNode && state.activeNode.si === meta.si) { state.activeNode.s = meta.s; state.activeNode.e = meta.e; }
  }

  /**
   * 关闭节点源码框 → **局部增量**把该段恢复成渲染态。
   *
   * 【为什么不用 rebuildLineEditor】整页重建有三重代价（用户反馈「退出源码态后
   * 下方未渲染区域部分可用、部分失效」的根因就在这）：
   *   ① `box.innerHTML=''` 把**所有**段连同它们的 shadow 根一起销毁 →
   *      其余段的渲染结果（尤其是需要服务端返回的 transclusion 块）全部退回
   *      「（渲染中…）」占位；重建后只有视口附近的段会被 renderVisible 重新触发，
   *      视口外的段就一直卡在占位状态 —— 表现就是「一部分能用、一部分点了没反应」。
   *   ② 让位计算（applyFloatLayout）、外链重排、坏链标红全部重跑一遍。
   *   ③ 滚动位置与折叠状态被重置。
   *
   * 现在只做三件事：
   *   1. 把暂存的渲染节点原样放回（它一直好好地存在 state._nodeSave 里，没被删）；
   *   2. 只重绘**受影响的那一段**（paintSeg），其余段一个 DOM 节点都不动；
   *   3. 仅当段边界真的变了（增删行导致段集合重算后与打开时不同）才升级为整页重建。
   */
  function closeNodeSource() {
    const an = state.activeNode;
    const saved = state._nodeSave;
    state.activeNode = null; state._nodeSave = null; state._nodeOrigin = null;
    if (!an) return;
    const si = an.si;

    // 段边界是否被编辑改动了？
    // state.segments 在编辑过程中是**陈旧的**（只有 rebuildLineEditor 才重算），
    // 所以必须拿当前 state.lines 现算一份再比对：只要任一段的行范围与旧的不同，
    // 说明增删行让段合并/分裂了 → 段号会平移，只能整页重建。
    const needRebuild = (() => {
      if (an.segStart == null) return false;
      const fresh = computeSegments(state.lines);
      if (fresh.length !== state.segments.length) return true;
      for (let i = 0; i < fresh.length; i++) {
        if (fresh[i].start !== state.segments[i].start || fresh[i].end !== state.segments[i].end) return true;
      }
      return false;
    })();

    if (needRebuild) {
      // 段结构变了（插入/删除行可能让相邻段合并或分裂）→ 段号会平移，只能重建行编辑器
      rebuildLineEditor();
      return;
    }

    // ① 把摘走的渲染节点放回原位（parent/next 是暂存时记下的，此刻仍挂在 shadow 树上）
    //    用 saved.parent 找当前挂载点（就是 box 所在的父容器），原地 replaceChild
    //    → 位置与兄弟顺序完全不变，不产生任何布局抖动，也不需要重新解析 HTML。
    try {
      if (saved && saved.el && saved.parent) {
        const host = saved.parent;
        const box = host.querySelector ? host.querySelector('.node-src') : null;
        if (box) host.replaceChild(saved.el, box);
        else host.insertBefore(saved.el, saved.next || null);
      }
    } catch (e) { /* DOM 已被别处动过 → 交给下面的重绘兜底 */ }

    // ② 只重绘这一段（其余段不动：无占位回退、无重排、无滚动跳动）
    //    ⚠️ 必须**先刷新该段的区间**：段对象是 rebuildLineEditor 时的快照，
    //    seg.cs/ce 仍是旧偏移，而 segText 按行取的是编辑后的新内容 ——
    //    直接 paintSeg 会让 annotate 用错位的区间打标注，点回去就跳错位置。
    //    段号没平移（needRebuild 已确认）→ **原地**更新段对象，不重建任何 DOM。
    try {
      const fresh = computeSegments(state.lines);
      const n = Math.min(fresh.length, state.segments.length);
      for (let i = 0; i < n; i++) {
        const o = state.segments[i], f = fresh[i];
        o.start = f.start; o.end = f.end;
        o.cs = f.cs; o.ce = f.ce;
        o.kind = f.kind; o.level = f.level; o.listKind = f.listKind; o.isTable = f.isTable;
        o._localHtml = undefined;        // 内容变了，本地渲染结果作废
      }
      // 缓存按段文本索引：本段内容已变 → key 自然不命中 → 下面 paintSeg 会重新请求**这一段**
    } catch (e) { /* 刷新失败就退化为只重绘，区间沿用旧值（不致命） */ }
    paintSeg(si);
    // ③ 让位与外链序号可能要跟着新内容调整，但同样只在这一段范围内做
    afterRenderPass();
  }

  // 可视化模式下补齐所有**还没有渲染结果**的段：逐段判断、逐段请求。
  //
  // 【为什么不能按视口懒加载】旧实现给「是否需要请求」加了视口门槛，于是当视口内的段
  // 恰好都能本地渲染时，视口下方那些含 transclusion 的段永远没人去取 → 一直卡在
  // 「（渲染中…）」占位上，点它也没反应（用户反馈的「下方部分可用、部分失效」）。
  // 现在：**只看该段自己有没有结果，不看它在不在视口**。少了任何一段都会变成死区。
  function renderVisible() {
    const needSegs = [];
    le().querySelectorAll('.vseg').forEach((wrap) => {
      const si = Number(wrap.dataset.seg);
      if (si === state.activeSeg) return;
      // 正在就地编辑的表格段：DOM 里是我们自己的可编辑网格，**绝不能**被渲染结果替换掉
      if (state.inlineTable && state.inlineTable.si === si) return;
      const seg = state.segments[si]; if (!seg) return;
      if (segIsBlank(seg)) return;                   // 空行段直接画 ↵，无需请求
      const r = renderForSeg(si);
      if (r.html != null) return;                    // 已有内容（本地或缓存）
      needSegs.push(si);
    });
    if (!needSegs.length) return;
    // paintSeg 内部发现没结果会自己发起本段请求（fetchRenderSeg）
    needSegs.forEach((si) => { try { paintSeg(si); } catch (e) { } });
  }

  function parseBody(key, withTitle) {
    return 'text=' + encodeURIComponent(key) + (withTitle ? '&title=' + encodeURIComponent(state.title) : '');
  }
  function fetchRenderSeg(si) {
    const seg = state.segments[si]; if (!seg) return;
    const key = segText(seg);
    if (state.renderCache[key] !== undefined) { paintSeg(si); return; }
    if (state.pending.has(key)) return;
    state.pending.add(key);
    // variant=zh（不转换）：渲染预览必须与源码同为「不转换」版本，否则预览是转换版、
    // 源码是原文，两边的字对不上（点选定位 / 包裹 / 字符映射全会错位）。
    const url = apiUrl() + '?action=parse&prop=text&contentmodel=wikitext&disablelimitreport=1&disableeditsection=1&format=json' + variantParam();
    const opts = { method: 'POST', credentials: 'omit', headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };
    // 必须带上 title=<页面名>：否则 {{PAGENAME}}/{{FULLPAGENAME}}/{{#ifexist:{{PAGENAME}}}}
    // 会退化成请求页名（"API"），信息框因此收到错误参数；带 title 后与原站一致。
    fetch(url, Object.assign({ body: parseBody(key, true) }, opts))
      .then((r) => r.json())
      .then((j) => {
        // title 异常（重定向/非法标题）时降级重试一次不带 title
        if (j && j.error) return fetch(url, Object.assign({ body: parseBody(key, false) }, opts)).then((r) => r.json()).catch(() => ({}));
        return j;
      })
      .then((j) => {
        const html = (j && j.parse && j.parse.text && j.parse.text['*']) || '';
        state.renderCache[key] = absolutizeHtml(html);
        state.pending.delete(key); paintSeg(si);
      })
      .catch(() => { state.renderCache[key] = ''; state.pending.delete(key); paintSeg(si); });
  }
  function paintSeg(si) {
    const wrap = le().querySelector('.vseg[data-seg="' + si + '"]'); if (!wrap) return;
    if (si === state.activeSeg) return;
    // 正在就地编辑的表格段：不参与渲染替换（否则输入到一半会被渲染结果冲掉）
    if (state.inlineTable && state.inlineTable.si === si) return;
    const seg = state.segments[si]; if (!seg) return;
    const host = buildSegHost(si);
    if (!host) { fetchRenderSeg(si); return; }        // 本段还没结果 → 自己发起请求补齐
    replaceRenderHost(wrap, host);      // 幂等替换：绝不追加出第二份内容
    afterRenderPass(si);                // 只处理这一段（避免每段重绘都全量扫描）
  }

  // 每个非活动段是独立 action=parse 渲染的，wiki.gg 会把裸外链渲染成 class="external autonumber"
  // 且各自从 [1] 重排 → 同一页多个外链全都显示 [1]。这里按文档顺序遍历所有已渲染段，
  // 把 external autonumber 的编号重写为全局递增 [1][2]…（兼容 Shadow DOM：优先查 shadowRoot）。
  function renumberExternalLinks() {
    const box = le(); if (!box) return;
    let seq = 0;
    box.querySelectorAll('.vseg').forEach((wrap) => {
      const si = Number(wrap.dataset.seg);
      if (si === state.activeSeg) return;          // 活动段是源码，不参与重排
      const host = wrap.querySelector('.render'); if (!host) return;
      const root = host.shadowRoot || host;
      root.querySelectorAll('a.external.autonumber').forEach((a) => {
        seq++; a.textContent = '[' + seq + ']';
      });
    });
  }

  // 从渲染出来的 <a> 反推它指向的页面名（用于和我们自己算出的坏链目标比对）。
  // MediaWiki 对"不存在的页面"会给 a.new 且 title="Foo（页面不存在）"；否则退回解析 href 的 /wiki/xxx。
  function targetOfAnchor(a) {
    const t = (a.getAttribute('title') || '').trim();
    let m = t.match(/^(.*?)（页面不存在）$/);
    if (m) return m[1].trim();
    m = t.match(/^(.*?)\(page does not exist\)$/i);
    if (m) return m[1].trim();
    const href = a.getAttribute('href') || '';
    try {
      const u = new URL(href, baseUrl() + '/');
      const mm = u.pathname.match(/\/wiki\/(.+)$/);
      if (mm) return decodeURIComponent(mm[1]).replace(/_/g, ' ');
    } catch (e) { }
    return '';
  }

  // 渲染块内的坏链标红。
  // action=parse 会把"不存在"的页面渲染成 <a class="new">，但原站那条 .new 规则多半写在
  // .mw-body 等选择器下，搬进 Shadow DOM（我们只注入 :host 作用域的样式）后并不生效 →
  // 渲染块里的坏链看着和正常链接一样。这里在每次渲染完成后扫一遍锚点：
  //   ① class 含 new；② 目标命中我们 API 判定的坏链集合 state.badTargets。
  // 命中就加 .bad-link-render 并内联标红 + 波浪下划线（颜色随主题，深浅两套）。
  // 内联样式即使对 Shadow DOM 也生效，无需再往影子树里插样式。
  function markRenderedBadLinks() {
    const box = le(); if (!box) return;
    const dark = (currentTheme() === 'dark');
    const col = dark ? '#ff8086' : '#c92a2f';
    const targets = state.badTargets || new Set();
    box.querySelectorAll('.vseg').forEach((wrap) => {
      const si = Number(wrap.dataset.seg);
      if (si === state.activeSeg) return;              // 活动段是源码，由着色层负责标红
      const host = wrap.querySelector('.render'); if (!host) return;
      const root = host.shadowRoot || host;
      root.querySelectorAll('a').forEach((a) => {
        const isNew = a.classList.contains('new');
        const tgt = targetOfAnchor(a).toLowerCase();
        const known = !!(tgt && targets.has(tgt));
        if (isNew || known) {
          a.classList.add('bad-link-render');
          a.style.setProperty('color', col, 'important');
          a.style.setProperty('text-decoration', 'underline wavy', 'important');
          a.style.setProperty('text-decoration-color', col, 'important');
          a.setAttribute('data-bad-link', isNew ? '目标页面不存在' : '无法解析的链接');
        } else if (a.hasAttribute('data-bad-link')) {
          // 坏链已被修复 / 主题切换：清掉我们加的标红，恢复原站样式
          a.classList.remove('bad-link-render');
          a.style.removeProperty('color');
          a.style.removeProperty('text-decoration');
          a.style.removeProperty('text-decoration-color');
          a.removeAttribute('data-bad-link');
        }
      });
    });
  }

  // ---------- 渲染块里的链接点击行为（v1.8.7）----------
  // 目标：编辑器里点链接时**绝不让当前编辑标签页被导航走**（未保存的编辑会丢）。
  // 内链 → 用加强编辑器在新标签打开；外链 → 弹窗确认；红链 → 打开 wiki 页面。
  //
  // 关键点：渲染块在 Shadow DOM 里，在外层监听器中 e.target 会被 retarget 成 shadow host，
  // 既拿不到真正的 <a>，也拦不住 <a> 的默认导航。必须在**捕获阶段**用 e.composedPath()
  // 找到真实锚点并 preventDefault()（默认导航发生在事件派发之后，此时拦得住）。
  // 只有这两个命名空间**不是**可编辑页面：Special: 是功能页、Media: 直链文件本体。
  // 其余（Template/Category/File/Help/Module/User/Talk/…）都是真实页面 → 一律用编辑器打开。
  const SPECIAL_NS_RE = /^(special|media)$/i;

  // 从一个已解析的 URL 里抽出「本 wiki 的页面名」；抽不到返回 ''（→ 交还浏览器）。
  // 支持漂亮 URL（/wiki/标题）与 index.php?title=标题（含 action=edit 等查询参数）。
  function pageFromUrl(u) {
    let raw = '';
    const m = u.pathname.match(/\/wiki\/(.+)$/);
    if (m) raw = m[1];
    else if (/\/(?:index|api)\.php$/i.test(u.pathname)) {
      const t = u.searchParams && u.searchParams.get('title');
      if (t) raw = t;
    }
    if (!raw) return '';
    try { return decodeURIComponent(raw).replace(/_/g, ' '); } catch (e) { return raw.replace(/_/g, ' '); }
  }

  // 从锚点 title 反推页面名（href 解析不出页面名时的兜底）：MediaWiki 内链一律带 title，
  // 不存在页会带「X（页面不存在）」；含句读/换行的说明性 title 一律不当作页面名。
  function titlePageName(a) {
    let t = (a.getAttribute('title') || '').trim();
    t = t.replace(/[（(]\s*页面不存在\s*[)）]\s*$/, '').replace(/\(page does not exist\)\s*$/i, '').trim();
    if (!t || /[。！？；，、\n]/.test(t)) return '';
    return t;
  }

  // 判断一个渲染出来的 <a> 属于哪一类点击行为：
  //   frag     片段链接：目标为空（#xx）或目标就是**当前页**（或红链带 #xx）→ 页内章内跳转
  //   internal 本 wiki 内容页（/wiki/标题、index.php?title=、或能由 title 反推）→ 用编辑器新标签打开
  //   new      页面不存在（a.new / 我们的坏链标记）→ 打开 wiki 页面，让用户去创建
  //   external 站外链接（含兄弟 wiki 根路径）→ 先弹窗确认
  //   plain    站内非内容页（Special:/Media:）→ 普通新标签打开
  //   anchor   非 http 协议（mailto: 等）→ 交还浏览器默认行为
  // 说明：带片段（#xx）的链接会把 frag 一起带出：
  //   internal + frag → 打开页面后跳该章节；frag → 本页内跳转。
  function currentPageName() { return String(state.title || '').replace(/_/g, ' ').trim(); }
  function anchorKind(a) {
    const raw = a.getAttribute('href') || '';
    if (!raw) return { kind: 'anchor' };
    // 纯锚点 #xx → 页内跳转（MediaWiki 里 [[#xx|yy]] 就是这种）。
    // 只有能命中标题段才当章节链接；否则（如脚注 #cite_note-1）交还浏览器，避免误报。
    if (raw.charAt(0) === '#') {
      const f = raw.slice(1);
      if (!f || resolveFrag(f)) return { kind: 'frag', frag: f };
      return { kind: 'anchor' };
    }
    let u, base;
    try { u = new URL(raw, baseUrl() + '/'); } catch (e) { return { kind: 'anchor' }; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return { kind: 'anchor' };
    try { base = new URL(baseUrl() + '/'); } catch (e) { base = { host: location.host }; }
    const frag = u.hash ? u.hash.slice(1) : '';
    if (u.host !== base.host) return { kind: /\/wiki\//.test(u.pathname) ? 'plain' : 'external', url: u.href };
    let page = pageFromUrl(u);
    if (!page) page = titlePageName(a);              // href 解析不出 → 退回 title
    if (!page) return { kind: 'plain', url: u.href };
    const colon = page.indexOf(':');
    if (colon > 0 && SPECIAL_NS_RE.test(page.slice(0, colon).trim())) return { kind: 'plain', url: u.href };
    const isNew = a.classList.contains('new') || a.hasAttribute('data-bad-link');
    // 目标就是当前页 → 页内跳转（z == 本页）；红链带片段 → 按「本页章节」处理（z 不存在）
    if (frag && page.replace(/_/g, ' ').trim() === currentPageName()) return { kind: 'frag', frag };
    if (isNew) {
      // 红链带片段：仅当本页确有同名标题时才按「本页章节」跳（z 不存在 → 本页 xx）；
      // 否则保持红链语义（打开 wiki 页面去创建），不误报。
      if (frag && resolveFrag(frag)) return { kind: 'frag', frag, selfFallback: true };
      return { kind: 'new', url: u.href, page };
    }
    return { kind: 'internal', url: u.href, page, frag };
  }

  // 全局兜底链路守卫（document 冒泡阶段）：
  //   编辑页里**任何会导航走**的链接点击都拦下来，改走扩展内的打开逻辑 —— 保证当前编辑标签页
  //   永不被导航走（未保存内容不丢）。行内渲染块 / 参考栏的具体处理器在捕获阶段就能命中并
  //   stopPropagation，事件不会冒泡到这里；只有「漏网」的链接才会被这里接住。
  function initLinkGuard() {
    if (document._wtLinkGuard) return;
    document._wtLinkGuard = true;
    document.addEventListener('click', (e) => {
      if (e.defaultPrevented || e.button !== 0) return;
      const path = (typeof e.composedPath === 'function') ? e.composedPath() : [];
      let a = null;
      for (let i = 0; i < path.length; i++) {
        const n = path[i];
        if (n && n.tagName === 'A' && typeof n.getAttribute === 'function') { a = n; break; }
      }
      if (!a) return;
      if ((a.getAttribute('target') || '') === '_blank') return;   // 明确要新标签：放行
      const raw = a.getAttribute('href') || '';
      const info = anchorKind(a);
      if (info.kind === 'frag') { e.preventDefault(); jumpToFrag(info.frag); return; }
      if (info.kind === 'anchor') {
        // 协议链接（mailto: 等）→ 放行；「解析不出」的链接 → 拦下，避免导航走
        if (!raw || raw.charAt(0) === '#' || /^(javascript:|mailto:|tel:|ftp:|irc:)/i.test(raw)) return;
        e.preventDefault();
        const pg = titlePageName(a);
        if (pg) openEditorForPage(pg);
        return;
      }
      e.preventDefault();
      if (info.kind === 'external') { askExternalLink(info.url); return; }
      if (info.kind === 'internal') { openEditorForPage(info.page, info.frag); return; }
      if (info.kind === 'new') { openTab(info.url); toast('「' + (info.page || '该页面') + '」尚不存在，已打开 wiki 页面'); return; }
      openTab(info.url);
    }, false);
  }

  // 在新标签页打开一个 URL（tabs 权限已在 manifest 里；异常时退回 window.open）
  function openTab(url) {
    try {
      chrome.tabs.create({ url, active: true }, () => {
        if (chrome.runtime.lastError) toast('无法打开新标签页：' + chrome.runtime.lastError.message);
      });
    } catch (e) {
      try { window.open(url, '_blank'); } catch (e2) { toast('无法打开链接'); }
    }
  }

  // 用加强编辑器在新标签页打开某个页面。
  // 透传 state.srcTabId（原始 wiki 页的标签 id）：background.js 里 msg.src 优先，
  // 这样新开的编辑页在保存失败时，SAVE_VIA_ORIGINAL 兜底仍能往真正的 wiki 页注入代理。
  function openEditorForPage(page, frag) {
    const t = String(page || '').trim();
    if (!t) return;
    try {
      chrome.runtime.sendMessage({
        type: 'OPEN_EDITOR', title: t,
        server: normalizeServer(state.server), scriptPath: state.scriptPath || '',
        revId: '', src: state.srcTabId || 0, frag: frag || ''
      }, (res) => {
        const err = chrome.runtime.lastError;
        if (err) { toast('打开编辑器失败：' + err.message); return; }
        if (res && res.ok === false) { toast('打开失败：' + (res.error || '未知错误')); return; }
        toast('已在新标签页用加强编辑器打开「' + t + '」' + (frag ? '（并跳到该章节）' : ''));
      });
    } catch (e) { toast('无法与扩展后台通信'); }
  }

  // 给渲染块里的锚点加行为标记：悬停提示「会发生什么」+ 手型光标。
  // 提示文字放进 title（影子树内外都生效），不额外插样式表。
  function annotateRenderedLinks() {
    const box = le(); if (!box) return;
    box.querySelectorAll('.vseg').forEach((wrap) => {
      const si = Number(wrap.dataset.seg);
      if (si === state.activeSeg) return;
      const host = wrap.querySelector('.render'); if (!host) return;
      const root = host.shadowRoot || host;
      root.querySelectorAll('a').forEach((a) => {
        if (!a.getAttribute('href')) return;
        const info = anchorKind(a); const kind = info.kind;
        let tag = '', hint = '';
        if (kind === 'frag') { tag = 'frag'; hint = info.selfFallback ? '章节跳转：目标页不存在，跳本页同名章节' : '章节跳转：在本页内跳到该标题'; }
        else if (kind === 'internal') { tag = 'int'; hint = info.frag ? '用加强编辑器在新标签页打开，并跳到该章节' : '用加强编辑器在新标签页打开（当前编辑页不受影响）'; }
        else if (kind === 'external') { tag = 'ext'; hint = '外部链接：点击后会先弹窗确认'; }
        else if (kind === 'new') { tag = 'new'; hint = '页面尚不存在：点击打开 wiki 页面（可在那里点「创建页面」）'; }
        if (!tag) return;
        if (a.dataset.lkOrig === undefined) a.dataset.lkOrig = a.getAttribute('title') || '';
        if (a.dataset.lk === tag) return;
        a.dataset.lk = tag;
        const base = a.dataset.lkOrig;
        a.title = (base ? base + '\n' : '') + hint;
        a.style.setProperty('cursor', 'pointer');
      });
    });
  }

  // 捕获阶段拦截渲染块里的链接点击（见上方说明）。
  function handleRenderedLinkClick(e) {
    const path = typeof e.composedPath === 'function' ? e.composedPath() : [];
    let a = null;
    for (let i = 0; i < path.length; i++) {
      const n = path[i];
      if (n && n.tagName === 'A' && typeof n.getAttribute === 'function') { a = n; break; }
    }
    if (!a) return false;
    const info = anchorKind(a);
    if (info.kind === 'anchor') return false;   // 非 http 协议等：交还浏览器
    e.preventDefault();
    e.stopPropagation();
    if (info.kind === 'frag') { jumpToFrag(info.frag); if (info.selfFallback) toast('目标页面不存在，已跳到本页同名章节'); return true; }
    if (info.kind === 'external') { askExternalLink(info.url); return true; }
    if (info.kind === 'internal') { openEditorForPage(info.page, info.frag); return true; }
    openTab(info.url);
    if (info.kind === 'new') toast('「' + (info.page || '该页面') + '」尚不存在，已打开 wiki 页面');
    return true;
  }

  function updateCounters() {
    const cb = byteLen(state.lines.join('\n')); const ib = state.initialBytes; const d = cb - ib;
    $('cCur').textContent = cb; $('cInit').textContent = ib;
    $('cDelta').textContent = (d > 0 ? '+' : '') + d;
    $('srcMeta').textContent = state.lines.length + ' 行';
    scheduleBadLinkCheck(); // 编辑后延后重查坏链（防抖，避免每次按键都打 API）
  }

  // ---------- 纯源码模式：整篇语法着色（双层叠加，与可视化活动行同一套度量）----------
  // 着色层 <pre class="hl"><code class="hl-in"> 决定高度并显示颜色；<textarea class="ta">
  // 绝对定位覆盖其上、文字透明只保留光标。两层共享同一组字体/行高/内边距/换行规则（见
  // editor.css .src-wrap）→ 换行点一致 → 光标不漂移。
  // 只有 .ta 产生滚动条；.hl 设 overflow:hidden，滚动时用 transform 平移 .hl-in 跟随，
  // 避免着色层自己的滚动条占掉内容宽度、使两层换行位置不同。
  // 逐行渲染 + 每行末尾补 U+200B：保证空行与末尾行都有真实行盒。
  // 行间用「真实换行 \n」而非 <br>：<br> 与 textarea 的 \n 在行盒模型上并不等价
  // （尾随 <br> 是否产生行盒、<br> 与软换行叠加等因浏览器而异）→ 多行文本会「差一行」。
  // 让着色层文本与 textarea 的 value 逐字符相同（连换行都一样），只把相同字符包上颜色 span，
  // 两层在 pre-wrap 下的换行/行盒规则就完全一致（这也是 Prism / react-simple-code-editor 的通行做法）。
  function srcHl() { return $('srcHl'); }

  function renderSourceHl(text) {
    const inner = srcHl(); if (!inner) return;
    const t = (text == null) ? '' : text;
    inner.innerHTML = t.split('\n').map(hlLine).join(HL_JOIN);
    syncSourceScroll();
  }
  // 把输入层的滚动量同步到着色层（transform 比 scrollTop 更稳：不会触发着色层自身滚动条）
  function syncSourceScroll() {
    const ta = $('srcSource'), inner = srcHl();
    if (!ta || !inner) return;
    inner.style.transform = 'translate(' + (-ta.scrollLeft) + 'px,' + (-ta.scrollTop) + 'px)';
  }

  // ========== 分栏（面板）体系 ==========  //
  //
  // 结构（DOM 次序）： [左槽位] | splitLeft | 主编辑区（渲染）| splitRight | [右槽位]
  //   · 槽位里放「视图」：source = 源码栏、ref = 参考页面栏、ai = DeepSeek 助手栏
  //   · 每个槽位可 × 关闭；两个槽位都开时可按住标题条拖动交换左右
  //   · 视图元素在打开时被**移动**进槽位，关闭时移回 #viewStore（隐藏仓库）——
  //     同一份 DOM（含 textarea 的 IME 状态与全部监听）在开关之间复用，不重建、不丢状态
  //   · 尺寸：所有可见栏（含渲染区）按 paneWeight 等权平分整行；相邻两可见栏之间各一个拖动条
  const PANE_KEY = 'paneLayout';
  const VIEW_DEF = {
    source: { el: 'viewSource', title: '源码' },
    ref: { el: 'viewRef', title: '参考页面' },
    ai: { el: 'viewAi', title: 'AI 助手' }
  };
  const PANE_SIDES = ['left', 'right'];
  // 三个可参与分栏的窗格（DOM 次序：左槽 / 渲染 / 右槽），顺序值决定 flex 排布
  const PANE_ORDER = { left: 10, main: 20, right: 30 };
  function paneEl(id) { return id === 'main' ? $('paneMain') : (id === 'left' ? $('slotLeft') : $('slotRight')); }
  function visiblePanes() {
    const out = [];
    if (state.panes.left) out.push('left');
    if (!state.renderHidden) out.push('main');
    if (state.panes.right) out.push('right');
    return out;
  }
  function resetPaneWeights() { state.paneWeight = { left: 1, main: 1, right: 1 }; }
  // 可见栏按**显示次序**排列（拖动换位后次序会变）
  function orderedPanes() {
    const o = state.paneOrder || PANE_ORDER;
    return visiblePanes().slice().sort((a, b) => ((o[a] || 0) - (o[b] || 0)) || (PANE_ORDER[a] - PANE_ORDER[b]));
  }
  // 栏的中文名（用于拖动提示）：侧栏取当前视图名，主栏固定「文本编辑」
  function paneLabel(id) {
    if (id === 'main') return '文本编辑';
    const n = state.panes[id];
    return (n && VIEW_DEF[n]) ? VIEW_DEF[n].title : '分栏';
  }

  function sideOfView(name) {
    if (state.panes.left === name) return 'left';
    if (state.panes.right === name) return 'right';
    return '';
  }
  function viewOpen(name) { return !!sideOfView(name); }
  function viewNode(name) { const d = VIEW_DEF[name]; return d ? $(d.el) : null; }

  // 打开视图：目标侧被别的视图占着 → 原视图让位到另一侧；另一侧也占着 → 关掉它（回仓库）
  function openView(name, preferSide) {
    if (!VIEW_DEF[name]) return false;
    const side = (preferSide === 'left' || preferSide === 'right') ? preferSide : 'right';
    const at = sideOfView(name);
    if (at === side) { applyPaneLayout(); return true; }
    if (at) state.panes[at] = '';                       // 跨侧移动：先从原侧摘下
    const occ = state.panes[side];
    if (occ && occ !== name) {
      const other = (side === 'left') ? 'right' : 'left';
      if (!state.panes[other]) state.panes[other] = occ;
      else state.panes[side] = '';
    }
    state.panes[side] = name;
    resetPaneWeights();                      // 新开分栏与已有分栏平分空间（等权 → 等宽）
    applyPaneLayout();
    onPaneOpened(name);
    return true;
  }
  function closeView(name) {
    const side = sideOfView(name);
    if (!side) return false;
    state.panes[side] = '';
    resetPaneWeights();                      // 关掉后剩余栏等权填充整行
    applyPaneLayout();
    return true;
  }
  // 是否还有任意侧栏视图打开（源码/参考/AI）
  function anySlotOpen() { return viewOpen('source') || viewOpen('ref') || viewOpen('ai'); }
  // ---------- 渲染区（主编辑区 #paneMain）开关 ----------
  // 顶栏「渲染区」按钮 / 渲染区内 ✕ 共用；状态持久化到 PANE_KEY。
  function setRenderAreaVisible(v) {
    // 规则：所有侧栏都关闭、且渲染区也要关 → 强制保持渲染区可见，避免整页空白。
    if (!v && !anySlotOpen()) {
      v = true;
      toast('已保留渲染区（不能同时关闭所有面板）');
    }
    state.renderHidden = !v;
    resetPaneWeights();                      // 显隐渲染区 = 结构变化 → 剩余栏重新等权平分
    applyPaneLayout();
    savePaneLayout();
  }
  function toggleRenderArea() { setRenderAreaVisible(state.renderHidden); } // 当前隐藏 → 显示

  function toggleView(name, preferSide) {
    if (viewOpen(name)) closeView(name); else openView(name, preferSide);
    savePaneLayout();
  }
  function closePaneOnSide(side) {
    const n = state.panes[side]; if (!n) return;
    closeView(n); savePaneLayout();
    toast('已关闭「' + VIEW_DEF[n].title + '」分栏（主编辑区保留）');
  }
  // 拖动换位：按住**任意栏的单行标题栏**（.pane-drag）拖到另一栏上松手 → 交换两栏的**显示位置**。
  // 三栏（左槽 / 主编辑区 / 右槽）一视同仁，`state.paneOrder` 保存次序。
  // 用事件委托挂在 .layout 上：视图会在槽位与仓库之间搬来搬去，逐元素绑监听会随搬迁失效。
  function initPaneDrag() {
    const layout = $('layout');
    if (!layout || layout._dragWired) return;
    layout._dragWired = true;
    layout.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      const bar = e.target.closest ? e.target.closest('.pane-drag') : null;
      if (!bar) return;
      if (e.target.closest('button,input,select,a,label')) return;    // 不拦截标题栏里的控件
      const own = bar.closest('[data-pane]');
      const mine = own && own.dataset.pane;
      if (!mine) return;
      if (orderedPanes().length < 2) return;                          // 只有一栏时无处可换
      e.preventDefault();
      const startX = e.clientX, startY = e.clientY;
      const onMove = (ev) => {
        bar.classList.toggle('drag-swap', Math.abs(ev.clientX - startX) > 40 || Math.abs(ev.clientY - startY) > 40);
      };
      const onUp = (ev) => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        bar.classList.remove('drag-swap');
        const tgt = document.elementFromPoint(ev.clientX, ev.clientY);
        const dest = tgt && tgt.closest ? tgt.closest('[data-pane]') : null;
        const other = dest && dest.dataset.pane;
        if (!other || other === mine) return;
        const o = state.paneOrder;
        const t = o[mine]; o[mine] = o[other]; o[other] = t;          // 交换显示位置
        applyPaneLayout(); savePaneLayout();
        toast('已交换「' + paneLabel(mine) + '」与「' + paneLabel(other) + '」的位置');
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function applyPaneLayout() {
    const store = $('viewStore');
    // ① 槽位显隐 + 视图搬迁 + 标题
    PANE_SIDES.forEach((side) => {
      const name = state.panes[side];
      const slot = $(side === 'left' ? 'slotLeft' : 'slotRight');
      const body = $(side === 'left' ? 'slotLeftBody' : 'slotRightBody');
      if (!slot || !body) return;
      if (name && VIEW_DEF[name]) {
        const node = viewNode(name);
        slot.hidden = false;
        if (node && node.parentNode !== body) body.appendChild(node);   // 视图自带标题栏（标题 + 特殊按钮 + ✕）
      } else {
        slot.hidden = true;
      }
    });
    // ② 未被任何槽位使用的视图 → 收回隐藏仓库（只移动，不销毁）
    Object.keys(VIEW_DEF).forEach((name) => {
      if (viewOpen(name)) return;
      const node = viewNode(name);
      if (node && store && node.parentNode !== store) store.appendChild(node);
    });

    // ③ 尺寸：所有**可见**栏按权重等分整行（默认等权 → 等宽）。只剩一个栏时自然占满 100%。
    //    渲染区不再特殊（与槽位同吃权重），因此「关掉任意一栏 → 其余填充」自动成立。
    const VIS = orderedPanes();                 // 按显示次序（可被拖动换位改变）
    const O = state.paneOrder || PANE_ORDER;
    const sum = VIS.reduce((s, id) => s + (state.paneWeight[id] || 1), 0) || 1;
    ['left', 'main', 'right'].forEach((id) => {
      const el = paneEl(id); if (!el) return;
      if (VIS.indexOf(id) < 0) { el.style.order = ''; el.style.flex = ''; return; }
      el.style.order = O[id];
      el.style.flex = '0 0 ' + ((state.paneWeight[id] || 1) / sum * 100) + '%';
    });
    const pm = $('paneMain'); if (pm) pm.hidden = !!state.renderHidden;

    // ④ 拖动条：相邻两个可见栏之间**恰好一个**；没有任何相邻栏则全部隐藏。
    const pairs = [];
    for (let i = 0; i + 1 < VIS.length; i++) pairs.push([VIS[i], VIS[i + 1]]);
    [[$('splitLeft'), pairs[0]], [$('splitRight'), pairs[1]]].forEach((it) => {
      const sp = it[0], pair = it[1];
      if (!sp) return;
      if (pair) {
        sp.hidden = false;
        sp._pair = pair;                                          // 拖动时据此决定调整哪两栏
        sp.style.order = (O[pair[0]] + O[pair[1]]) / 2;
      } else { sp.hidden = true; sp._pair = null; }
    });

    syncPaneButtons();
    if (viewOpen('source')) { ensureSourceWired(); syncSourceScroll(); }
    const rb = $('btnRenderPane');
    if (rb) { rb.classList.toggle('on', !state.renderHidden); rb.textContent = '渲染区'; }
    // 没有任何侧栏、且渲染区也被关 → 强制重开渲染区，避免整页空白
    if (state.renderHidden && !anySlotOpen()) setRenderAreaVisible(true);
  }
  function syncPaneButtons() {
    const bs = $('btnSourcePane');
    if (bs) { const on = viewOpen('source'); bs.classList.toggle('on', on); bs.textContent = '源码栏'; }
    const br = $('btnRefPane');
    if (br) { const on = viewOpen('ref'); br.classList.toggle('on', on); br.textContent = '参考栏'; }
    const ba = $('btnAiPane');
    if (ba) { const on = viewOpen('ai'); ba.classList.toggle('on', on); ba.textContent = 'AI 助手'; }
  }
  function savePaneLayout() {
    saveJSON(PANE_KEY, {
      panes: state.panes, wt: state.paneWeight, ord: state.paneOrder,
      sync: state.syncScroll, render: state.renderHidden
    });
  }
  function loadPaneLayout() {
    return new Promise((res) => {
      try {
        chrome.storage.local.get(PANE_KEY, (r) => {
          const v = r && r[PANE_KEY];
          if (v && typeof v === 'object') {
            if (v.panes && typeof v.panes === 'object') {
              // 只接受已知视图名：脏数据/旧数据不会把不存在的视图挂到槽位上
              PANE_SIDES.forEach((s) => { const n = v.panes[s]; state.panes[s] = VIEW_DEF[n] ? n : ''; });
            }
            if (v.wt && typeof v.wt === 'object') {
              ['left', 'main', 'right'].forEach((s) => {
                const n = Number(v.wt[s]);
                if (isFinite(n) && n > 0) state.paneWeight[s] = n;
              });
            }
            if (v.ord && typeof v.ord === 'object') {
              const seen = {};
              ['left', 'main', 'right'].forEach((s) => {
                const n = Number(v.ord[s]);
                // 只用「三个互不相同」的合法次序，脏数据一律回退默认
                if (isFinite(n) && !seen[n]) { state.paneOrder[s] = n; seen[n] = 1; }
                else state.paneOrder[s] = PANE_ORDER[s];
              });
            }
            if (typeof v.sync === 'boolean') state.syncScroll = v.sync;
            if (typeof v.render === 'boolean') state.renderHidden = v.render;
          }
          res();
        });
      } catch (e) { res(); }
    });
  }
  function initPanes() {
    const wire = (id, fn) => { const el = $(id); if (el) el.addEventListener('click', fn); };
    initPaneDrag();                                          // 拖动标题条到另一栏 = 交换两栏显示位置
    // 每个视图标题栏里的 ✕：关闭**该视图**（哪一侧都能关），主编辑区保留
    const closeViewBtn = (name) => {
      if (!viewOpen(name)) return;
      closeView(name); savePaneLayout();
      toast('已关闭「' + VIEW_DEF[name].title + '」分栏（主编辑区保留）');
    };
    wire('viewSourceClose', () => closeViewBtn('source'));
    wire('viewRefClose', () => closeViewBtn('ref'));
    wire('viewAiClose', () => closeViewBtn('ai'));
    wire('btnRenderPane', toggleRenderArea);                 // 顶栏：渲染区开/关
    const pmc = $('paneMainClose'); if (pmc) pmc.addEventListener('click', () => setRenderAreaVisible(false)); // 渲染区内 ✕
    loadPaneLayout().then(() => {
      if (state.panes.left && state.panes.left === state.panes.right) state.panes.right = '';
      applyPaneLayout();
      initPaneSplitters();
      initScrollSync();
    });
  }
  // 拖动条：拖动调整它**相邻两栏**的宽度（在两者间转移宽度，其余栏不变；每栏有最小宽度）。
  // 拖动条与「哪两栏相邻」的对应关系由 applyPaneLayout 写入 sp._pair。
  function initPaneSplitters() {
    ['splitLeft', 'splitRight'].forEach((id) => {
      const sp = $(id);
      if (!sp || sp._wired) return;
      sp._wired = true;
      sp.addEventListener('mousedown', (e) => {
        const pair = sp._pair; if (!pair) return;
        e.preventDefault();
        const VIS = orderedPanes();
        const px = {}; VIS.forEach((pid) => { px[pid] = paneEl(pid).getBoundingClientRect().width; });
        const A = pair[0], B = pair[1];
        const tot = px[A] + px[B];
        const minPx = 90;
        const startX = e.clientX;
        sp.classList.add('dragging'); document.body.classList.add('col-resize');
        const onMove = (ev) => {
          const newA = Math.max(minPx, Math.min(tot - minPx, px[A] + (ev.clientX - startX)));
          const w = {}; VIS.forEach((pid) => { w[pid] = px[pid]; });   // 其余栏保持当前宽度
          w[A] = newA; w[B] = tot - newA;                              // 在 A、B 之间转移宽度
          state.paneWeight = Object.assign({}, state.paneWeight, w);
          applyPaneLayout();
        };
        const onUp = () => {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
          sp.classList.remove('dragging'); document.body.classList.remove('col-resize');
          savePaneLayout();
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
      // 双击拖动条 = 该两栏恢复等宽
      sp.addEventListener('dblclick', () => { resetPaneWeights(); applyPaneLayout(); savePaneLayout(); });
    });
  }
  // 视图打开后的收尾（源码栏要按当前 state.lines 刷一遍并可选聚焦）
  function onPaneOpened(name) {
    if (name === 'source') showSourceView(false);
    if (name === 'ai') ensureAiFrame();
  }
  // AI 助手（免费网页版 DeepSeek）：iframe 懒加载——首次打开该栏时才真正发起请求，避免拖慢启动。
  function ensureAiFrame() {
    const f = $('aiFrame'); if (!f) return;
    if (!f.getAttribute('src')) f.setAttribute('src', 'https://chat.deepseek.com/');
  }

  // ---------- 源码视图（分栏里的整篇 wikitext）----------
  // 输入层只装一次：**恢复上次布局**时分栏已经是开着的，不会走 openView → onPaneOpened，
  // 所以接线必须独立于「打开动作」，否则那种情况下源码栏能看不能改（输入不回写 model）。
  function ensureSourceWired() {
    const ta = $('srcSource'); if (!ta || ta._wired) return;
    ta._wired = true;
    // 源码栏与活动行/节点框共用同一个 IME 安全输入层（组合期不回写、收尾 input 不重复回写）
    bindImeInput(
      ta,
      () => renderSourceHl(ta.value),
      () => {
        state.lines = ta.value.split('\n'); syncSource(); updateCounters();
        // 源码里可能改动了表格 → 重扫表格模型（正在就地编辑表格时跳过，别把它手里的模型换掉）
        if (!state.inlineTable) scheduleRescan();
        // 停止输入 0.5s 后刷新渲染区（仅当渲染区可见），让整篇可视化结果跟上源码改动
        if (state._srcRr) clearTimeout(state._srcRr);
        state._srcRr = setTimeout(() => {
          state._srcRr = null;
          if (!state.renderHidden) { try { rebuildLineEditor(); } catch (e) { } }
        }, 500);
      }
    );
    ta.onscroll = () => { syncSourceScroll(); };
  }
  function showSourceView(focus) {
    ensureSourceWired();
    const ta = $('srcSource'); if (!ta) return;
    const t = state.lines.join('\n');
    if (ta.value !== t) ta.value = t;
    renderSourceHl(t);
    if (focus) setTimeout(() => { try { ta.focus(); } catch (e) { } }, 0);
    if (!state._srcResizeWired) {
      state._srcResizeWired = true;
      window.addEventListener('resize', () => { syncSourceScroll(); });
    }
    syncSourceScroll();
  }
  // 正文侧改了 state.lines → 同步到源码栏（源码栏自己正在打字时不覆盖，避免抢光标）
  function refreshSourceView(force) {
    const ta = $('srcSource'); if (!ta) return;
    if (!force) {
      let focused = false;
      try { focused = (document.activeElement === ta); } catch (e) { }
      if (focused) return;      // 源码栏自己正在打字 → 不覆盖，不抢光标
    }
    const t = state.lines.join('\n');
    if (ta.value === t) return;
    ta.value = t;
    if (viewOpen('source')) renderSourceHl(t);
    syncSourceScroll();
  }
  // 坏链重查完成后，源码栏的着色层也要刷新（红标要跟着更新）
  function repaintSourceHighlight() {
    if (!viewOpen('source')) return;
    const ta = $('srcSource'); if (ta) renderSourceHl(ta.value);
  }

  // ---------- 源码栏 ↔ 渲染栏 滚动同步 ----------
  // 以**段边界**为锚点做分段线性映射：纯按比例在长文/图表混排时会明显跑偏，
  // 用段首作锚点后，两侧的段首基本对齐（段内再线性插值）。
  let _syncLock = 0;
  function syncGuard() {
    const t = Date.now();
    if (_syncLock && t - _syncLock < 140) return false;   // 防回环：程序滚动也会触发对方的 scroll 事件
    _syncLock = t;
    return true;
  }
  function renderAnchors() {
    const box = le(); if (!box) return [];
    const origin = box.getBoundingClientRect().top - box.scrollTop;   // 内容坐标原点
    const out = [];
    box.querySelectorAll('.vseg').forEach((w) => {
      const si = Number(w.dataset.seg);
      const seg = state.segments[si]; if (!seg) return;
      out.push({ y: w.getBoundingClientRect().top - origin, line: seg.start });
    });
    out.sort((a, b) => a.y - b.y);
    return out;
  }
  function initScrollSync() {
    const chk = $('syncScrollChk');
    if (chk && !chk._wired) {
      chk._wired = true;
      chk.checked = !!state.syncScroll;
      chk.addEventListener('change', () => { state.syncScroll = !!chk.checked; savePaneLayout(); });
    }
    const box = le(), ta = $('srcSource');
    if (!box || !ta || box._syncWired) return;
    box._syncWired = true;
    box.addEventListener('scroll', () => {
      if (!state.syncScroll || !viewOpen('source')) return;
      if (!syncGuard()) return;
      renderToSource();
    }, { passive: true });
    ta.addEventListener('scroll', () => {
      if (!state.syncScroll || !viewOpen('source')) return;
      if (!syncGuard()) return;
      sourceToRender();
    }, { passive: true });
  }
  function renderToSource() {
    const box = le(), ta = $('srcSource'); if (!box || !ta) return;
    // 只有「源码栏 + 渲染区」同时可见时才同步（否则单栏浏览会被无意义地带着滚动）
    const pm = $('paneMain'); if (!viewOpen('source') || !pm || state.renderHidden || pm.hidden || pm.clientWidth < 2) return;
    const anchors = renderAnchors(); if (!anchors.length) return;
    const y = box.scrollTop;
    // 顶级对齐：找到「此刻位于视口顶部」的那一段，把对应源码块也置顶（反之见 sourceToRender）
    let a = anchors[0];
    for (let i = 0; i < anchors.length; i++) { if (anchors[i].y <= y + 1) a = anchors[i]; else break; }
    const total = Math.max(1, state.lines.length);
    const sc = ta.scrollHeight || 1;
    ta.scrollTop = Math.max(0, (a.line / total) * sc);
  }
  function sourceToRender() {
    const box = le(), ta = $('srcSource'); if (!box || !ta) return;
    // 只有「源码栏 + 渲染区」同时可见时才同步（否则单栏浏览会被无意义地带着滚动）
    const pm = $('paneMain'); if (!viewOpen('source') || !pm || state.renderHidden || pm.hidden || pm.clientWidth < 2) return;
    const anchors = renderAnchors(); if (!anchors.length) return;
    const total = Math.max(1, state.lines.length);
    const sc = ta.scrollHeight || 1;
    const line = Math.max(0, Math.min(total, (ta.scrollTop / sc) * total));
    let a = anchors[0];
    for (let i = 0; i < anchors.length; i++) { if (anchors[i].line <= line) a = anchors[i]; else break; }
    box.scrollTop = Math.max(0, a.y);
  }

  // ---------- 表格模型：从源码扫出所有表格（正文内就地编辑的数据来源）----------
  // 只维护模型数组，**不再**碰任何 DOM（旧版这里有表格列表/预览面板，已随右侧表格栏一起取消）。
  function rescan() {
    if (!HAS_WT) return;
    // 正在就地编辑表格时**不重扫**：DOM 里的 textarea 正握着当前 model 的 cell 引用，
    // 重扫会把 model 换成新对象，下一次输入就写进已被丢弃的旧模型了。
    if (state.inlineTable) return;
    const list = (WT.extractTables(state.source) || []).map((t) => {
      const model = WT.parseTable(t.raw); WT.cleanPlaceholders(model);
      return { raw: t.raw, start: t.start, end: t.end, model: model, isNew: false, name: model.caption || '' };
    });
    state.tables = list;
    state.selected = state.tables.length ? 0 : -1;
    state.selR = state.selC = -1; state.selRect = null;
  }

  // 新建表格：在光标处插入一个空的 3×3 表格（源码栏光标处 / 渲染区活动段之后），直接进入单元格编辑
  function createNewTable() {
    if (!HAS_WT) { toast('表格引擎未载入，无法新建表格'); return; }
    const model = WT.emptyTable(3, 3);
    const raw = WT.serializeTable(model);
    const rawLines = raw.split('\n');

    // 插入点：源码栏聚焦 → 其光标处；渲染区活动段 → 其后；都没有 → 文末
    const ta = $('srcSource');
    let viaSource = false;
    try { viaSource = !!(ta && document.activeElement === ta); } catch (e) {}
    let anchor, leadN = 0, trailN = 0;
    if (viaSource) {
      const pos = ta.selectionStart || 0;
      const before = ta.value.slice(0, pos), after = ta.value.slice(pos);
      const leadNl = (before.length && !before.endsWith('\n')) ? 1 : 0;
      const trailNl = (after.length && !after.startsWith('\n')) ? 1 : 0;
      ta.value = before + (leadNl ? '\n' : '') + raw + (trailNl ? '\n' : '') + after;
      state.lines = ta.value.split('\n'); syncSource(); updateCounters();
      // 光标保留在插入的空表格之后（不因改写 value 而跳到文末），继续保持源码栏激活状态
      const caretPos = before.length + (leadNl ? 1 : 0) + raw.length;
      try { ta.focus(); ta.setSelectionRange(caretPos, caretPos); } catch (e) { }
      anchor = before.split('\n').length - 1 + leadNl;
      leadN = leadNl; trailN = trailNl;
    } else {
      anchor = state.activeSeg >= 0 ? state.segments[state.activeSeg].end + 1 : state.lines.length;
      // 表格是块级元素：插入点前后若紧邻非空内容，各补一个空行分隔
      leadN = (anchor > 0 && state.lines[anchor - 1] != null && state.lines[anchor - 1].trim() !== '') ? 1 : 0;
      trailN = (anchor < state.lines.length && state.lines[anchor] != null && state.lines[anchor].trim() !== '') ? 1 : 0;
      state.lines.splice(anchor, 0, ...(leadN ? [''] : []), ...rawLines, ...(trailN ? [''] : []));
      syncSource(); updateCounters();
    }
    state.segments = computeSegments(state.lines);
    // 直接为新表建**独立** entry（不走 rescan）：rescan 在 inlineTable 时早退会漏建，
    // 且两个相同空表会被 findTableIndexForSeg 按 raw 误匹配成「重复」。新建表永远指向自己的模型，
    // 因此哪怕正文里已有内容完全相同的表格，新插入的这个也不会被当成已有表的副本。
    const newModel = WT.parseTable(raw); WT.cleanPlaceholders(newModel);
    const entry = { raw, start: anchor, end: anchor + rawLines.length - 1, model: newModel, isNew: true, name: '' };
    state.tables.push(entry);
    const newIdx = state.tables.length - 1;
    let si = -1;
    for (let i = 0; i < state.segments.length; i++) {
      if (anchor >= state.segments[i].start && anchor <= state.segments[i].end) { si = i; break; }
    }
    if (si >= 0) {
      state.inlineTable = { si: si, idx: newIdx, cur: { r: 0, c: 0 } };
      rebuildLineEditor();
      const ta2 = le().querySelector('.vseg[data-seg="' + si + '"] .cell-ta');
      if (ta2) { try { ta2.focus(); } catch (e) { } }
      toast('已在光标处插入 3×3 空表格并进入单元格编辑');
    } else {
      rebuildLineEditor();
      toast('已在光标处插入 3×3 空表格');
    }
  }

  // ---------- 表格：正文内就地编辑（v2.2）----------
  //
  // 设计（按需求）：
  //   · 表格对象被点击后**就地**变成可编辑表格，直接在单元格里改（textarea 直接用同一个
  //     IME 安全输入层，组合期不回写），改动防抖写回 wikitext；
  //   · 原有的表格编辑工具搬到**浮动在表头**的工具栏（sticky，表格很长时仍贴在可视区顶部）；
  //   · 工具栏只保留：名称/标题行(+)、其它属性、对齐、属性标签（class）、当前单元格的跨列/跨行/表头；
  //     其余（增删行列、移动行列/单元格、合并拆分、全选、一键填充片段）已按需求取消。
  function segIsTable(seg) { return seg.kind === 'table' || /^\s*\{\|/.test(segText(seg)); }
  function trimRaw(s) { return (s || '').replace(/\s+$/, '').trim(); }
  // 把文本区段落与表格模型对应起来：优先整段文本精确匹配，退化按首行匹配。
  function findTableIndexForSeg(seg) {
    if (!HAS_WT) return -1;
    const target = trimRaw(segText(seg));
    for (let i = 0; i < state.tables.length; i++) {
      if (trimRaw(state.tables[i].raw) === target) return i;
    }
    const first = target.split('\n')[0];
    for (let i = 0; i < state.tables.length; i++) {
      if (trimRaw(state.tables[i].raw).split('\n')[0] === first) return i;
    }
    return -1;
  }

  // 进入/退出某段的表格就地编辑
  function enterTableEdit(si) {
    if (!HAS_WT) { toast('表格引擎未载入，无法就地编辑表格'); return; }
    const seg = state.segments[si]; if (!seg) return;
    const idx = findTableIndexForSeg(seg);
    if (idx < 0) { toast('没能把该表格对应到表格模型（源码可能刚被改动），可在源码栏直接改'); return; }
    state.inlineTable = { si: si, idx: idx, cur: { r: 0, c: 0 } };
    rebuildLineEditor();
    const w = le().querySelector('.vseg[data-seg="' + si + '"]');
    if (w) w.scrollIntoView({ block: 'center' });
  }
  function exitTableEdit() {
    state.inlineTable = null;
    rebuildLineEditor();
  }
  // 表格单元格的自动增高（textarea 不能被子内容撑开，只能自己量）
  function autoGrowTa(ta) {
    if (!ta) return;
    try { ta.style.height = 'auto'; ta.style.height = Math.max(24, ta.scrollHeight + 2) + 'px'; } catch (e) { }
  }

  // 把表格模型的改动写回源码（**不重建 DOM**：正在输入的光标必须保住）
  function commitTableEdit(si, idx) {
    if (!HAS_WT) return;
    if (!state.inlineTable) return;                 // 已退出就地编辑 → 忽略迟到的输入
    const entry = state.tables[idx]; if (!entry) return;
    const newRaw = WT.serializeTable(entry.model);
    if (newRaw === entry.raw) return;
    pushTableUndo(idx);                       // 记录撤销点（改动前的快照）
    const seg = state.segments[si];
    if (!seg) return;
    const parts = newRaw.split('\n');
    state.lines.splice(seg.start, seg.end - seg.start + 1, ...parts);
    entry.raw = newRaw; entry.isNew = false;
    syncSource();                       // 顺带把源码栏刷成新内容（未聚焦时才覆盖）
    updateCounters();
    // 只重算段的**行区间**（行数变了，后续段的行号要跟着挪），不重建 DOM
    state.segments = computeSegments(state.lines);
    const seg2 = state.segments[si];
    if (seg2) entry.start = seg2.start;
  }
  // 工具栏里的改动统一走这里（与单元格输入同一套写回逻辑）
  function commitCur(idx) {
    const it = state.inlineTable;
    if (!it) return;
    commitTableEdit(it.si, idx);
  }

  // ---------- 表格编辑的撤销 / 重做（Ctrl+Z / Ctrl+Y）----------
  // 撤销栈挂在每个表格 entry 上（entry.undo / entry.redo），存的是「改动前的 wikitext 快照」。
  function pushTableUndo(idx) {
    const entry = state.tables[idx]; if (!entry) return;
    if (!entry.undo) entry.undo = [];
    if (!entry.redo) entry.redo = [];
    if (entry.undo.length && entry.undo[entry.undo.length - 1] === entry.raw) return;
    entry.undo.push(entry.raw);
    entry.redo.length = 0;
    if (entry.undo.length > 80) entry.undo.shift();
  }
  // 把某个 wikitext 快照写回源码行 + 模型（不改 entry 的 undo/redo）
  function writeTableRawToLines(idx, raw) {
    const entry = state.tables[idx]; if (!entry) return -1;
    const it = state.inlineTable;
    let si = -1;
    if (it && it.idx === idx) si = it.si;
    if (si < 0) {
      const cur = trimRaw(entry.raw);
      for (let i = 0; i < state.segments.length; i++) {
        if (trimRaw(segText(state.segments[i])) === cur) { si = i; break; }
      }
    }
    if (si < 0) return -1;
    const seg = state.segments[si]; if (!seg) return -1;
    const parts = raw.split('\n');
    state.lines.splice(seg.start, seg.end - seg.start + 1, ...parts);
    state.segments = computeSegments(state.lines);
    const seg2 = state.segments[si];
    if (seg2) { entry.start = seg2.start; entry.end = seg2.end; }
    entry.raw = raw;
    entry.model = WT.parseTable(raw);
    WT.cleanPlaceholders(entry.model);
    syncSource(); updateCounters();
    return si;
  }
  function tableUndo(idx) {
    const entry = state.tables[idx]; if (!entry) return;
    if (!entry.undo || !entry.undo.length) { toast('没有可撤销的表格操作'); return; }
    if (!entry.redo) entry.redo = [];
    entry.redo.push(entry.raw);
    const snap = entry.undo.pop();
    writeTableRawToLines(idx, snap);
    rebuildLineEditor();
    toast('已撤销表格操作');
  }
  function tableRedo(idx) {
    const entry = state.tables[idx]; if (!entry) return;
    if (!entry.redo || !entry.redo.length) { toast('没有可重做的表格操作'); return; }
    entry.undo.push(entry.raw);
    const snap = entry.redo.pop();
    writeTableRawToLines(idx, snap);
    rebuildLineEditor();
    toast('已重做表格操作');
  }

  // 浮动工具栏（贴在表头之上）
  function makeTableToolbar(idx) {
    const entry = state.tables[idx]; const m = entry.model;
    const bar = document.createElement('div'); bar.className = 'tbl-toolbar';
    const mk = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
    const lab = (text, node) => { const l = mk('label', 'tb-label'); l.appendChild(document.createTextNode(text)); l.appendChild(node); bar.appendChild(l); return node; };

    // 名称 / 标题行（|+ caption）
    const cap = mk('input'); cap.type = 'text'; cap.value = m.caption || ''; cap.placeholder = '表格名称（标题行 +）';
    cap.addEventListener('input', () => { m.caption = cap.value.trim() || null; commitCur(idx); });
    lab('名称', cap);

    // 其它属性
    const oth = mk('input'); oth.type = 'text'; oth.value = (m.attrs && m.attrs.other) || ''; oth.placeholder = '其它属性，如 style="…"';
    oth.addEventListener('input', () => { if (!m.attrs) m.attrs = { classes: [], other: '' }; m.attrs.other = oth.value; commitCur(idx); });
    lab('其它属性', oth);

    // 对齐
    const al = mk('select');
    ['', 'left', 'center', 'right'].forEach((v) => { const o = document.createElement('option'); o.value = v; o.textContent = v || '默认'; al.appendChild(o); });
    al.value = m.align || '';
    al.addEventListener('change', () => { m.align = al.value || ''; commitCur(idx); });
    lab('对齐', al);

    bar.appendChild(mk('span', 'tb-sep'));

    // 属性标签（class）：一键开关，直接写进 {| 行的 class
    const clsWrap = mk('span', 'cls-toggles');
    if (!Array.isArray(m.attrs.classes)) m.attrs.classes = [];
    CLASS_PRESETS.forEach((p) => {
      const b = mk('button', 'cls-toggle' + (m.attrs.classes.indexOf(p.cls) >= 0 ? ' on' : ''), p.label);
      b.type = 'button'; b.title = 'class="' + p.cls + '"';
      b.addEventListener('click', (e) => {
        e.preventDefault();
        const i = m.attrs.classes.indexOf(p.cls);
        if (i >= 0) m.attrs.classes.splice(i, 1); else m.attrs.classes.push(p.cls);
        b.classList.toggle('on', i < 0);
        commitCur(idx);
      });
      clsWrap.appendChild(b);
    });
    const clsLab = mk('span', 'tb-label', '属性标签');
    bar.appendChild(clsLab); bar.appendChild(clsWrap);

    bar.appendChild(mk('span', 'tb-sep'));

    // 当前单元格：跨列 / 跨行 / 表头
    const curInfo = mk('span', 'tb-cur', '当前单元格 —');
    const cs = mk('input'); cs.type = 'number'; cs.min = '1'; cs.max = '30'; cs.value = '1'; cs.title = '跨列 colspan';
    const rs = mk('input'); rs.type = 'number'; rs.min = '1'; rs.max = '30'; rs.value = '1'; rs.title = '跨行 rowspan';
    const hd = document.createElement('input'); hd.type = 'checkbox'; hd.title = '该格是否为表头（! / !）';
    const applyCell = () => {
      const c = curCellOf(idx); if (!c) { toast('请先点一个单元格'); return; }
      const newCs = Math.max(1, Math.min(30, parseInt(cs.value, 10) || 1));
      const newRs = Math.max(1, Math.min(30, parseInt(rs.value, 10) || 1));
      const it = state.inlineTable; if (!it) return;
      // 跨行/跨列：把所跨单元格的内容连同分隔「合成一个块」，而不是顶出一个单元格
      WT.mergeSpanCells(m, it.cur.r, it.cur.c, newCs, newRs);
      c.isHeader = !!hd.checked;
      commitCur(idx);
      rebuildLineEditor();               // 跨行/跨列会改变表格形状 → 这里需要重建一次
    };
    cs.addEventListener('change', applyCell);
    rs.addEventListener('change', applyCell);
    hd.addEventListener('change', applyCell);
    const cellBox = mk('span', 'tb-label');
    cellBox.appendChild(curInfo);
    const l1 = mk('label', 'tb-label'); l1.appendChild(document.createTextNode('跨列')); l1.appendChild(cs);
    const l2 = mk('label', 'tb-label'); l2.appendChild(document.createTextNode('跨行')); l2.appendChild(rs);
    const l3 = mk('label', 'tb-label'); l3.appendChild(document.createTextNode('表头')); l3.appendChild(hd);
    bar.appendChild(cellBox); bar.appendChild(l1); bar.appendChild(l2); bar.appendChild(l3);

    // 行列增删（回归）：以「当前单元格」所在行为基准，插在它后面 / 删掉它
    bar.appendChild(mk('span', 'tb-sep'));
    const shapeBtn = (text, title, fn) => {
      const b = mk('button', 'btn small ghost', text);
      b.type = 'button'; b.title = title;
      b.addEventListener('click', (e) => { e.preventDefault(); fn(); });
      bar.appendChild(b);
      return b;
    };
    const curLC = () => {
      const it = state.inlineTable; if (!it) return null;
      const row = m.rows[it.cur.r]; if (!row) return null;
      const cell = row.cells[it.cur.c]; if (!cell) return null;
      return { r: it.cur.r, c: it.cur.c, cell: cell };
    };
    const shapeDone = (msg) => {
      commitCur(idx);                      // 形状变了：先把当前模型写回源码，再重建编辑器
      if (state.inlineTable) state.inlineTable.cur = { r: 0, c: 0 };
      rebuildLineEditor();
      toast(msg);
    };
    shapeBtn('＋行', '在当前单元格所在行的下方插入一行', () => {
      try {
        WT.computeCovered(m);
        const g = WT.buildGrid(m);
        const lc = curLC();
        let K = g.V;
        if (lc) K = (g.rowOffset[lc.r] || 0) + (lc.cell.rowspan || 1);
        WT.insertRow(m, K);
        shapeDone('已插入一行');
      } catch (e) { toast('插入行失败：' + (e.message || e)); }
    });
    shapeBtn('－行', '删除当前单元格所在行', () => {
      try {
        WT.computeCovered(m);
        const g = WT.buildGrid(m);
        if (g.V <= 1) { toast('至少保留一行'); return; }
        const lc = curLC(); if (!lc) { toast('请先点一个单元格'); return; }
        WT.deleteRow(m, g.rowOffset[lc.r] || 0);
        shapeDone('已删除一行');
      } catch (e) { toast('删除行失败：' + (e.message || e)); }
    });
    shapeBtn('＋列', '在当前单元格所在列的右侧插入一列', () => {
      try {
        WT.computeCovered(m);
        const g = WT.buildGrid(m);
        const lc = curLC();
        let K = g.C;
        if (lc) K = (lc.cell._start || 0) + (lc.cell.colspan || 1);
        WT.insertColumn(m, K);
        shapeDone('已插入一列');
      } catch (e) { toast('插入列失败：' + (e.message || e)); }
    });
    shapeBtn('－列', '删除当前单元格所在列', () => {
      try {
        WT.computeCovered(m);
        const g = WT.buildGrid(m);
        if (g.C <= 1) { toast('至少保留一列'); return; }
        const lc = curLC(); if (!lc) { toast('请先点一个单元格'); return; }
        WT.deleteColumn(m, lc.cell._start || 0);
        shapeDone('已删除一列');
      } catch (e) { toast('删除列失败：' + (e.message || e)); }
    });

    bar.appendChild(mk('span', 'tb-grow'));
    const back = mk('button', 'btn small ghost', '◀ 返回渲染');
    back.type = 'button'; back.title = '结束单元格编辑，恢复原站渲染外观';
    back.addEventListener('click', (e) => { e.preventDefault(); exitTableEdit(); });
    bar.appendChild(back);

    // 当前单元格信息随焦点更新（表格重建后由 makeTableEditHost 再调一次）
    bar._syncCur = () => {
      const cur = state.inlineTable && state.inlineTable.cur;
      const c = curCellOf(idx);
      curInfo.textContent = cur ? ('当前单元格 ' + (cur.r + 1) + '行' + (cur.c + 1) + '列' +
        ((c && (c.colspan > 1 || c.rowspan > 1)) ? ('（跨列' + (c.colspan || 1) + '/跨行' + (c.rowspan || 1) + '）') : '')) : '当前单元格 —';
      if (c) { cs.value = String(c.colspan || 1); rs.value = String(c.rowspan || 1); hd.checked = !!c.isHeader; }
    };
    bar._syncCur();
    return bar;
  }
  function curCellOf(idx) {
    const it = state.inlineTable; if (!it) return null;
    const entry = state.tables[idx]; if (!entry) return null;
    const row = entry.model.rows[it.cur.r]; if (!row) return null;
    return row.cells[it.cur.c] || null;
  }
  function markCurCell(host, r, c) {
    host.querySelectorAll('td.cur,th.cur').forEach((td) => td.classList.remove('cur'));
    const td = host.querySelector('td[data-r="' + r + '"][data-c="' + c + '"],th[data-r="' + r + '"][data-c="' + c + '"]');
    if (td) td.classList.add('cur');
  }

  // 就地编辑宿主：浮动工具栏 + 可编辑表格（结构照搬原表格面板的网格，但每格可直接改）
  function makeTableEditHost(seg, si, idx) {
    const entry = state.tables[idx];
    const m = entry.model;
    const host = document.createElement('div'); host.className = 'tbl-edit';
    const bar = makeTableToolbar(idx);
    host.appendChild(bar);
    WT.computeCovered(m);
    const table = document.createElement('table'); table.className = 'tbl-grid';
    const w = m._maxCols || 0;
    m.rows.forEach((row, r) => {
      const tr = document.createElement('tr');
      let col = 0;
      row.cells.forEach((cell, c) => {
        const start = cell._start || 0; while (col < start) col++;
        const td = document.createElement(cell.isHeader ? 'th' : 'td');
        if (cell.colspan && cell.colspan > 1) td.colSpan = cell.colspan;
        if (cell.rowspan && cell.rowspan > 1) td.rowSpan = cell.rowspan;
        td.dataset.r = r; td.dataset.c = c;
        const it = state.inlineTable;
        if (it && it.cur.r === r && it.cur.c === c) td.classList.add('cur');
        const ta = document.createElement('textarea');
        ta.className = 'cell-ta'; ta.value = cell.text || ''; ta.spellcheck = false;
        ta.rows = 1;
        ta.addEventListener('focus', () => {
          if (!state.inlineTable) return;
          state.inlineTable.cur = { r: r, c: c };
          markCurCell(host, r, c);
          if (bar._syncCur) bar._syncCur();
        });
        // 与活动行/节点框/源码栏共用同一个 IME 安全输入层（组合期不回写、收尾 input 不重复回写）
        bindImeInput(ta, () => autoGrowTa(ta), () => {
          cell.text = ta.value;
          autoGrowTa(ta);
          commitTableEdit(si, idx);
        });
        ta.addEventListener('input', () => autoGrowTa(ta));
        td.appendChild(ta);
        tr.appendChild(td);
        col = start + (cell.colspan || 1);
      });
      const covSet = (m._covered && m._covered[r]) || null;
      while (col < w) { if (covSet && covSet.has(col)) { col++; continue; } const ph = document.createElement('td'); tr.appendChild(ph); col++; }
      table.appendChild(tr);
    });
    host.appendChild(table);
    const hint = document.createElement('div'); hint.className = 'tbl-hint';
    hint.textContent = '单元格内容即 wikitext 片段，改动会立即写回源码；跨列/跨行/表头作用于当前单元格；＋行/－行/＋列/－列 以当前单元格为基准。';
    host.appendChild(hint);
    setTimeout(() => { host.querySelectorAll('.cell-ta').forEach(autoGrowTa); }, 0);
    return host;
  }

  // 未进入编辑态时的提示条（点它或点表格本身都能进入就地编辑）
  function makeTableJumpBar(si) {
    const bar = document.createElement('div'); bar.className = 'seg-tablebar';
    const label = document.createElement('span'); label.className = 'seg-tablelabel'; label.textContent = '▤ 表格';
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'btn small'; btn.textContent = '点击进入单元格编辑 →';
    btn.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      enterTableEdit(si);
    });
    bar.appendChild(label); bar.appendChild(btn);
    return bar;
  }

  // ---------- 片段 / 概要：用户自定义存储 ----------
  // 通用「chips + 管理面板」工厂：表格片段与编辑概要共用同一份实现（行为一致、只有一版）。
  //   · o.loader 可选：自定义读取（概要需要「空数组也算有效」的严格读取，见 loadJSONStrict）；
  //   · o.onInsert(text)：点 chip 时的动作（片段=插入，概要=**追加**）。
  function buildSnippetManager(o) {
    let items = o.defaults.slice();
    function persist() { saveJSON(o.storageKey, items); }
    function render() {
      const loading = o.loader ? o.loader() : loadJSON(o.storageKey, o.defaults);
      loading.then((loaded) => {
        items = (loaded || []).map((s) => (typeof s === 'string' ? { text: s } : (s && s.text !== undefined ? s : { text: String(s) })));
        o.chipsEl.innerHTML = '';
        items.forEach((s) => {
          const b = document.createElement('button'); b.className = 'chip'; b.type = 'button';
          b.textContent = (s.label || s.text || s); b.title = (s.text || s);
          b.addEventListener('click', () => o.onInsert(s.text || s)); o.chipsEl.appendChild(b);
        });
        o.listEl.innerHTML = '';
        items.forEach((s, idx) => {
          const row = document.createElement('div'); row.className = 'snip-row';
          const lab = document.createElement('input'); lab.value = s.label || ''; lab.placeholder = '名称';
          lab.addEventListener('input', () => { items[idx].label = lab.value; persist(); });
          const txt = document.createElement('input'); txt.value = s.text || ''; txt.placeholder = o.placeholder;
          txt.addEventListener('input', () => { items[idx].text = txt.value; persist(); });
          const del = document.createElement('button'); del.className = 'btn ghost'; del.type = 'button'; del.textContent = '×';
          del.addEventListener('click', () => { items.splice(idx, 1); persist(); render(); });
          row.appendChild(lab); row.appendChild(txt); row.appendChild(del); o.listEl.appendChild(row);
        });
        const al = o.newLabelEl, at = o.newTextEl, ab = o.addBtn;
        ab.onclick = () => { const t = at.value.trim(); if (!t) return; items.push({ label: al.value.trim(), text: t }); persist(); render(); al.value = ''; at.value = ''; };
      });
    }
    o.toggleBtn.addEventListener('click', () => { o.manageEl.hidden = !o.manageEl.hidden; });
    render();
  }

  // ---------- 弹窗通用：开合 + Esc + 点遮罩关闭 ----------
  function modalOpen(el) { if (!el) return; el.hidden = false; }
  function modalClose(el) { if (!el) return; el.hidden = true; }
  // 只有最上层的弹窗响应 Esc（所有 .modal 都参与，含包裹/指南/diff）
  function anyModalOpen() {
    return !!document.querySelector('.modal:not([hidden])');
  }
  function closeTopModal() {
    const modals = Array.from(document.querySelectorAll('.modal')).filter((m) => !m.hidden);
    if (modals.length) { modalClose(modals[modals.length - 1]); return true; }
    return false;
  }
  // 点遮罩空白处关闭（点卡片内部不关）
  function wireModal(el, id) {
    if (!el) return;
    el.addEventListener('mousedown', (e) => { if (e.target === el) modalClose(el); });
  }

  // ---------- 顶栏「⌘ 包裹符号」弹窗 ----------
  // 数据存 chrome.storage.local['wrapSnippets'] = [{label, open, close, key, caret}, …]
  // key 用「修饰键 + KeyboardEvent.code」的字符串（如 Alt+Digit2），与键盘布局无关。
  const WRAP_KEY = 'wrapSnippets';

  function normWrap(s) {
    if (!s || typeof s !== 'object') return null;
    const open = String(s.open == null ? '' : s.open);
    const close = String(s.close == null ? '' : s.close);
    if (!open && !close) return null;
    return {
      label: String(s.label || ''), open, close,
      key: String(s.key || ''), caret: (s.caret === 'after') ? 'after' : 'in'
    };
  }

  function keyConflict(list, key, skipIdx) {
    if (!key) return -1;
    if (RESERVED_KEYS.has(key)) return -2;
    for (let i = 0; i < list.length; i++) {
      if (i !== skipIdx && list[i].key === key) return i;
    }
    return -1;
  }

  // 快捷键指南里的「包裹符号」表：直接读当前 state.wraps，改键后同步刷新
  function renderHelpWrapTable() {
    const body = $('hgWrapBody'); if (!body) return;
    body.innerHTML = '';
    if (!state.wraps.length) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 3; td.className = 'hg-empty'; td.textContent = '（尚未配置任何包裹符号）';
      tr.appendChild(td); body.appendChild(tr);
      return;
    }
    state.wraps.forEach((w) => {
      const tr = document.createElement('tr');
      // 快捷键：把 "Alt+Digit2" 渲染成一串键帽
      const kd = document.createElement('td');
      const comb = w.key ? prettyKey(w.key) : '未设置';
      comb.split('+').forEach((part, i) => {
        if (i) kd.appendChild(document.createTextNode('+'));
        const k = document.createElement('kbd');
        k.textContent = part === 'Ctrl' ? 'Ctrl' : part;
        kd.appendChild(k);
      });
      const nm = document.createElement('td'); nm.textContent = w.label || '（未命名）';
      const ef = document.createElement('td');
      ef.innerHTML = openClosePreview(w);
      tr.appendChild(kd); tr.appendChild(nm); tr.appendChild(ef);
      body.appendChild(tr);
    });
  }
  // 用示例文字展示「左 + 例子 + 右」的效果
  function openClosePreview(w) {
    const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const o = esc(w.open || ''), c = esc(w.close || ''), mid = '内容';
    const both = w.open && w.close;
    return '<code>' + o + (both ? mid : '') + c + '</code>';
  }

  function buildWrapPanel() {
    const btn = $('btnWrapPanel'), modal = $('wrapModal');
    if (!btn || !modal) return;
    wireModal(modal, 'wrapModal');
    btn.addEventListener('click', () => { render(); renderHelpWrapTable(); modalOpen(modal); });
    const x = $('wrapModalX'), ok = $('wrapModalOk');
    if (x) x.addEventListener('click', () => modalClose(modal));
    if (ok) ok.addEventListener('click', () => modalClose(modal));
    const toHelp = $('btnHelpFromWrap');
    if (toHelp) toHelp.addEventListener('click', () => { modalClose(modal); openHelp(); });

    function persist() { saveJSON(WRAP_KEY, state.wraps); renderHelpWrapTable(); }

    function render() {
      const list = $('wrapList'); if (!list) return;
      list.innerHTML = '';
      state.wraps.forEach((w, idx) => {
        const row = document.createElement('div'); row.className = 'wp-row';

        const lab = document.createElement('input');
        lab.className = 'wp-in lbl'; lab.value = w.label || ''; lab.placeholder = '名称';
        lab.addEventListener('input', () => { w.label = lab.value; persist(); });

        const op = document.createElement('input');
        op.className = 'wp-in op'; op.value = w.open; op.placeholder = '左符号';
        op.addEventListener('input', () => { w.open = op.value; persist(); });

        const cl = document.createElement('input');
        cl.className = 'wp-in cl'; cl.value = w.close; cl.placeholder = '右符号';
        cl.addEventListener('input', () => { w.close = cl.value; persist(); });

        const key = document.createElement('input');
        key.className = 'wp-in key'; key.readOnly = true;
        key.value = prettyKey(w.key);
        key.title = '点一下后直接按快捷键（需含 Ctrl / Alt / Shift）；按 Backspace 清除';
        key.addEventListener('keydown', (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          if (ev.key === 'Backspace' || ev.key === 'Delete') { w.key = ''; key.value = '未设置'; persist(); return; }
          const comb = keyFromEvent(ev);
          if (!comb) { toast('快捷键至少要包含 Ctrl / Alt / Shift 之一'); return; }
          const hit = keyConflict(state.wraps, comb, idx);
          if (hit === -2) { toast('该组合是浏览器/编辑器保留键，请换一个'); return; }
          if (hit >= 0) { toast('已被「' + (state.wraps[hit].label || state.wraps[hit].open) + '」占用'); return; }
          w.key = comb; key.value = prettyKey(comb); persist();
        });
        key.addEventListener('focus', () => { key.classList.add('rec'); key.value = '按下快捷键…'; });
        key.addEventListener('blur', () => { key.classList.remove('rec'); key.value = prettyKey(w.key); });

        const del = document.createElement('button');
        del.type = 'button'; del.className = 'btn ghost small'; del.textContent = '×'; del.title = '删除这一项';
        del.addEventListener('click', () => { state.wraps.splice(idx, 1); persist(); render(); });

        row.appendChild(lab); row.appendChild(op); row.appendChild(cl); row.appendChild(key); row.appendChild(del);
        list.appendChild(row);
      });
    }

    // 新增录入：左/右符号 + 名称 + 快捷键（快捷键框聚焦后直接按）
    const nLbl = $('wrapNewLabel'), nOp = $('wrapNewOpen'), nCl = $('wrapNewClose'), nKey = $('wrapNewKey');
    let pendingKey = '';
    if (nKey) {
      nKey.addEventListener('keydown', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        if (ev.key === 'Backspace' || ev.key === 'Delete') { pendingKey = ''; nKey.value = ''; return; }
        const comb = keyFromEvent(ev);
        if (!comb) { toast('快捷键至少要包含 Ctrl / Alt / Shift 之一'); return; }
        const hit = keyConflict(state.wraps, comb, -1);
        if (hit === -2) { toast('该组合是浏览器/编辑器保留键，请换一个'); return; }
        if (hit >= 0) { toast('已被「' + (state.wraps[hit].label || state.wraps[hit].open) + '」占用'); return; }
        pendingKey = comb; nKey.value = prettyKey(comb);
      });
      nKey.addEventListener('focus', () => { nKey.classList.add('rec'); if (!pendingKey) nKey.value = '按下快捷键…'; });
      nKey.addEventListener('blur', () => { nKey.classList.remove('rec'); nKey.value = prettyKey(pendingKey); });
    }
    const addBtn = $('wrapAddBtn');
    if (addBtn) {
      addBtn.addEventListener('click', () => {
        const open = nOp ? nOp.value : '';
        const close = nCl ? nCl.value : '';
        if (!open && !close) { toast('请至少填写左符号或右符号'); return; }
        state.wraps.push({
          label: (nLbl && nLbl.value.trim()) || '',
          open, close, key: pendingKey, caret: 'in'
        });
        persist(); render();
        if (nLbl) nLbl.value = ''; if (nOp) nOp.value = ''; if (nCl) nCl.value = '';
        pendingKey = ''; if (nKey) nKey.value = '';
        toast('已添加包裹符号');
      });
    }
    const resetBtn = $('wrapResetBtn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        state.wraps = DEFAULT_WRAPS.map((w) => Object.assign({}, w));
        persist(); render();
        toast('已恢复默认包裹符号');
      });
    }

    loadJSON(WRAP_KEY, null).then((loaded) => {
      const arr = Array.isArray(loaded) ? loaded.map(normWrap).filter(Boolean) : [];
      state.wraps = arr.length ? arr : DEFAULT_WRAPS.map((w) => Object.assign({}, w));
      render();
      renderHelpWrapTable();
    });

    window.addEventListener('beforeunload', () => { try { saveJSON(WRAP_KEY, state.wraps); } catch (e) { } });
  }

  // ---------- 顶栏「? 快捷键指南」弹窗 ----------
  function openHelp() {
    renderHelpWrapTable();     // 每次打开都用最新配置刷新包裹符号表
    modalOpen($('helpModal'));
  }
  function buildHelpModal() {
    const btn = $('btnHelp'), modal = $('helpModal');
    if (!btn || !modal) return;
    wireModal(modal, 'helpModal');
    btn.addEventListener('click', () => { if (modal.hidden) openHelp(); else modalClose(modal); });
    const x = $('helpModalX'), ok = $('helpModalOk');
    if (x) x.addEventListener('click', () => modalClose(modal));
    if (ok) ok.addEventListener('click', () => modalClose(modal));
  }

  // ---------- 保存前差异对比弹窗 ----------
  function buildDiffModal() {
    const modal = $('diffModal');
    if (!modal) return;
    wireModal(modal, 'diffModal');
    const x = $('diffModalX'), cancel = $('diffCancel'), confirm = $('diffConfirm'), copy = $('diffCopy');
    if (x) x.addEventListener('click', () => modalClose(modal));
    if (cancel) cancel.addEventListener('click', () => modalClose(modal));
    if (confirm) confirm.addEventListener('click', () => doSave());
    if (copy) copy.addEventListener('click', () => {
      const rows = Array.from($('dfBody').querySelectorAll('.df-row'));
      const txt = rows.map((r) => {
        const sign = r.classList.contains('add') ? '+' : r.classList.contains('del') ? '-' : ' ';
        return sign + ' ' + (r.querySelector('.tx').textContent || '');
      }).join('\n');
      navigator.clipboard.writeText(txt).then(() => toast('已复制差异'), () => toast('复制失败'));
    });
  }

  // ---------- 外链确认弹窗（v1.8.7）----------
  // 渲染块里点站外链接时先问一句：确认后才在新标签页打开。
  // 绝不原地导航 —— 编辑内容还没保存，导航走就丢了。
  let _extUrl = '';
  function askExternalLink(url) {
    _extUrl = String(url || '');
    if (!_extUrl) return;
    const box = $('extUrl'); if (box) box.textContent = _extUrl;
    modalOpen($('extModal'));
  }
  function buildExtModal() {
    const modal = $('extModal');
    if (!modal) return;
    wireModal(modal, 'extModal');
    const x = $('extModalX'), cancel = $('extCancel'), ok = $('extOk'), copy = $('extCopy');
    if (x) x.addEventListener('click', () => modalClose(modal));
    if (cancel) cancel.addEventListener('click', () => modalClose(modal));
    if (ok) ok.addEventListener('click', () => { const u = _extUrl; modalClose(modal); if (u) openTab(u); });
    if (copy) copy.addEventListener('click', () => {
      navigator.clipboard.writeText(_extUrl).then(() => toast('已复制链接'), () => toast('复制失败'));
    });
  }

  // ---------- 站内搜索 / 跳转（v1.8.7）----------
  // action=query&list=search。结果项主点击=用编辑器在新标签打开，
  // 次按钮=在光标处插入 [[页面名]]（可视化活动行 textarea 或纯源码 textarea）。
  let _seToken = 0;                 // 请求序号：只渲染最后一次的结果，避免旧结果覆盖新结果
  function searchApiUrl(q, limit) {
    return apiUrl() + '?action=query&list=search&srsearch=' + encodeURIComponent(q)
      + '&srnamespace=0&srlimit=' + (limit || 20) + '&format=json';
  }
  function stripHtml(s) { return String(s == null ? '' : s).replace(/<[^>]*>/g, ''); }

  // 把搜索词高亮成 <em>（先转义再插标签，避免 XSS）
  function markQuery(text, q) {
    const safe = String(text == null ? '' : text)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    if (!q) return safe;
    const terms = q.split(/\s+/).filter(Boolean).map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    if (!terms.length) return safe;
    try {
      return safe.replace(new RegExp('(' + terms.join('|') + ')', 'gi'), '<em>$1</em>');
    } catch (e) { return safe; }
  }

  // 取得「可以写入的输入框」：优先当前活动的可视化行 textarea，其次纯源码 textarea
  function currentInputTarget() {
    const wrap = le().querySelector('.active-line');
    const ta = wrap && wrap.querySelector('.ta');
    if (ta) return ta;
    const src = $('srcSource');
    if (src && !src.hidden) return src;
    return null;
  }

  // 在光标处插入一段文本（尽量走 execCommand 以保住 Ctrl+Z 撤销栈）
  function insertAtCaret(ta, text) {
    const v = ta.value;
    let s = ta.selectionStart, e = ta.selectionEnd;
    if (s == null) { s = e = v.length; }
    if (s > e) { const t = s; s = e; e = t; }
    // 走 editTextarea 闸门：execCommand 会同步派发一次 input，若再手动派发一次就回写两遍
    editTextarea(ta, () => {
      let ok = false;
      try {
        ta.focus();
        ta.setSelectionRange(s, e);
        ok = document.execCommand('insertText', false, text);
      } catch (err) { ok = false; }
      if (!ok) {
        ta.value = v.slice(0, s) + text + v.slice(e);
        const p = s + text.length;
        ta.selectionStart = p; ta.selectionEnd = p;
      }
    });
  }

  function insertWikiLink(title) {
    const t = String(title || '').trim();
    if (!t) return;
    const ta = currentInputTarget();
    if (!ta) { toast('请先点进某一行（或切到源码模式）再插入链接'); return; }
    insertAtCaret(ta, '[[' + t + ']]');
    toast('已插入 [[' + t + ']]');
  }

  function renderSearchResults(list, hits, q) {
    const box = $('seList'); if (!box) return;
    box.innerHTML = '';
    if (!hits.length) {
      const d = document.createElement('div');
      d.className = 'se-empty';
      d.textContent = '没有匹配「' + q + '」的页面';
      box.appendChild(d);
      return;
    }
    hits.forEach((h) => {
      const row = document.createElement('div'); row.className = 'se-row';
      const main = document.createElement('button');
      main.className = 'se-main'; main.type = 'button';
      main.title = '用加强编辑器在新标签页打开「' + h.title + '」';
      const t = document.createElement('span'); t.className = 'se-t';
      t.innerHTML = markQuery(h.title, q);
      const s = document.createElement('span'); s.className = 'se-s';
      s.innerHTML = markQuery(stripHtml(h.snippet), q);
      main.appendChild(t); main.appendChild(s);
      main.addEventListener('click', () => {
        modalClose($('searchModal'));
        setStatus('正在打开「' + h.title + '」…');
        openEditorForPage(h.title);
      });

      const acts = document.createElement('span'); acts.className = 'se-acts';
      const ref = document.createElement('button');
      ref.className = 'btn ghost small'; ref.type = 'button'; ref.textContent = '参考';
      ref.title = '在分栏里只读打开「' + h.title + '」（第三个选项：在分栏中打开）';
      ref.addEventListener('click', () => { modalClose($('searchModal')); openRefPage(h.title); });
      const ins = document.createElement('button');
      ins.className = 'btn ghost small'; ins.type = 'button'; ins.textContent = '插入';
      ins.title = '在光标处插入 [[' + h.title + ']]';
      ins.addEventListener('click', () => { insertWikiLink(h.title); });
      const wiki = document.createElement('button');
      wiki.className = 'btn ghost small'; wiki.type = 'button'; wiki.textContent = 'wiki 页';
      wiki.title = '不用编辑器，直接在 wiki 上打开';
      wiki.addEventListener('click', () => {
        modalClose($('searchModal'));
        openTab(baseUrl() + '/wiki/' + encodeURIComponent(String(h.title).replace(/ /g, '_')));
      });
      acts.appendChild(ref); acts.appendChild(ins); acts.appendChild(wiki);
      row.appendChild(main); row.appendChild(acts);
      box.appendChild(row);
    });
  }

  // ---------- 参考页面（分栏里只读打开另一个 wiki 页面）----------
  // 用途：编辑 A 页面时把 B 页面摆在旁边对照（例如照着模板页写参数）。
  //   · 用 action=parse 取渲染好的 HTML（只读；要改请用「✎ 编辑」开新标签页）
  //   · 栏内点站内链接 = 在本栏继续跳转（浏览参考页最顺手）；Ctrl/⌘+点击 = 新标签页打开编辑器
  //   · 外链走「外链确认弹窗」，绝不把当前编辑页导航走
  function refTitleOf(a) {
    const t = (a.getAttribute('title') || '').trim();
    const m = t.match(/^(.*?)（页面不存在）$/);
    if (m) return m[1].trim();
    try { return pageFromUrl(new URL(a.getAttribute('href') || '', baseUrl() + '/')); } catch (e) { return ''; }
  }
  // 参考页与主栏走**同一条渲染管线**（makeRenderHost）：Shadow DOM + 原站站点 CSS + 主题覆盖
  // + 交互兜底（页签切换 / 折叠组 / 导航盒折叠）→ 外观与主栏完全一致。
  // 两点差别：① 不打源码区间标注（参考页不是当前编辑的页面，点它不该跳源码）；
  //          ② 链接点击在栏内跳转，Ctrl/⌘+点击才用编辑器开新标签页。
  function paintRef(html) {
    const body = $('refBody'); if (!body) return;
    body.innerHTML = '';
    state.refHtml = String(html || '');
    if (!state.refHtml.trim()) {
      const d = document.createElement('div'); d.className = 'ref-empty';
      d.textContent = '该页面没有可显示的内容。';
      body.appendChild(d);
      return;
    }
    // 外面套一层 .vseg：editor.css 里所有「.vseg .render …」的度量/链接/深色主题规则
    // 因此对参考页**同样生效**（这是「参考栏与主栏同一套样式」的最后一块拼图）。
    const wrap = document.createElement('div');
    wrap.className = 'vseg ref-vseg';
    const host = makeRenderHost(state.refHtml, null, { cls: 'ref-render' });
    wrap.appendChild(host);
    body.appendChild(wrap);
    wireRefLinks(host.shadowRoot || host);
  }
  // ⚠️ 参考页现在在 Shadow DOM 里：监听必须挂在**影子根**上（挂在 #refBody 上时 e.target
  //    会被重定向成宿主元素，closest('a') 永远找不到锚点 → 链接点了没反应）。
  function wireRefLinks(root) {
    if (!root || root._wired) return;
    root._wired = true;
    root.addEventListener('click', (e) => {
      const a = e.target && e.target.closest ? e.target.closest('a') : null;
      if (!a) return;
      const href = a.getAttribute('href') || '';
      e.preventDefault(); e.stopPropagation();
      if (!href || href.charAt(0) === '#') {                    // 页内锚点：栏内滚动
        const id = href.replace(/^#/, '');
        if (id) {
          const el = (root.getElementById ? root.getElementById(id) : null) || root.querySelector('#' + CSS.escape(id));
          if (el) el.scrollIntoView({ block: 'start' });
        }
        return;
      }
      let u = null, abs = href;
      try { u = new URL(href, baseUrl() + '/'); abs = u.href; } catch (err) { u = null; }
      if (u && (u.protocol === 'http:' || u.protocol === 'https:')) {
        let same = false;
        try { same = (u.origin === new URL(baseUrl() + '/').origin || abs.indexOf(normalizeServer(state.server)) === 0); } catch (err) { same = false; }
        const page = pageFromUrl(u);
        if (same && page) {                                     // 站内页面：栏内跳转；Ctrl/⌘ 用编辑器开新标签
          if (e.ctrlKey || e.metaKey) openEditorForPage(page); else openRefPage(page);
          return;
        }
        if (same) { openTab(abs); return; }                     // 站内非页面（Special: 等）：普通新标签
        askExternalLink(abs);                                   // 真外链：走确认弹窗
        return;
      }
      askExternalLink(abs);
    }, true);
  }
  async function openRefPage(title) {
    const t = String(title || '').trim();
    if (!t) { toast('请给一个页面名'); return; }
    state.refPage = t;
    openView('ref', 'right');
    const body = $('refBody'), hint = $('refHint'), tt = $('refTitle');
    if (tt) tt.textContent = '参考：' + t;
    if (hint) hint.textContent = '只读；点链接在本栏跳转，Ctrl/⌘+点击开新标签页';
    if (body) body.innerHTML = '<div class="ref-loading">正在载入「' + escH(t) + '」…</div>';
    try {
      const url = apiUrl() + '?action=parse&page=' + encodeURIComponent(t)
        + '&prop=text&disablelimitreport=1&disableeditsection=1&format=json' + variantParam();
      const r = await fetch(url, { credentials: 'omit', cache: 'no-store', headers: { 'Accept': 'application/json' } });
      const j = await r.json();
      if (j && j.error) throw new Error(j.error.info || j.error.code || '页面不存在');
      const html = (j && j.parse && j.parse.text && j.parse.text['*']) || '';
      const real = (j && j.parse && j.parse.title) || t;
      if (tt) tt.textContent = '参考：' + real;
      paintRef(absolutizeHtml(html));           // 与主栏同一套渲染管线
    } catch (e) {
      if (body) body.innerHTML = '<div class="ref-empty">载入失败：' + escH(e.message || String(e)) +
        '<br>可以点右上角「✎ 编辑」用编辑器打开它。</div>';
    }
  }

  // ---------- Wiki 施工进度（大分类 → 分类页面 → 分类成员页面）----------
  // 数据来源：project 页「缺氧 Wiki:施工进度」的 wikitext。它的「内容」段是
  //   ; 内容
  //   * 待求证页面：[[:Category:来源请求|{{PAGESINCATEGORY:来源请求}}]]
  // 这类「标签：[[:Category:X]]」列表 —— 本项目把它解析成
  //   大分类（; 后面的名字）→ 分类页面（Category:X）→ 该分类的成员页面（API categorymembers）
  const PROGRESS_PAGE = '缺氧 Wiki:施工进度';

  // 从 wikitext 里解析出 [{ name, cats: [{ label, cat }] }]
  function parseProgress(text) {
    const src = String(text == null ? '' : text);
    const groups = [];
    let cur = null;
    src.split('\n').forEach((raw) => {
      const line = raw.replace(/<!--[\s\S]*?-->/g, '').trim();
      if (!line) return;
      const mt = line.match(/^;\s*(.+)$/);                       // ; 内容  → 新的大分类
      if (mt) {
        const name = mt[1].replace(/\[\[([^\]|]+)\|?([^\]]*)\]\]/g, (a, p1, p2) => (p2 || p1)).trim();
        cur = { name: name, cats: [] };
        groups.push(cur);
        return;
      }
      if (!cur) return;
      const mi = line.match(/^\*+\s*(.*)$/);                      // * 标签：[[Category:X]]
      if (!mi) return;
      const body = mi[1];
      // 分类链接：允许 [[:Category:X]] / [[Category:X|显示]] / [[分类:X]]
      const re = /\[\[:?\s*(?:Category|分类)\s*:\s*([^\]|]+?)\s*(?:\|[^\]]*)?\]\]/gi;
      let m = null;
      while ((m = re.exec(body))) {
        const rawCat = m[1].trim();
        if (!rawCat) continue;
        let label = body.slice(0, m.index)
          .replace(/\{\{[^}]*\}\}/g, '')                          // 去掉 {{PAGESINCATEGORY:…}} 之类
          .replace(/\[\[[^\]]*\]\]/g, '')
          .replace(/[''']+/g, '')
          .replace(/[：:]\s*$/, '')
          .trim();
        cur.cats.push({ label: label || rawCat, cat: rawCat.charAt(0).toUpperCase() + rawCat.slice(1) === rawCat ? rawCat : rawCat });
      }
    });
    return groups.filter((g) => g.cats.length);
  }

  function catPageTitle(cat) {
    // API 的 cmtitle 需要带命名空间前缀；解析时可能只拿到名字
    return /^(Category|分类)\s*:/i.test(cat) ? cat.replace(/^分类\s*:/i, 'Category:') : ('Category:' + cat);
  }

  async function loadCatMembers(cat) {
    const key = catPageTitle(cat);
    if (state.progressCatCache[key]) return state.progressCatCache[key];
    const url = apiUrl() + '?action=query&list=categorymembers&cmtitle=' + encodeURIComponent(key)
      + '&cmlimit=500&cmprop=ids|title|type&format=json' + variantParam();
    const r = await fetch(url, { credentials: 'include', cache: 'no-store', headers: { 'Accept': 'application/json' } });
    const j = await r.json();
    const list = (j && j.query && Array.isArray(j.query.categorymembers)) ? j.query.categorymembers : [];
    state.progressCatCache[key] = list;
    return list;
  }

  async function loadProgress(force) {
    const now = Date.now();
    if (!force && state.progressGroups.length && (now - state._progressAt) < 120000) return state.progressGroups;
    const info = $('pgInfo'), body = $('pgBody');
    if (info) info.textContent = '正在获取「' + PROGRESS_PAGE + '」…';
    if (body) body.innerHTML = '';
    try {
      const url = apiUrl() + '?action=query&prop=revisions&rvprop=content&rvslots=main&titles='
        + encodeURIComponent(PROGRESS_PAGE) + variantParam() + '&format=json&_=' + Date.now();
      const r = await fetch(url, { credentials: 'include', cache: 'no-store', headers: { 'Accept': 'application/json' } });
      const j = await r.json();
      const pages = j && j.query && j.query.pages;
      const p = pages ? pages[Object.keys(pages)[0]] : null;
      const rev = p && p.revisions && p.revisions[0];
      const slot = rev && rev.slots && rev.slots.main;
      const text = (slot && slot['*'] != null) ? slot['*'] : '';
      state.progressGroups = parseProgress(text);
      state.progressCatCache = {};
      state._progressAt = now;
      if (info) {
        const nCat = state.progressGroups.reduce((a, g) => a + g.cats.length, 0);
        info.textContent = state.progressGroups.length
          ? ('共 ' + state.progressGroups.length + ' 个大分类 / ' + nCat + ' 个分类页面（展开大分类即加载该分类的页面）')
          : '没有从该页面解析到分类列表（页面结构可能已变）。';
      }
      renderProgress();
    } catch (e) {
      if (info) info.textContent = '获取失败：' + (e.message || e);
      if (body) body.innerHTML = '<div class="pg-empty">获取失败：' + escH(e.message || String(e)) + '</div>';
    }
    return state.progressGroups;
  }

  function renderProgress() {
    const body = $('pgBody'); if (!body) return;
    body.innerHTML = '';
    if (!state.progressGroups.length) {
      const d = document.createElement('div'); d.className = 'pg-empty';
      d.textContent = '没有解析到「内容」段的分类列表。';
      body.appendChild(d);
      return;
    }
    state.progressGroups.forEach((g, gi) => {
      const wrap = document.createElement('div'); wrap.className = 'pg-group';
      const head = document.createElement('button');
      head.type = 'button'; head.className = 'pg-head';
      const caret = document.createElement('span'); caret.className = 'pg-caret'; caret.textContent = '▸';
      const name = document.createElement('span'); name.className = 'pg-gname'; name.textContent = g.name;
      const count = document.createElement('span'); count.className = 'pg-count';
      count.textContent = '（' + g.cats.length + ' 个分类）';
      head.appendChild(caret); head.appendChild(name); head.appendChild(count);
      const catsBox = document.createElement('div'); catsBox.className = 'pg-cats'; catsBox.hidden = true;
      head.addEventListener('click', async () => {
        const open = catsBox.hidden;
        catsBox.hidden = !open;
        caret.textContent = open ? '▾' : '▸';
        if (open && !catsBox._loaded) { catsBox._loaded = true; await fillProgressCats(catsBox, g); }
      });
      wrap.appendChild(head); wrap.appendChild(catsBox);
      body.appendChild(wrap);
      if (gi === 0) { /* 默认全部折叠，由用户展开（大分类要可以折叠展开） */ }
    });
  }

  async function fillProgressCats(catsBox, g) {
    for (const c of g.cats) {
      const row = document.createElement('div'); row.className = 'pg-cat';
      const lab = document.createElement('span'); lab.textContent = c.label;
      const catLink = document.createElement('a');
      catLink.textContent = catPageTitle(c.cat);
      catLink.title = '在分栏里打开该分类页面（参考栏）';
      catLink.addEventListener('click', (e) => { e.preventDefault(); openRefPage(catPageTitle(c.cat)); });
      const st = document.createElement('span'); st.className = 'pg-sub'; st.textContent = '载入中…';
      row.appendChild(lab); row.appendChild(catLink); row.appendChild(st);
      catsBox.appendChild(row);
      const memBox = document.createElement('div'); memBox.className = 'pg-members';
      catsBox.appendChild(memBox);
      try {
        const list = await loadCatMembers(c.cat);
        const pages = list.filter((x) => x.type === 'page');
        const subs = list.filter((x) => x.type === 'subcat');
        const files = list.filter((x) => x.type === 'file');
        st.textContent = pages.length + ' 个页面' + (subs.length ? (' / ' + subs.length + ' 个子分类') : '') +
          (files.length ? (' / ' + files.length + ' 个文件（未列出）') : '') + (list.length >= 500 ? '（仅前 500 项）' : '');
        if (!pages.length) {
          const e = document.createElement('span'); e.className = 'pg-sub'; e.textContent = '（该分类没有直接包含的页面）';
          memBox.appendChild(e);
        }
        pages.forEach((pg) => {
          const b = document.createElement('button');
          b.type = 'button'; b.className = 'pg-page'; b.textContent = pg.title;
          b.title = '点：用加强编辑器在新标签页打开「' + pg.title + '」；Ctrl/⌘+点击：开在分栏里';
          b.addEventListener('click', (e) => {
            if (e.ctrlKey || e.metaKey) { openRefPage(pg.title); return; }
            openEditorForPage(pg.title);
          });
          memBox.appendChild(b);
        });
        subs.forEach((sc) => {
          const b = document.createElement('button');
          b.type = 'button'; b.className = 'pg-page'; b.textContent = '📂 ' + sc.title;
          b.title = '子分类：开在分栏里查看';
          b.addEventListener('click', () => openRefPage(sc.title));
          memBox.appendChild(b);
        });
      } catch (e) {
        st.textContent = '载入失败：' + (e.message || e);
      }
    }
  }

  function buildProgressModal() {
    const modal = $('progressModal');
    if (!modal) return;
    wireModal(modal, 'progressModal');
    const x = $('progressModalX'), ok = $('progressModalOk'), rl = $('pgReload');
    const ea = $('pgExpandAll'), ca = $('pgCollapseAll');
    if (x) x.addEventListener('click', () => modalClose(modal));
    if (ok) ok.addEventListener('click', () => modalClose(modal));
    if (rl) rl.addEventListener('click', () => loadProgress(true));
    const setAll = (open) => {
      document.querySelectorAll('#pgBody .pg-cats').forEach((box) => { box.hidden = !open; });
      document.querySelectorAll('#pgBody .pg-caret').forEach((c) => { c.textContent = open ? '▾' : '▸'; });
      if (open) document.querySelectorAll('#pgBody .pg-cats').forEach(async (box) => {
        if (box._loaded) return;
        box._loaded = true;
        const gi = Array.prototype.indexOf.call(document.querySelectorAll('#pgBody .pg-group'), box.parentNode);
        const g = state.progressGroups[gi];
        if (g) await fillProgressCats(box, g);
      });
    };
    if (ea) ea.addEventListener('click', () => setAll(true));
    if (ca) ca.addEventListener('click', () => setAll(false));
  }
  function openProgress() {
    modalOpen($('progressModal'));
    const src = $('pgSrc');
    if (src) src.innerHTML = '数据来源：<a href="#" id="pgSrcLink">' + escH(PROGRESS_PAGE) + '</a>';
    const link = $('pgSrcLink');
    if (link) link.addEventListener('click', (e) => { e.preventDefault(); openRefPage(PROGRESS_PAGE); });
    loadProgress(false);
  }

  async function runSearch(q) {
    q = String(q || '').trim();
    const info = $('seInfo'), list = $('seList');
    if (!q) { if (info) info.textContent = '请输入页面名或关键词'; if (list) list.innerHTML = ''; return; }
    const my = ++_seToken;
    if (info) info.textContent = '正在搜索「' + q + '」…';
    if (list) list.innerHTML = '';
    try {
      const r = await fetch(searchApiUrl(q, 20), { credentials: 'omit', headers: { 'Accept': 'application/json' } });
      const j = await r.json();
      if (my !== _seToken) return;                       // 已有更新的查询，丢弃本次结果
      const hits = (j && j.query && Array.isArray(j.query.search)) ? j.query.search : [];
      if (info) info.textContent = '共 ' + hits.length + ' 条结果（最多显示 20 条）';
      renderSearchResults(list, hits, q);
    } catch (e) {
      if (my !== _seToken) return;
      if (info) info.textContent = '搜索失败：' + (e.message || e);
      if (list) list.innerHTML = '';
    }
  }

  function openSearch(seed) {
    const modal = $('searchModal'); if (!modal) return;
    const inp = $('seInput');
    if (inp) {
      const top = $('siteSearch');
      const v = seed != null ? seed : (top ? top.value : '');
      inp.value = v || '';
    }
    modalOpen(modal);
    if (inp) { inp.focus(); inp.select(); }
    if (inp && inp.value.trim()) runSearch(inp.value);
  }

  function buildSearchModal() {
    const modal = $('searchModal');
    if (!modal) return;
    wireModal(modal, 'searchModal');
    const x = $('searchModalX'), ok = $('searchModalOk'), go = $('seGo'), inp = $('seInput'), exact = $('seExact');
    if (x) x.addEventListener('click', () => modalClose(modal));
    if (ok) ok.addEventListener('click', () => modalClose(modal));
    if (go) go.addEventListener('click', () => runSearch(inp ? inp.value : ''));
    if (inp) {
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); runSearch(inp.value); }
        else if (e.key === 'Escape') { e.preventDefault(); modalClose(modal); }
      });
    }
    if (exact) exact.addEventListener('click', () => {
      const t = (inp ? inp.value : '').trim();
      if (!t) { toast('请先输入页面名'); return; }
      modalClose(modal);
      openEditorForPage(t);
    });
    const exactRef = $('seExactRef');
    if (exactRef) exactRef.addEventListener('click', () => {
      const t = (inp ? inp.value : '').trim();
      if (!t) { toast('请先输入页面名'); return; }
      modalClose(modal);
      openRefPage(t);
    });
    // 顶栏搜索框：回车或点按钮都打开搜索弹窗（带上下文）
    const top = $('siteSearch'), tbtn = $('btnSearch');
    if (top) {
      top.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); openSearch(top.value); }
      });
    }
    if (tbtn) tbtn.addEventListener('click', () => openSearch(top ? top.value : ''));
  }

  // ---------- 保存：编辑标签页直接带 cookie 保存（+ 小编辑 / 监视）----------
  async function saveDirect(text, opts) {
    const api = apiUrl();
    const tkResp = await fetch(api + '?action=query&meta=tokens&type=csrf&format=json', { credentials: 'include', headers: { 'Accept': 'application/json' } });
    const tkj = await tkResp.json();
    const token = tkj && tkj.query && tkj.query.tokens && tkj.query.tokens.csrftoken;
    if (!token) throw new Error('无法获取编辑令牌（可能未登录或 cookie 被拦）');
    const fd = new FormData();
    fd.append('action', 'edit'); fd.append('title', state.title); fd.append('text', text);
    fd.append('summary', opts.summary || '通过可视化编辑器编辑'); fd.append('token', token); fd.append('format', 'json');
    if (opts.minor) fd.append('minor', '1');
    fd.append('watchlist', opts.watch ? 'watch' : 'nochange');
    const resp = await fetch(api, { method: 'POST', credentials: 'include', body: fd, headers: { 'Accept': 'application/json' } });
    const j = await resp.json();
    if (j && j.error) throw new Error(j.error.info || j.error.code || '编辑失败');
    return j;
  }
  function saveViaOriginal(text, opts) {
    return chrome.runtime.sendMessage({ type: 'SAVE_VIA_ORIGINAL', src: state.srcTabId, title: state.title, text, summary: opts.summary, minor: opts.minor, watch: opts.watch });
  }

  // ---------- 保存：点「保存」后在底栏（表格面板底部）就地展开保存栏，确认后带 cookie 提交 ----------
  let lastSummary = '';
  let modalReload = false;

  // ---------- 编辑概要：用户自己设定 / 管理（预制概要）----------
  // 存储：chrome.storage.local[SUMMARY_KEY] = [{label, text}, …]
  // 旧版本用 editSummaries（字符串数组）：首次使用时迁移，之后只读写新键 ——
  // 这样「把预制概要全删光」之后不会被默认值偷偷恢复。
  const SUMMARY_KEY = 'summaryPresets';
  const LEGACY_SUMMARY_KEY = 'editSummaries';

  function normalizeSummaryItems(list) {
    return (list || []).map((s) => {
      if (typeof s === 'string') return { label: '', text: s };
      if (s && s.text !== undefined) return { label: String(s.label || ''), text: String(s.text || '') };
      return { label: '', text: String(s == null ? '' : s) };
    }).filter((s) => s.text || s.label);
  }

  function migrateSummaryPresets() {
    return new Promise((res) => {
      try {
        chrome.storage.local.get([SUMMARY_KEY, LEGACY_SUMMARY_KEY], (r) => {
          const stored = r && r[SUMMARY_KEY];
          if (!Array.isArray(stored)) {                 // 还没有新键 → 用旧数据或默认值初始化
            const legacy = (r && Array.isArray(r[LEGACY_SUMMARY_KEY]) && r[LEGACY_SUMMARY_KEY].length)
              ? r[LEGACY_SUMMARY_KEY] : DEFAULT_SUMMARIES.slice();
            saveJSON(SUMMARY_KEY, normalizeSummaryItems(legacy));
          }
          res();
        });
      } catch (e) { res(); }
    });
  }

  // 点预制概要 chip = **追加**到输入框（需求：追加而不是清空原概要）
  function appendSummary(text) {
    const inp = $('sbSummary'); if (!inp) return;
    const add = String(text == null ? '' : text);
    if (!add) return;
    const cur = inp.value;
    if (!cur.trim()) {
      inp.value = add;
    } else {
      // 原概要已以分隔符/标点/空白结尾就不再补分隔符，避免出现「修正错别字；；补充内容」
      const sep = /[；;，,、：:\s]$/.test(cur) ? '' : '；';
      inp.value = cur.replace(/\s+$/, '') + sep + add;
    }
    try { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) { }
  }

  // 懒创建"保存栏"：固定吸附在窗口底部，避免被长内容挤出可视区
  function buildSaveBar() {
    const bar = document.createElement('div');
    bar.id = 'saveBar'; bar.className = 'save-bar'; bar.hidden = true;
    bar.innerHTML = '';

    const row1 = document.createElement('div'); row1.className = 'sb-row';
    const lb = document.createElement('span'); lb.className = 'sb-label'; lb.textContent = '编辑概要';
    const inp = document.createElement('input'); inp.id = 'sbSummary'; inp.className = 'sb-input';
    inp.placeholder = '本次编辑摘要（点下方预制概要可追加；可自己设定与管理）';
    const clr = document.createElement('button'); clr.type = 'button'; clr.id = 'sbClear';
    clr.className = 'btn ghost small'; clr.textContent = '清空'; clr.title = '清空当前编辑概要输入框';
    row1.appendChild(lb); row1.appendChild(inp); row1.appendChild(clr);

    const chips = document.createElement('div'); chips.id = 'sbChips'; chips.className = 'chips sb-chips';

    // 概要管理面板（与「表格片段」同一套 UI 与存储逻辑）
    const manageRow = document.createElement('div'); manageRow.className = 'sb-row sb-manage-row';
    const mgBtn = document.createElement('button'); mgBtn.type = 'button'; mgBtn.id = 'sbManageBtn';
    mgBtn.className = 'btn ghost small'; mgBtn.textContent = '管理概要';
    const mgTip = document.createElement('span'); mgTip.className = 'sb-tip';
    mgTip.appendChild(document.createTextNode('点 chip 会把概要文本'));
    const mgTipEm = document.createElement('strong'); mgTipEm.textContent = '追加';
    mgTip.appendChild(mgTipEm);
    mgTip.appendChild(document.createTextNode('到输入框（不清空原有的）；下方可增删改自己的常用概要。'));
    manageRow.appendChild(mgBtn); manageRow.appendChild(mgTip);

    const manage = document.createElement('div'); manage.id = 'sbManage'; manage.className = 'snip-manage'; manage.hidden = true;
    const mgList = document.createElement('div'); mgList.id = 'sbList'; mgList.className = 'snip-list';
    const mgAdd = document.createElement('div'); mgAdd.className = 'snip-add';
    const newLabel = document.createElement('input'); newLabel.id = 'sbNewLabel'; newLabel.placeholder = '名称（可空）';
    const newText = document.createElement('input'); newText.id = 'sbNewText'; newText.placeholder = '概要文本，如 修正错别字';
    const addBtn = document.createElement('button'); addBtn.type = 'button'; addBtn.id = 'sbAddBtn';
    addBtn.className = 'btn primary'; addBtn.textContent = '+ 添加';
    mgAdd.appendChild(newLabel); mgAdd.appendChild(newText); mgAdd.appendChild(addBtn);
    manage.appendChild(mgList); manage.appendChild(mgAdd);

    const row2 = document.createElement('div'); row2.className = 'sb-row sb-actions';
    const minor = document.createElement('label'); minor.className = 'sb-chk';
    minor.innerHTML = '<input type="checkbox" id="sbMinor"> 这是小编辑';
    const watch = document.createElement('label'); watch.className = 'sb-chk';
    watch.innerHTML = '<input type="checkbox" id="sbWatch"> 监视此页面';
    const sp = document.createElement('span'); sp.className = 'sb-spacer';
    const diffBtn = document.createElement('button'); diffBtn.type = 'button'; diffBtn.id = 'sbDiff'; diffBtn.className = 'btn ghost'; diffBtn.textContent = '对比差异';
    const cancel = document.createElement('button'); cancel.type = 'button'; cancel.id = 'sbCancel'; cancel.className = 'btn ghost'; cancel.textContent = '取消';
    const ok = document.createElement('button'); ok.type = 'button'; ok.id = 'sbConfirm'; ok.className = 'btn primary'; ok.textContent = '确认保存';
    row2.appendChild(minor); row2.appendChild(watch); row2.appendChild(sp);
    row2.appendChild(diffBtn); row2.appendChild(cancel); row2.appendChild(ok);

    bar.appendChild(row1); bar.appendChild(chips); bar.appendChild(manageRow); bar.appendChild(manage); bar.appendChild(row2);
    document.body.appendChild(bar);

    // 预制概要：用户自定义 + 可管理。点 chip = **追加**（见 appendSummary），不再覆盖已填内容。
    migrateSummaryPresets().then(() => {
      buildSnippetManager({
        chipsEl: chips, listEl: mgList, toggleBtn: mgBtn, manageEl: manage,
        storageKey: SUMMARY_KEY, defaults: DEFAULT_SUMMARIES.map((t) => ({ text: t })),
        loader: () => loadJSONStrict(SUMMARY_KEY, DEFAULT_SUMMARIES.map((t) => ({ text: t }))),
        placeholder: '概要文本，如 修正错别字',
        onInsert: (t) => appendSummary(t),
        newLabelEl: newLabel, newTextEl: newText, addBtn: addBtn
      });
    });

    clr.addEventListener('click', () => { inp.value = ''; try { inp.focus(); } catch (e) { } });

    cancel.addEventListener('click', closeSaveBar);
    ok.addEventListener('click', confirmSave);
    diffBtn.addEventListener('click', () => {
      const opts = {
        summary: (($('sbSummary') && $('sbSummary').value.trim()) || '通过可视化编辑器编辑'),
        minor: !!($('sbMinor') && $('sbMinor').checked),
        watch: !!($('sbWatch') && $('sbWatch').checked)
      };
      lastSummary = opts.summary; openDiffModal(opts);   // 仅预览差异，不提交保存
    });
    return bar;
  }

  function openSaveBar(reload) {
    modalReload = reload;
    if (!$('saveBar')) buildSaveBar();
    const bar = $('saveBar'); bar.hidden = false;
    $('sbSummary').value = lastSummary || '';
    $('sbMinor').checked = false;
    $('sbWatch').checked = false;
    try { $('sbSummary').focus(); } catch (e) { }
  }
  function closeSaveBar() { const b = $('saveBar'); if (b) b.hidden = true; }

  async function confirmSave() {
    // 点「确认保存」不再直接提交，而是先弹出「保存前差异对比」，确认后再真正保存。
    const opts = {
      summary: (($('sbSummary') && $('sbSummary').value.trim()) || '通过可视化编辑器编辑'),
      minor: !!($('sbMinor') && $('sbMinor').checked),
      watch: !!($('sbWatch') && $('sbWatch').checked)
    };
    lastSummary = opts.summary;
    closeSaveBar();
    openDiffModal(opts);
  }

  // ---------- 保存前差异对比（LCS 行级 diff）----------
  // 行数乘积过大会让 O(n*m) 的 DP 矩阵内存爆掉，给一个安全上限：超过则退化为
  // 「整篇旧 = 删除、整篇新 = 新增」——仍是合法 diff，只是不做最小化。
  function computeLineDiff(a, b) {
    const n = a.length, m = b.length;
    if (n * m > 6000000) {
      const rows = [];
      for (let i = 0; i < n; i++) rows.push({ type: '-', oln: i + 1, nln: null, text: a[i] });
      for (let j = 0; j < m; j++) rows.push({ type: '+', oln: null, nln: j + 1, text: b[j] });
      return rows;
    }
    const dp = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
    for (let i = n - 1; i >= 0; i--)
      for (let j = m - 1; j >= 0; j--)
        dp[i][j] = (a[i] === b[j]) ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    const rows = []; let i = 0, j = 0;
    while (i < n && j < m) {
      if (a[i] === b[j]) { rows.push({ type: ' ', oln: i + 1, nln: j + 1, text: a[i] }); i++; j++; }
      else if (dp[i + 1][j] >= dp[i][j + 1]) { rows.push({ type: '-', oln: i + 1, nln: null, text: a[i] }); i++; }
      else { rows.push({ type: '+', oln: null, nln: j + 1, text: b[j] }); j++; }
    }
    while (i < n) { rows.push({ type: '-', oln: i + 1, nln: null, text: a[i] }); i++; }
    while (j < m) { rows.push({ type: '+', oln: null, nln: j + 1, text: b[j] }); j++; }
    return rows;
  }
  function renderDiff() {
    const old = (state.originalText || '').split('\n');
    const cur = state.lines.join('\n').split('\n');
    const rows = computeLineDiff(old, cur);
    let add = 0, del = 0;
    const html = rows.map((r) => {
      if (r.type === '+') add++; else if (r.type === '-') del++;
      const cls = r.type === '+' ? 'add' : (r.type === '-' ? 'del' : 'ctx');
      const sign = r.type === '+' ? '+ ' : (r.type === '-' ? '- ' : '  ');
      const g1 = (r.oln != null) ? r.oln : '';
      const g2 = (r.nln != null) ? r.nln : '';
      return '<div class="df-row ' + cls + '"><span class="g">' + g1 + '</span><span class="g2">' + g2 + '</span><span class="tx">' + escH(sign + r.text) + '</span></div>';
    }).join('');
    $('dfBody').innerHTML = html || '<div class="df-empty">没有差异</div>';
    const bOld = byteLen(state.originalText || ''), bCur = byteLen(state.lines.join('\n'));
    $('dfStat').textContent = '原始 ' + old.length + ' 行 / ' + bOld + ' 字节 · 当前 ' + cur.length + ' 行 / ' + bCur + ' 字节 · 删除 ' + del + ' 行 · 新增 ' + add + ' 行';
    // 选了会转换的变体时，差异弹窗里也明确写出来（保存下去的将是转换后的字）
    if (state.variant && !variantIsRaw()) {
      $('dfStat').textContent += ' · 预览按「' + variantName() + '」渲染（源码与本次保存仍是 wiki 原文）';
    }
    $('dfBody').scrollTop = 0;
  }
  function openDiffModal(opts) {
    state._pendingSaveOpts = opts || {};
    renderDiff();
    modalOpen($('diffModal'));
  }
  async function doSave() {
    const opts = state._pendingSaveOpts || {};
    // 注意：这里**不再**为「非不转换」弹危险确认 —— 源码永远是 wiki 原文
    //（MediaWiki 只转换渲染结果，不转换 wikitext；三种 API 路径都已实测），
    // 所以选繁體预览并不会把转换后的字写回库里。
    modalClose($('diffModal'));
    const text = state.lines.join('\n'); syncSource();
    setStatus('保存中…');
    try {
      let res;
      try { res = await saveDirect(text, opts); }
      catch (e) {
        if (state.srcTabId && /未登录|令牌|token|assert|cookie/i.test(e.message)) {
          setStatus('直接保存受限，改经原页面保存…');
          const fb = await saveViaOriginal(text, opts);
          if (!fb || !fb.ok) throw new Error((fb && fb.error) || '兜底保存失败');
          res = fb.data;
        } else throw e;
      }
      setStatus('已保存 ✓'); toast('保存成功');
      if (modalReload && state.srcTabId) chrome.tabs.reload(state.srcTabId);
    } catch (e) { setStatus('保存失败：' + e.message); toast('保存失败：' + e.message); }
  }

  // ---------- 左右分栏拖拽（比例持久化）----------
  function loadNum(key, def) {
    return new Promise((res) => {
      try { chrome.storage.local.get(key, (r) => { const v = r && r[key]; res(typeof v === 'number' ? v : def); }); }
      catch (e) { res(def); }
    });
  }
  // ---------- 事件绑定 ----------
  function bindEvents() {
    $('btnSave').addEventListener('click', () => openSaveBar(false));
    $('btnSaveReload').addEventListener('click', () => openSaveBar(true));
    $('btnReloadSrc').addEventListener('click', loadSource);
    // 在 wiki 原站（新标签页）打开当前页面：对照原站效果 / 使用原站维护工具
    const boo = $('btnOpenOriginal');
    if (boo) boo.addEventListener('click', () => {
      if (!state.title) { toast('页面标题尚未加载完成'); return; }
      openTab(pageUrl(state.title));
    });
    // 分栏：源码栏 / 参考栏 / AI 助手 开关（默认开在右侧；点顶部按钮或分栏上的 × 都能管）
    const bs = $('btnSourcePane');
    if (bs) bs.addEventListener('click', () => toggleView('source', 'right'));
    const br = $('btnRefPane');
    if (br) br.addEventListener('click', () => toggleView('ref', 'right'));
    const bai = $('btnAiPane');
    if (bai) bai.addEventListener('click', () => toggleView('ai', 'right'));
    // AI 助手栏内：重新载入 / 在新标签页打开（iframe 若非同源登录态不生效时的兜底）
    const air = $('aiReload');
    if (air) air.addEventListener('click', () => { const f = $('aiFrame'); if (f) f.setAttribute('src', 'https://chat.deepseek.com/'); });
    const aio = $('aiOpen');
    if (aio) aio.addEventListener('click', () => { try { window.open('https://chat.deepseek.com/', '_blank'); } catch (e) { } });
    // 新建表格：mousedown 阻止默认 → 按钮不夺焦，源码栏 textarea / 渲染区活动单元格的光标与
    // 「活动段」激活态在点击前后保持不变；click 时再按当前光标处插入。
    const bn = $('btnNewTable');
    if (bn) {
      bn.addEventListener('mousedown', (e) => e.preventDefault());
      bn.addEventListener('click', createNewTable);
    }
    const bp = $('btnProgress');
    if (bp) bp.addEventListener('click', openProgress);
    // 参考栏上的两个按钮
    const rr = $('refReload');
    if (rr) rr.addEventListener('click', () => { if (state.refPage) openRefPage(state.refPage); });
    const re = $('refEdit');
    if (re) re.addEventListener('click', () => { if (state.refPage) openEditorForPage(state.refPage); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
