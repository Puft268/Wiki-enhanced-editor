/*
 * theme-boot.js — 在 <head> 同步执行，尽早把主题套到 <html> 上，避免首屏「闪白/闪黑」。
 *
 * 为什么不用内联脚本：MV3 扩展页的 CSP 禁止内联 <script>，只能用外链脚本。
 * 为什么用 localStorage：chrome.storage.local 是异步的，赶不上首屏渲染；
 *   这里用 localStorage 作「即时镜像」，真正的偏好仍以 chrome.storage.local 为准
 *   （editor.js 启动时会再读一次并回写镜像，两者保持一致）。
 */
(function () {
  try {
    var t = localStorage.getItem('enhEditorTheme');
    document.documentElement.setAttribute('data-theme', t === 'dark' ? 'dark' : 'light');
  } catch (e) {
    document.documentElement.setAttribute('data-theme', 'light');
  }
})();
