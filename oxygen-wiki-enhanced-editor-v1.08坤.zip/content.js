/*
 * content.js — 隔离世界内容脚本（页面识别 + 按钮注入）
 *
 * v1.5.1 加固：把"点了没反应"变成"要么成功、要么给出明确原因"。
 *   1) 不用 innerHTML（改用 createElement）——避免站点开启 Trusted Types / 严格 CSP 时创建节点抛错。
 *   2) 自愈：站点会异步重渲染顶栏，可能把注入的按钮抹掉。改为常驻定时器补注入，按钮不会消失。
 *   3) 可见错误：点击时校验扩展上下文；扩展被重载后旧内容脚本会失效（chrome.runtime.id 丢失），
 *      此时明确提示"请刷新本页"，而不是静默失败。发送失败/后台无响应也会弹提示 + 控制台日志。
 *   4) 版本标记：按钮 title 带版本号，便于确认页面上跑的是哪一版（旧版需刷新页面才会被替换）。
 *   5) 后台 OPEN_EDITOR 现在会回执，点击后可在控制台看到 [加强编辑] 成功/失败。
 *
 * 打开链路与工具栏菜单一致：OPEN_EDITOR 消息 → background → chrome.tabs.create 打开独立编辑标签页。
 */
(function () {
  'use strict';

  const BTN_ID = 'wt-enhance-edit-btn';
  const STYLE_ID = 'wt-enhance-style';
  const VERSION = '2.5.1';

  function log(msg) { try { console.log('[加强编辑] ' + msg); } catch (e) {} }
  function logErr(msg) { try { console.error('[加强编辑] ' + msg); } catch (e) {} }

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = [
      '.wt-enhance-btn{',
      '  display:inline-flex;align-items:center;gap:4px;cursor:pointer;',
      '  margin:0 4px;padding:2px 10px;border:1px solid #4f9bff;border-radius:4px;',
      '  background:linear-gradient(180deg,#ffffff,#f3f8ff);color:#1f6fe0;',
      '  font-size:13px;line-height:1.6;font-weight:600;text-decoration:none;',
      '  box-shadow:0 1px 2px rgba(79,155,255,.25);transition:all .15s ease;',
      '}',
      '.wt-enhance-btn:hover{background:linear-gradient(180deg,#ffe9f3,#ffd9ea);border-color:#ff7ab0;color:#e23a86;}',
      '.wt-enhance-btn .wt-dot{width:7px;height:7px;border-radius:50%;background:#ff7ab0;box-shadow:0 0 0 3px rgba(255,122,176,.25);}',
      '.wt-enhance-float{',
      '  position:fixed;top:14px;right:14px;z-index:2147483647;',
      '  display:inline-flex;align-items:center;gap:6px;cursor:pointer;',
      '  padding:8px 14px;border:none;border-radius:22px;',
      '  background:linear-gradient(135deg,#ff9ec7,#7ab8ff);color:#fff;',
      '  font-size:14px;font-weight:700;box-shadow:0 4px 14px rgba(122,184,255,.5);',
      '}',
      '.wt-enhance-float:hover{filter:brightness(1.05);}',
      '.wt-enhance-float .wt-dot{width:8px;height:8px;border-radius:50%;background:#fff;}',
      ''
    ].join('\n');
    document.head.appendChild(s);
  }

  function normalizeServer(s) {
    if (!s) return location.origin;
    if (s.indexOf('//') === 0) s = location.protocol + s;
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    return s.replace(/\/+$/, '');
  }

  // ---- 从 URL 推导 server / scriptPath / title（与 manager.js 同一规则）----
  // wiki.gg 语言站：/zh/wiki/标题 → scriptPath="/zh"；根站：/wiki/标题 → scriptPath=""。
  function deriveFromUrl(u) {
    const out = { server: location.origin, scriptPath: '', title: '' };
    let x;
    try { x = new URL(u); } catch (e) { return out; }
    out.server = x.origin;
    const path = x.pathname;
    const lm = path.match(/^\/([a-z]{2}(?:-[a-z]+)?)(\/|$)/i);
    if (lm && path.length > ('/' + lm[1]).length) out.scriptPath = '/' + lm[1].toLowerCase();
    let title = '';
    const wm = path.match(/\/wiki\/(.+)$/i);
    if (wm) title = decodeURIComponent(wm[1]);
    else { const q = x.searchParams.get('title'); if (q) title = q; }
    out.title = (title || '').replace(/_/g, ' ').replace(/\+/g, ' ').trim();
    return out;
  }

  // ---- 读取页面信息（URL 优先，DOM 兜底）----
  function getPageInfo() {
    const info = { ok: false, title: '', server: '', scriptPath: '', revId: 0, ns: 0, articleId: 0 };
    const editing = /[?&](action|veaction)=(edit|submit|editredlink|editsource)/i.test(location.search)
      || /[?&]veaction=/i.test(location.search);
    if (editing) { info.ok = false; return info; } // 正在编辑的页面不再注入
    if (/\/(Special|File|Media):/i.test(location.pathname)) { info.ok = false; return info; }

    const d = deriveFromUrl(location.href);
    if (d.title) {
      info.title = d.title; info.server = d.server; info.scriptPath = d.scriptPath;
      info.articleId = 1; info.ok = true; return info;
    }

    // DOM 兜底：标题取首标题，scriptPath 复用同一套语言前缀推导
    try {
      const h = document.querySelector('#firstHeading, .mw-first-heading, .mw-page-title-main, h1');
      let t = h ? (h.textContent || '').trim() : (document.title || '').trim();
      t = t.replace(/\s*[–\-]\s*[^–\-]+$/, '').trim();
      if (!t) { info.ok = false; return info; }
      info.server = d.server || normalizeServer(location.origin);
      info.scriptPath = d.scriptPath;
      info.title = t;
      info.articleId = 1;
      info.ok = true;
    } catch (e) { info.ok = false; }
    return info;
  }

  function findEditAnchor() {
    const candidates = [
      '#ca-edit a', '#ca-ve-edit a',
      '[data-id="ca-edit"] a', '[data-id="ca-ve-edit"] a',
      'a[href*="action=edit"]:not([href*="section="])',
      'a[href*="veaction=edit"]',
      '#p-views li a', '#p-cactions a'
    ];
    for (const sel of candidates) {
      let a = null;
      try { a = document.querySelector(sel); } catch (e) { continue; }
      if (a && a.offsetParent !== null && (a.textContent || '').trim()) return a;
    }
    return null;
  }

  // 扩展上下文是否仍有效：扩展被重载/更新后，旧内容脚本的 runtime.id 会消失
  function contextAlive() {
    try { return !!(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id); }
    catch (e) { return false; }
  }

  function makeDot(cls) { const d = document.createElement('span'); d.className = cls; return d; }

  // 触发节流：pointerdown 与 click 都会调到，避免一次点击开两个标签页
  let lastTrigger = 0;
  function trigger(e) {
    const now = Date.now();
    if (now - lastTrigger < 800) return;
    lastTrigger = now;
    onClick(e);
  }
  // 同时挂 click 与 pointerdown(capture)：即便站点拦截/阻止了 click 冒泡，pointerdown 仍会触发
  function wire(btn) {
    btn.addEventListener('click', trigger);
    btn.addEventListener('pointerdown', trigger, true);
    return btn;
  }

  /* ------------------------------------------------------------------
   * 可选功能：双击页面跳转到加强编辑
   *
   * 与本站「双击编辑」的兼容策略（关键）：
   *   MediaWiki 有原生双击编辑（通常双击正文 .mw-parser-output 进入该节编辑），
   *   若我们无条件抢占 dblclick，会和站点行为冲突。因此：
   *     1) 默认关闭（opt-in），用户可在工具栏弹窗里勾选开启；
   *     2) 仅在"安全区"触发——落在正文链接/按钮/输入框/图片/表格/导航等元素上时一律不抢，
   *        把双击让给站点；只有双击正文文字（段落）时才接管；
   *     3) 用捕获阶段监听，抢到时 preventDefault+stopImmediatePropagation 阻止站点响应；
   *        若用户设置为"优先本站"，则不拦截，仅在本站无双击编辑时才接管。
   * ------------------------------------------------------------------ */
  const DBL_KEY = 'dblclickEnabled';
  const DBL_MODE_KEY = 'dblclickMode'; // 'preferEnhanced' | 'preferSite'
  let dblClickOn = false;
  let dblClickMode = 'preferEnhanced';

  // 本站是否具备双击编辑能力（mw.user.options 'editondblclick'，或页面存在常见可编辑标记）
  function siteHasDblEdit() {
    try {
      const mw = window.mw;
      if (mw && mw.user && typeof mw.user.options === 'object') {
        const v = mw.user.options.get && mw.user.options.get('editondblclick');
        if (v !== undefined && v !== null && v !== '' && v !== false && v !== 0 && v !== '0') return true;
      }
    } catch (e) { /* mw 可能不可用 */ }
    return false;
  }

  // 双击落点是否属于"应让给站点"的元素（链接/按钮/表单/媒体/表格/导航/已标记可编辑块）
  function isSiteOwnedTarget(t) {
    if (!t || t.nodeType !== 1) return true;
    const sel = 'a,button,input,textarea,select,label,img,video,audio,svg,canvas,table,' +
      '[contenteditable],[role=button],[role=link],[role=tab],.mw-editsection,' +
      '.mw-parser-output table,.navbox,.infobox,.portable-infobox,' +
      '#toc,.toc,#p-navigation,#p-search,#p-personal,#p-views,#p-cactions,' +
      '.vector-menu,.vector-tabs,#mw-navigation';
    try { if (t.closest(sel)) return true; } catch (e) { }
    // 落在交互/导航/侧栏容器内，同样让给站点
    try { if (t.closest('#mw-panel,.mw-body-header,#siteSub,#jump-to-nav,.mw-indicators')) return true; } catch (e) { }
    return false;
  }

  // 双击的目标应位于正文区（更稳妥地判定"是不是在编辑正文"）
  function isContentArea(t) {
    try { return !!(t.closest && (t.closest('.mw-parser-output') || t.closest('#mw-content-text'))); } catch (e) { return false; }
  }

  function onPageDblClick(e) {
    if (!dblClickOn) return;
    if (e.button !== 0) return;
    if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    if (!contextAlive()) return; // 上下文失效时静默让给站点，避免误拦

    const t = e.target;
    // 落在"站点拥有"的交互元素上：一律让给站点（兼容本站双击编辑/双击选中）
    if (isSiteOwnedTarget(t)) return;
    // 仅在正文区接管；非正文（侧栏/页脚等）让给站点
    if (!isContentArea(t)) return;

    const info = getPageInfo();
    if (!info.ok) return;

    // 优先本站：本站具备双击编辑时，不抢（仅在站点不具备时才接管）
    if (dblClickMode === 'preferSite' && siteHasDblEdit()) return;

    // 接管：阻止站点默认响应与其它监听器，随后打开加强编辑
    try { e.preventDefault(); } catch (err) { }
    try { e.stopImmediatePropagation(); } catch (err) { }
    log('双击正文 → 打开加强编辑 title=' + info.title);
    openEditor(info, 0);
  }

  function loadDblSettings() {
    try {
      chrome.storage.local.get([DBL_KEY, DBL_MODE_KEY], (r) => {
        dblClickOn = !!(r && r[DBL_KEY]);
        dblClickMode = (r && r[DBL_MODE_KEY]) === 'preferSite' ? 'preferSite' : 'preferEnhanced';
      });
    } catch (e) { /* 忽略 */ }
  }
  // 设置可能在弹窗里被改动：监听存储变更即时生效，无需刷新页面
  try {
    if (chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((chg, area) => {
        if (area !== 'local') return;
        if (chg[DBL_KEY]) dblClickOn = !!chg[DBL_KEY].newValue;
        if (chg[DBL_MODE_KEY]) dblClickMode = chg[DBL_MODE_KEY].newValue === 'preferSite' ? 'preferSite' : 'preferEnhanced';
      });
    }
  } catch (e) { /* 忽略 */ }

  function buildButton() {
    const btn = document.createElement('a');
    btn.id = BTN_ID;
    btn.className = 'wt-enhance-btn';
    // 关键：不设 href（尤其不用 javascript:void(0)）——javascript: 受站点 CSP 约束，
    // 且 <a href> 的默认行为可能被站点脚本拦截；无 href 则不存在任何会被拦截的跳转。
    btn.setAttribute('role', 'button');
    btn.setAttribute('tabindex', '0');
    btn.title = '加强编辑 v' + VERSION;
    btn.appendChild(makeDot('wt-dot'));
    btn.appendChild(document.createTextNode('加强编辑'));
    return wire(btn);
  }

  function buildFloatButton() {
    const btn = document.createElement('button');
    btn.id = BTN_ID;
    btn.className = 'wt-enhance-float';
    btn.type = 'button';
    btn.title = '加强编辑 v' + VERSION;
    btn.appendChild(makeDot('wt-dot'));
    btn.appendChild(document.createTextNode('加强编辑'));
    return wire(btn);
  }

  function onClick(e) {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    if (!contextAlive()) {
      logErr('扩展上下文已失效（扩展被重载过），需刷新本页。');
      alert('加强编辑：扩展已更新或重新加载，请刷新当前页面（F5/Ctrl+R）后再点击。');
      return;
    }
    const info = getPageInfo();
    if (!info.ok) {
      logErr('当前页面判定为不可编辑，未发送。url=' + location.href);
      alert('当前页面不是可编辑的 wiki.gg 内容页');
      return;
    }
    log('点击：准备打开编辑页 title=' + info.title + ' scriptPath=' + info.scriptPath);
    openEditor(info, 0);
  }

  // 发送 OPEN_EDITOR；带回调与重试，任何失败都会明确报出来（不再静默）
  function openEditor(info, attempt) {
    const payload = {
      type: 'OPEN_EDITOR', title: info.title, server: info.server,
      scriptPath: info.scriptPath, revId: info.revId
    };
    let sent = false;
    try {
      chrome.runtime.sendMessage(payload, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) {
          // 服务工作者可能刚休眠或被回收：短延迟重试
          if (attempt < 2) { logErr('发送失败（第' + (attempt + 1) + '次）：' + err.message + '，重试…'); setTimeout(() => openEditor(info, attempt + 1), 300); return; }
          logErr('无法与扩展后台通信：' + err.message);
          alert('加强编辑：无法与扩展后台通信（' + err.message + '）。\n请确认扩展已启用，并可尝试重新加载扩展后刷新本页。');
          return;
        }
        if (resp && resp.ok === false) {
          logErr('后台打开标签页失败：' + (resp.error || '未知'));
          alert('加强编辑：无法打开编辑标签页（' + (resp.error || '未知') + '）。');
          return;
        }
        log('已打开编辑标签页（后台回执：' + JSON.stringify(resp || {}) + '）');
      });
      sent = true;
    } catch (e) {
      // 同步异常（例如上下文失效）：重试一次
      if (attempt < 2) { setTimeout(() => openEditor(info, attempt + 1), 300); return; }
      logErr('发送异常：' + (e && e.message));
      alert('加强编辑：发送失败（' + (e && e.message) + '）。请重新加载扩展并刷新本页。');
      return;
    }
    if (!sent) logErr('消息未能发出');
  }

  function inject() {
    try {
      if (!document.body) return false;
      if (document.getElementById(BTN_ID)) return true;
      injectStyle();
      const info = getPageInfo();
      if (!info.ok) return false;

      const anchor = findEditAnchor();
      if (anchor) {
        const li = anchor.closest('li') || anchor.parentElement;
        const btn = buildButton();
        if (li && li.parentElement) li.parentElement.insertBefore(btn, li.nextSibling);
        else if (anchor.parentElement) anchor.parentElement.insertBefore(btn, anchor.nextSibling);
        else throw new Error('无插入点');
        return true;
      }
      document.body.appendChild(buildFloatButton());
      return true;
    } catch (e) {
      logErr('注入失败：' + (e && e.message));
      // 最后兜底：无论如何都放一个悬浮按钮
      try { if (document.body && !document.getElementById(BTN_ID)) document.body.appendChild(buildFloatButton()); } catch (e2) {}
      return !!document.getElementById(BTN_ID);
    }
  }

  // 首次快轮询（等原生编辑控件/mw 就绪），随后常驻慢补注入（防站点重渲染把按钮抹掉）
  let fastTries = 0;
  function start() {
    log('内容脚本已注入 v' + VERSION + '（隔离世界）');
    loadDblSettings();
    (function fast() {
      inject();
      fastTries++;
      if (fastTries < 12 && !document.getElementById(BTN_ID)) setTimeout(fast, 400);
    })();
    setInterval(() => { if (!document.getElementById(BTN_ID)) inject(); }, 2000);
  }

  // 双击监听：捕获阶段挂在 document 上，确保先于站点处理（且便于在"安全区"放行）
  document.addEventListener('dblclick', onPageDblClick, true);

  // 供管理页（popup）查询精确页面信息
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === 'GET_PAGE_INFO') { sendResponse(getPageInfo()); return true; }
      // 弹窗打开时同步当前双击设置（避免首次打开读到默认值）
      if (msg && msg.type === 'GET_DBL_SETTINGS') {
        sendResponse({ enabled: dblClickOn, mode: dblClickMode, hasDblEdit: siteHasDblEdit() });
        return true;
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
