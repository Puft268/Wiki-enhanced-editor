/*
 * inject-proxy.js — MAIN world 保存代理（注入到「原 wiki.gg 页面」中）
 *
 * 只暴露 window.__WTPROXY.saveWiki(title, text, summary)：
 *   - 从 window.mw.config 读取 wgServer / wgScriptPath，拼出 api.php 地址；
 *   - fetch 取 csrf token（credentials:'same-origin' 携带用户会话 cookie）；
 *   - POST action=edit 回写 wikitext（同样带 cookie，因此需要登录态才能保存）。
 * 之所以放在原页面 MAIN world，是因为扩展页（chrome-extension://）跨域请求
 * wiki.gg 时无法自动附带 cookie，而原页面同源可携带。
 */
(function () {
  'use strict';

  function apiBase() {
    try {
      const mw = window.mw;
      if (mw && mw.config) {
        let server = mw.config.get('wgServer') || location.origin;
        if (server.indexOf('//') === 0) server = location.protocol + server;
        const sp = mw.config.get('wgScriptPath') || '';
        return server + sp + '/api.php';
      }
    } catch (e) { /* 回退 */ }
    const m = location.pathname.match(/^(\/[a-z-]+)?\//i);
    const sp = (m && m[1]) ? m[1] : '';
    return location.origin + sp + '/api.php';
  }

  window.__WTPROXY = {
    saveWiki: async function (title, text, summary, minor, watch) {
      try {
        const api = apiBase();
        const tk = await fetch(api + '?action=query&meta=tokens&type=csrf&format=json', {
          credentials: 'same-origin', headers: { 'Accept': 'application/json' }
        });
        const tkj = await tk.json();
        const token = tkj && tkj.query && tkj.query.tokens && tkj.query.tokens.csrftoken;
        if (!token) throw new Error('无法获取编辑令牌（可能未登录）');
        const fd = new FormData();
        fd.append('action', 'edit');
        fd.append('title', title);
        fd.append('text', text);
        fd.append('summary', (summary && summary.length) ? summary : '通过加强编辑保存');
        fd.append('token', token);
        fd.append('format', 'json');
        if (minor) fd.append('minor', '1');
        fd.append('watchlist', watch ? 'watch' : 'nochange');
        const resp = await fetch(api, {
          method: 'POST', credentials: 'same-origin', body: fd,
          headers: { 'Accept': 'application/json' }
        });
        const j = await resp.json();
        if (j && j.error) throw new Error(j.error.info || j.error.code || '编辑失败');
        return { ok: true, edit: j && j.edit };
      } catch (e) {
        return { ok: false, error: e.message || String(e) };
      }
    }
  };
})();
