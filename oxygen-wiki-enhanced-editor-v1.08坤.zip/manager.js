/*
 * manager.js — 扩展独立管理页（popup）
 *
 * 作用：不依赖内容脚本注入，直接列出当前浏览器中所有打开的 wiki.gg 标签页，
 *       点「加强编辑」即在独立标签页打开编辑器。这是对「内容脚本按钮用不了」
 *       的稳健替代入口：编辑器加载/保存均在本扩展页面内完成，仅需 host_permissions。
 */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);

  // 弹窗内运行时报错可见化：任何未捕获错误都直接显示在弹窗顶部，避免"点了图标一片空白"。
  function reportFatal(msg) {
    try {
      let el = $('wtFatal');
      if (!el) {
        el = document.createElement('div');
        el.id = 'wtFatal';
        el.style.cssText = 'background:#ffe5ea;color:#a3123a;border-bottom:1px solid #ff9bb3;'
          + 'padding:6px 10px;font:12px/1.6 ui-monospace,Consolas,monospace;white-space:pre-wrap;';
        document.body.insertBefore(el, document.body.firstChild);
      }
      el.textContent = '加强编辑出错：' + msg;
    } catch (e) { /* 忽略 */ }
  }
  window.addEventListener('error', (ev) => { reportFatal((ev && ev.message) || '未知错误'); });
  window.addEventListener('unhandledrejection', (ev) => {
    let r = ev && ev.reason; r = (r && (r.message || r)) || '未处理的 Promise 拒绝';
    reportFatal(String(r));
  });

  // 从标签页 URL 推导 server / scriptPath / title（wiki.gg 语言子路径即 scriptPath）
  function deriveFromUrl(tabUrl) {
    let u;
    try { u = new URL(tabUrl); } catch (e) { return { server: '', scriptPath: '', title: '' }; }
    const server = u.origin;
    let scriptPath = '';
    let title = '';
    const path = u.pathname;
    const lm = path.match(/^\/([a-z]{2}(?:-[a-z]+)?)(\/|$)/i);
    if (lm && path.length > ('/' + lm[1]).length) scriptPath = '/' + lm[1].toLowerCase();
    const wm = path.match(/\/wiki\/(.+)$/i);
    if (wm) title = decodeURIComponent(wm[1]);
    else {
      const q = u.searchParams.get('title');
      if (q) title = q;
    }
    title = (title || '').replace(/_/g, ' ').replace(/\+/g, ' ').trim();
    return { server, scriptPath, title };
  }

  function editorUrl(info) {
    const q = new URLSearchParams({
      title: info.title,
      src: String(info.tabId || ''),
      server: info.server,
      scriptPath: info.scriptPath,
      rev: ''
    });
    return chrome.runtime.getURL('editor/editor.html') + '?' + q.toString();
  }

  // 尝试从内容脚本获取精确页面信息（内容脚本未注入时静默失败，回退 URL 推导）
  function getPageInfoFromContent(tabId) {
    return new Promise((resolve) => {
      let done = false;
      const t = setTimeout(() => { if (!done) { done = true; resolve(null); } }, 600);
      try {
        // 必须用 chrome.tabs.sendMessage（发到指定标签页的内容脚本）；
        // 之前误用 chrome.runtime.sendMessage(tabId, …) 会把 tabId 当成 extensionId，永远失败。
        chrome.tabs.sendMessage(tabId, { type: 'GET_PAGE_INFO' }, (resp) => {
          if (chrome.runtime.lastError) { if (!done) { done = true; clearTimeout(t); resolve(null); } return; }
          if (!done) { done = true; clearTimeout(t); resolve(resp || null); }
        });
      } catch (e) { if (!done) { done = true; clearTimeout(t); resolve(null); } }
    });
  }

  async function buildItems() {
    const tabs = await chrome.tabs.query({ url: ['*://*.wiki.gg/*'] });
    const items = [];
    for (const tab of tabs) {
      const d = deriveFromUrl(tab.url);
      let info = d;
      const cpi = await getPageInfoFromContent(tab.id);
      if (cpi && cpi.ok) {
        info = {
          server: cpi.server || d.server,
          scriptPath: cpi.scriptPath || d.scriptPath,
          title: cpi.title || d.title
        };
      }
      items.push({
        tabId: tab.id,
        active: !!(tab.active && tab.windowId === (await currentWindow())),
        title: info.title,
        server: info.server,
        scriptPath: info.scriptPath,
        display: (tab.title || info.title || tab.url).replace(/\s*[–\-]\s*[^–\-]+$/, '').trim(),
        url: tab.url
      });
    }
    return items;
  }

  function currentWindow() {
    return new Promise((res) => {
      try { chrome.windows.getCurrent((w) => res(w ? w.id : null)); }
      catch (e) { res(null); }
    });
  }

  function render(items) {
    const list = $('list');
    list.innerHTML = '';
    if (!items.length) { $('empty').hidden = false; return; }
    $('empty').hidden = true;
    items.forEach((it) => {
      const li = document.createElement('li');
      li.className = 'item' + (it.active ? ' active' : '');
      const fav = document.createElement('img');
      fav.className = 'fav';
      fav.src = it.tabId ? (tabFavicon(it.tabId)) : '';
      fav.onerror = () => { fav.style.visibility = 'hidden'; };
      li.appendChild(fav);
      const info = document.createElement('div');
      info.className = 'info';
      const t = document.createElement('div'); t.className = 't'; t.textContent = it.display || '(无标题)';
      const u = document.createElement('div'); u.className = 'u'; u.textContent = it.url;
      info.appendChild(t); info.appendChild(u);
      li.appendChild(info);
      const go = document.createElement('button');
      go.className = 'go'; go.textContent = '加强编辑';
      go.disabled = !it.title;
      if (it.title) go.addEventListener('click', () => openEditor(it));
      else go.title = '无法从 URL 解析页面标题';
      li.appendChild(go);
      list.appendChild(li);
    });
  }

  function tabFavicon(tabId) {
    // chrome 不暴露直接 favicon URL，用占位（隐藏）；保留接口便于扩展
    return '';
  }

  function openEditor(it) {
    const url = editorUrl({ title: it.title, server: it.server, scriptPath: it.scriptPath, tabId: it.tabId });
    chrome.tabs.create({ url, active: true });
    window.close();
  }

  async function refresh() {
    const items = await buildItems();
    render(items);
  }

  // ---------- 双击跳转设置（可选功能，默认关闭）----------
  const DBL_KEY = 'dblclickEnabled';
  const DBL_MODE_KEY = 'dblclickMode';
  function saveDbl() {
    const enabled = !!($('optDbl') && $('optDbl').checked);
    let mode = 'preferEnhanced';
    document.querySelectorAll('input[name=dblMode]').forEach((el) => { if (el.checked) mode = el.value; });
    try { chrome.storage.local.set({ [DBL_KEY]: enabled, [DBL_MODE_KEY]: mode }); } catch (e) { }
  }
  function initDblOptions() {
    const chk = $('optDbl'), sub = $('dblSub'), tip = $('dblTip');
    if (!chk) return;
    const sync = () => { sub.hidden = !chk.checked; tip.hidden = !chk.checked; };
    try {
      chrome.storage.local.get([DBL_KEY, DBL_MODE_KEY], (r) => {
        chk.checked = !!(r && r[DBL_KEY]);
        const mode = (r && r[DBL_MODE_KEY]) === 'preferSite' ? 'preferSite' : 'preferEnhanced';
        document.querySelectorAll('input[name=dblMode]').forEach((el) => { el.checked = (el.value === mode); });
        sync();
      });
    } catch (e) { sync(); }
    chk.addEventListener('change', () => { saveDbl(); sync(); });
    document.querySelectorAll('input[name=dblMode]').forEach((el) => el.addEventListener('change', saveDbl));
  }

  try {
    $('btnRefresh').addEventListener('click', () => { refresh().catch((e) => reportFatal('刷新失败：' + (e && e.message ? e.message : e))); });
    $('btnManual').addEventListener('click', () => {
      const title = $('manualTitle').value.trim();
      if (!title) { $('manualTitle').focus(); return; }
      const [server, scriptPath] = $('manualServer').value.split('|');
      const url = editorUrl({ title, server, scriptPath, tabId: '' });
      chrome.tabs.create({ url, active: true });
      window.close();
    });
    initDblOptions();
    refresh().catch((e) => reportFatal('读取标签页失败：' + (e && e.message ? e.message : e)));
  } catch (e) {
    reportFatal('弹窗初始化失败：' + (e && e.message ? e.message : e));
  }
})();
