/*
 * background.js — 服务工作者
 *
 * 职责：
 *  1) OPEN_EDITOR：收到内容脚本的页面信息后，用 chrome.tabs.create 打开独立的
 *     编辑标签页（editor/editor.html）并自动聚焦 —— 实现「切到另一个标签页编辑」。
 *  2) SAVE_VIA_ORIGINAL（兜底）：编辑标签页「直接带 cookie 保存」失败（未登录 /
 *     跨域 cookie 被拦）时，把 wikitext 回写给「原 wiki.gg 页面」的 MAIN world
 *     执行 action=edit（同源，自动携带登录态）。这是兜底链路，正常情况下不触发。
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'OPEN_EDITOR') {
    // msg.src 优先：编辑器页发来的 OPEN_EDITOR 会透传「原始 wiki 页」的标签 id。
    // 若按 sender.tab.id 优先，从编辑器页再开编辑器时会把「编辑器自己的标签 id」当成原页 id，
    // 于是新编辑页保存失败时 SAVE_VIA_ORIGINAL 会往扩展页注入 MAIN world 代理而必然失败。
    // 内容脚本发来的消息没有 src，退回 sender.tab.id（即发消息的那个 wiki 页）。
    const srcTabId = msg.src || ((sender.tab && sender.tab.id) ? sender.tab.id : '');
    const q = new URLSearchParams({
      title: msg.title || '',
      src: String(srcTabId || ''),
      server: msg.server || '',
      scriptPath: msg.scriptPath || '',
      rev: String(msg.revId || '')
    });
    // 可选 #片段：跨页 [[z#xx]] 打开时，让新编辑页加载完直接跳该章节
    let url = chrome.runtime.getURL('editor/editor.html') + '?' + q.toString();
    if (msg.frag) url += '#' + encodeURIComponent(msg.frag);
    // 回执给内容脚本：便于在页面控制台确认"到底有没有打开成功"，不再"点了没反应"。
    chrome.tabs.create({ url, active: true }, (tab) => {
      try {
        if (chrome.runtime.lastError) sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        else sendResponse({ ok: true, tabId: tab && tab.id, title: msg.title || '' });
      } catch (e) { /* 响应通道可能已关闭 */ }
    });
    return true; // 异步响应
  }

  // 兜底保存：经原页面 MAIN world 回写
  if (msg.type === 'SAVE_VIA_ORIGINAL') {
    handleSaveViaOriginal(msg, sendResponse);
    return true; // 异步响应
  }
});

async function handleSaveViaOriginal(msg, sendResponse) {
  const srcTabId = msg.src;
  if (!srcTabId) { sendResponse({ ok: false, error: '缺少原页面标签 id，无法兜底保存' }); return; }
  try {
    const has = await chrome.scripting.executeScript({
      target: { tabId: srcTabId }, world: 'MAIN', func: () => !!window.__WTPROXY
    });
    if (!(has && has[0] && has[0].result)) {
      await chrome.scripting.executeScript({
        target: { tabId: srcTabId }, world: 'MAIN', files: ['inject-proxy.js']
      });
    }
    const r = await chrome.scripting.executeScript({
      target: { tabId: srcTabId }, world: 'MAIN',
      func: (title, text, summary, minor, watch) => window.__WTPROXY.saveWiki(title, text, summary, minor, watch),
      args: [msg.title, msg.text, msg.summary, !!msg.minor, !!msg.watch]
    });
    const res = r && r[0] && r[0].result;
    if (!res) throw new Error('保存代理无返回');
    if (res.ok === false) throw new Error(res.error || '保存失败');
    sendResponse({ ok: true, data: res });
  } catch (e) {
    sendResponse({ ok: false, error: e.message || String(e) });
  }
}
